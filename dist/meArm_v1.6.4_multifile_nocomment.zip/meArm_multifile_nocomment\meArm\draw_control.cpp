#include <math.h>
#include <Arduino.h>
#include "constant_and_positions.h"
#include "move.h"
#include "path_core.h"
#include "joystick_control.h"
#include "pick_place.h"
#include "button_control.h"
#include "draw_control.h"

#define DRAW_DEBUG_SERIAL WEARM_DEBUG_SERIAL

#if WEARM_ENABLE_DRAW

#define DRAW_PEN_Z_DEFAULT    12.0
#define DRAW_CENTER_X_DEFAULT 20.0
#define DRAW_CENTER_Y_DEFAULT  0.0
#define DRAW_HALF_DEFAULT      6.0
#define DRAW_PEN_Z_MIN        -5.0
#define DRAW_PEN_Z_MAX        30.0
#define DRAW_HALF_MIN          2.0
#define DRAW_HALF_MAX         12.0
#define DRAW_CENTER_LIMIT     35.0

#define DRAW_LIFT_DZ           4.0

#define DRAW_V_MAX             3.0
#define DRAW_ACCEL             6.0
#define DRAW_MAX_DPS          70.0
#define DRAW_HOME_DPS         50.0
#define DRAW_JOG_MAX_DPS     200.0
#define DRAW_STEP_MAX          0.02

#define DRAW_TICK_MAX_MS      50UL
#define DRAW_TEACH_START_DELAY_MS 700UL
#define DRAW_HOME_TOL_DEG      0.4

#define DRAW_PATH_SAMPLE_STEP  0.25
#define DRAW_PATH_SAMPLE_MAX  96
#define DRAW_BRANCH_JUMP_DEG  25.0

#define DRAW_POINT_TOL         0.8
#define DRAW_JOG_SCALE         0.5
#define DRAW_JOG_CENTER      512
#define DRAW_JOG_STEP_MAX      0.25
#define DRAW_JOG_STEP_MIN      0.02
#define DRAW_JOG_TOOL_ENABLE   0
#define DRAW_JOG_INVERT_X      0
#define DRAW_JOG_INVERT_Y      0
#define DRAW_JOG_INVERT_Z      0

struct drawVertex {
  double u;
  double v;
};

static const struct drawVertex SHAPE_LINE[2] PROGMEM = {
  { -1.0,  0.0 }, {  1.0,  0.0 }
};
static const struct drawVertex SHAPE_N[4] PROGMEM = {
  { -1.0, -1.0 }, { -1.0,  1.0 }, {  1.0, -1.0 }, {  1.0,  1.0 }
};
static const struct drawVertex SHAPE_TRIANGLE[4] PROGMEM = {
  { -1.0, -1.0 }, {  1.0, -1.0 }, {  0.0,  1.0 }, { -1.0, -1.0 }
};
static const struct drawVertex SHAPE_Z[4] PROGMEM = {
  { -1.0,  1.0 }, {  1.0,  1.0 }, { -1.0, -1.0 }, {  1.0, -1.0 }
};
static const struct drawVertex SHAPE_V[3] PROGMEM = {
  { -1.0,  1.0 }, {  0.0, -1.0 }, {  1.0,  1.0 }
};

static const char *const DRAW_TASK_NAME[DRAW_TASK_COUNT] = {
  "直线", "字母N", "三角形", "字母Z", "字母V", "五点折线", "五点曲线"
};

static const char *const DRAW_TASK_TAG[DRAW_TASK_COUNT] = {
  "LINE", "N", "TRI", "Z", "V", "POLY", "CURVE"
};

static const char *const DRAW_PHASE_NAME[] = {
  "空闲", "回待机", "抬笔移动", "落笔", "绘制中", "抬笔", "示教中", "准备绘制", "结束回待机"
};

static int8_t s_task     = DRAW_TASK_LINE;
static int8_t s_phase    = DRAW_PHASE_IDLE;
static bool s_paused   = false;
static int  s_lastRes  = PROTO_RES_NONE;
static unsigned long s_lastMs = 0UL;
static double s_dtSec  = 0.0;
static unsigned long s_applyMs = 0UL;

static double s_penZ    = DRAW_PEN_Z_DEFAULT;
static double s_centerX = DRAW_CENTER_X_DEFAULT;
static double s_centerY = DRAW_CENTER_Y_DEFAULT;
static double s_half    = DRAW_HALF_DEFAULT;

static double s_pts[DRAW_TEACH_MAX_POINTS][3];
static int8_t s_ptCount  = 0;
static bool   s_curved   = false;
static bool   s_isTeach  = false;
static double s_totalLen = 0.0;
static double s_ptArc[DRAW_TEACH_MAX_POINTS];

static double s_done = 0.0;
static double s_v    = 0.0;
static int8_t s_span = 0;
static double s_u    = 0.0;

static double s_mFrom[3], s_mTo[3];
static double s_mLen = 0.0, s_mDone = 0.0, s_mV = 0.0;
static int8_t s_nextAfterMove = DRAW_PHASE_IDLE;

enum { AFTER_HOME_IDLE = 0, AFTER_HOME_TRAVEL, AFTER_HOME_TEACH };

static double s_homeTarget[3] = { 0.0, 0.0, 0.0 };
static int8_t s_afterHome = AFTER_HOME_IDLE;

#define DRAW_STALL_LIMIT 500
static int    s_stallCount = 0;

static unsigned long s_pathStartMs = 0UL;
static unsigned long s_lastRunMs   = 0UL;
static int8_t s_hitCount  = 0;
static int8_t s_hitTotal  = 0;
static uint8_t s_ptHit = 0;

static unsigned long s_teachWaitMs = 0UL;
static unsigned long s_jogLastMs[4] = { 0UL, 0UL, 0UL, 0UL };

static inline bool pointOk(double x, double y, double z,
                           double *b, double *r, double *c) {
  return pathCorePointOk(x, y, z, b, r, c);
}

static inline void setJoints(double b, double r, double c) {
  pathCoreSetJoints(b, r, c);
}

static double clampDouble(double v, double lo, double hi)
{
  if (v < lo) return lo;
  if (v > hi) return hi;
  return v;
}

static double dist3(const double *a, const double *b)
{
  double dx = a[0] - b[0];
  double dy = a[1] - b[1];
  double dz = a[2] - b[2];
  return sqrt(dx * dx + dy * dy + dz * dz);
}

static int shapeTable(int task, const struct drawVertex **tbl)
{
  switch (task) {
    case DRAW_TASK_LINE:     *tbl = SHAPE_LINE;     return 2;
    case DRAW_TASK_N:        *tbl = SHAPE_N;        return 4;
    case DRAW_TASK_TRIANGLE: *tbl = SHAPE_TRIANGLE; return 4;
    case DRAW_TASK_Z:        *tbl = SHAPE_Z;        return 4;
    case DRAW_TASK_V:        *tbl = SHAPE_V;        return 3;
    default:                 *tbl = NULL;           return 0;
  }
}

static void buildShapePath(int task)
{
  const struct drawVertex *tbl = NULL;
  int n = shapeTable(task, &tbl);
  if (n > DRAW_TEACH_MAX_POINTS) n = DRAW_TEACH_MAX_POINTS;

  s_ptCount = (int8_t)n;
  s_curved  = false;
  s_isTeach = false;
  for (int i = 0; i < n; i++) {
    s_pts[i][0] = s_centerX + pgm_read_float(&tbl[i].u) * s_half;
    s_pts[i][1] = s_centerY + pgm_read_float(&tbl[i].v) * s_half;
    s_pts[i][2] = s_penZ;
  }
}

static double knotDelta(int a, int b)
{
  double d = dist3(s_pts[a], s_pts[b]);
  if (d < 1e-6) return 0.001;
  return sqrt(d);
}

static void curveSpan(int span, double u, double *p, double *d)
{
  int n = s_ptCount;
  int i = span;
  double dt = knotDelta(i, i + 1);

  double t1[3], t2[3];
  if (i == 0) {
    for (int k = 0; k < 3; k++) t1[k] = (s_pts[1][k] - s_pts[0][k]) / dt * dt;
  } else {
    double sum = knotDelta(i - 1, i) + dt;
    for (int k = 0; k < 3; k++) t1[k] = (s_pts[i + 1][k] - s_pts[i - 1][k]) / sum * dt;
  }
  if (i + 1 == n - 1) {
    for (int k = 0; k < 3; k++) t2[k] = (s_pts[n - 1][k] - s_pts[n - 2][k]) / dt * dt;
  } else {
    double sum = dt + knotDelta(i + 1, i + 2);
    for (int k = 0; k < 3; k++) t2[k] = (s_pts[i + 2][k] - s_pts[i][k]) / sum * dt;
  }

  double u2 = u * u;
  double u3 = u2 * u;
  double h01 = -2.0 * u3 + 3.0 * u2;
  double h00 =  1.0 - h01;
  double h10 =         u3 - 2.0 * u2 + u;
  double h11 =         u3 -       u2;
  double g10 =  3.0 * u2 - 4.0 * u + 1.0;
  double g11 =  3.0 * u2 - 2.0 * u;
  double e0  =  6.0 * u2 - 6.0 * u;
  double e1  = -e0;

  for (int k = 0; k < 3; k++) {
    double a0 = s_pts[i][k];
    double a1 = s_pts[i + 1][k];
    p[k] = h00 * a0 + h10 * t1[k] + h01 * a1 + h11 * t2[k];
    d[k] = e0 * a0 + g10 * t1[k] + e1 * a1 + g11 * t2[k];
  }
}

static void curvePoint(int span, double u, double *p)
{
  double d[3];
  curveSpan(span, u, p, d);
}

static double curveSpeed(int span, double u)
{
  double p[3], d[3];
  curveSpan(span, u, p, d);
  return sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]);
}

static void curveMeasure(void)
{
  const int SAMPLE_PER_SPAN = 64;
  double len = 0.0;
  double prev[3];
  curvePoint(0, 0.0, prev);

  s_ptArc[0] = 0.0;
  for (int span = 0; span < s_ptCount - 1; span++) {
    for (int k = 1; k <= SAMPLE_PER_SPAN; k++) {
      double u = (double)k / (double)SAMPLE_PER_SPAN;
      double cur[3];
      curvePoint(span, u, cur);
      len += dist3(prev, cur);
      prev[0] = cur[0]; prev[1] = cur[1]; prev[2] = cur[2];
    }
    s_ptArc[span + 1] = len;
  }
  s_totalLen = len;
}

static void polyMeasure(void)
{
  double acc = 0.0;
  s_ptArc[0] = 0.0;
  for (int i = 0; i < s_ptCount - 1; i++) {
    acc += dist3(s_pts[i], s_pts[i + 1]);
    s_ptArc[i + 1] = acc;
  }
  s_totalLen = acc;
}

static void measurePath(void)
{
  if (s_curved) curveMeasure();
  else          polyMeasure();
}

static double liftZFor(const double *pt)
{
  double z = pt[2] + DRAW_LIFT_DZ;
  while (z > pt[2]) {
    if (pointOk(pt[0], pt[1], z, NULL, NULL, NULL)) return z;
    z -= 0.5;
  }
  return pt[2];
}

static bool validatePath(void)
{
  if (s_ptCount < 2) return false;

  SER home;
  home = Pos.ser;
  if (!posGetHomeAngles(&home)) return false;
  REC hrec;
  if (!recFromServo(&hrec, &home)) return false;

  double lz = liftZFor(s_pts[0]);
  double hp[3];
  hp[0] = hrec.x; hp[1] = hrec.y; hp[2] = hrec.z;
  double ap[3];
  ap[0] = s_pts[0][0]; ap[1] = s_pts[0][1]; ap[2] = lz;
  if (!pathCoreSegmentOk(hp, ap, DRAW_PATH_SAMPLE_STEP,
                         DRAW_PATH_SAMPLE_MAX, DRAW_BRANCH_JUMP_DEG)) return false;

  if (!pathCoreSegmentOk(ap, s_pts[0], DRAW_PATH_SAMPLE_STEP,
                         DRAW_PATH_SAMPLE_MAX, DRAW_BRANCH_JUMP_DEG)) {
    return false;
  }

  if (s_curved) {
    const int SAMPLE_PER_SPAN = 24;
    double prevB = 0.0, prevR = 0.0, prevC = 0.0;
    bool first = true;
    for (int span = 0; span < s_ptCount - 1; span++) {
      for (int k = 0; k <= SAMPLE_PER_SPAN; k++) {
        double u = (double)k / (double)SAMPLE_PER_SPAN;
        double p[3];
        curvePoint(span, u, p);
        double b = 0.0, r = 0.0, c = 0.0;
        if (!pointOk(p[0], p[1], p[2], &b, &r, &c)) return false;
        if (!first) {
          if (fabs(b - prevB) > DRAW_BRANCH_JUMP_DEG ||
              fabs(r - prevR) > DRAW_BRANCH_JUMP_DEG ||
              fabs(c - prevC) > DRAW_BRANCH_JUMP_DEG) {
            return false;
          }
        }
        prevB = b; prevR = r; prevC = c;
        first = false;
      }
    }
  } else {
    for (int i = 0; i < s_ptCount - 1; i++) {
      if (!pathCoreSegmentOk(s_pts[i], s_pts[i + 1], DRAW_PATH_SAMPLE_STEP,
                             DRAW_PATH_SAMPLE_MAX, DRAW_BRANCH_JUMP_DEG)) {
        return false;
      }
    }
  }

  const double *last = s_pts[s_ptCount - 1];
  double ez = liftZFor(last);
  double ep[3];
  ep[0] = last[0]; ep[1] = last[1]; ep[2] = ez;
  if (!pathCoreSegmentOk(last, ep, DRAW_PATH_SAMPLE_STEP,
                         DRAW_PATH_SAMPLE_MAX, DRAW_BRANCH_JUMP_DEG)) {
    return false;
  }
  return true;
}

static double applyDtSec(void)
{
  unsigned long now = millis();
  double dt = (double)(now - s_applyMs) / 1000.0;
  if (dt > 0.1) dt = 0.1;
  if (dt < 0.005) dt = 0.005;
  return dt;
}

static bool applyPointStep(double x, double y, double z, double maxDps, double dtSec, int mode)
{
  const double goal[3] = { x, y, z };
  if (moveToPoint(goal, 0x07u, maxDps, dtSec, mode) != MOVE_XYZ_OK) return false;
  s_applyMs = millis();
  return true;
}

static double speedLimit(double done, double total, double vCur, double dt)
{
  double remain = total - done;
  if (remain < 0.0) remain = 0.0;

  double vEnd = sqrt(2.0 * DRAW_ACCEL * remain);
  if (vEnd > DRAW_V_MAX) vEnd = DRAW_V_MAX;

  double vRamp = vCur + DRAW_ACCEL * dt;
  double v = (vRamp < vEnd) ? vRamp : vEnd;
  if (v < 0.0) v = 0.0;
  return v;
}

static bool stallGuard(double movedNow)
{
  if (movedNow > 1e-6) {
    s_stallCount = 0;
    return false;
  }
  s_stallCount++;
  if (s_stallCount > DRAW_STALL_LIMIT) {
#if DRAW_DEBUG_SERIAL
    Serial.println(F("[draw] 无法继续前进（关节速率或可达性受限），放弃本次绘图"));
#endif
    s_stallCount = 0;
    s_paused = false;
    s_phase  = DRAW_PHASE_IDLE;
    s_lastRes = PROTO_RES_DRAW_REJECTED;
    return true;
  }
  return false;
}

static void loadHomeTarget(void)
{
  SER ser = Pos.ser;
  if (!posGetHomeAngles(&ser)) ser = Pos.ser;
  s_homeTarget[0] = ser.angle1;
  s_homeTarget[1] = ser.angle2;
  s_homeTarget[2] = ser.angle3;
}

static void beginHome(int after, int phase)
{
  loadHomeTarget();
  s_afterHome  = (int8_t)after;
  s_stallCount = 0;
  s_applyMs    = millis();
  s_phase = (int8_t)phase;
}

static void beginMove(int next, double x, double y, double z)
{
  s_mFrom[0] = Pos.rec.x;
  s_mFrom[1] = Pos.rec.y;
  s_mFrom[2] = Pos.rec.z;
  s_mTo[0] = x;
  s_mTo[1] = y;
  s_mTo[2] = z;
  s_mLen  = dist3(s_mFrom, s_mTo);
  s_mDone = 0.0;
  s_mV    = 0.0;
  s_applyMs = millis();
  s_nextAfterMove = (int8_t)next;
}

static void beginSequence(void)
{
  s_paused  = false;
  s_done    = 0.0;
  s_v       = 0.0;
  s_span    = 0;
  s_u       = 0.0;
  s_hitCount = 0;
  s_hitTotal = s_isTeach ? s_ptCount : 0;
  s_ptHit = 0;

  beginHome(AFTER_HOME_TRAVEL, DRAW_PHASE_HOME);
}

static bool homeTick(void)
{
  double maxStep = DRAW_HOME_DPS * s_dtSec;
  if (maxStep < 0.2) maxStep = 0.2;

  double tgt[3], cur[3], d[3];
  tgt[0] = s_homeTarget[0]; tgt[1] = s_homeTarget[1]; tgt[2] = s_homeTarget[2];
  cur[0] = Pos.ser.angle1;  cur[1] = Pos.ser.angle2;  cur[2] = Pos.ser.angle3;

  bool atHome = true;
  for (int i = 0; i < 3; i++) {
    d[i] = tgt[i] - cur[i];
    if (fabs(d[i]) > DRAW_HOME_TOL_DEG) atHome = false;
  }

  if (atHome) {
    setJoints(tgt[0], tgt[1], tgt[2]);
    return true;
  }

  setJoints(cur[0] + clampDouble(d[0], -maxStep, maxStep),
            cur[1] + clampDouble(d[1], -maxStep, maxStep),
            cur[2] + clampDouble(d[2], -maxStep, maxStep));
  return false;
}

static bool moveTick(void)
{
  if (s_mLen < 1e-6) return true;

  double v = speedLimit(s_mDone, s_mLen, s_mV, s_dtSec);
  double step = v * s_dtSec;
  if (step > s_mLen - s_mDone) step = s_mLen - s_mDone;

  double t = (s_mDone + step) / s_mLen;
  double x = s_mFrom[0] + (s_mTo[0] - s_mFrom[0]) * t;
  double y = s_mFrom[1] + (s_mTo[1] - s_mFrom[1]) * t;
  double z = s_mFrom[2] + (s_mTo[2] - s_mFrom[2]) * t;

  if (!applyPointStep(x, y, z, DRAW_MAX_DPS, applyDtSec(), MOVE_XYZ_TRACK)) {
    return false;
  }

  s_mDone += step;
  s_mV = (s_dtSec > 1e-6) ? (step / s_dtSec) : 0.0;
  return (s_mDone >= s_mLen - 1e-6);
}

static void polyPointAt(double s, double *px, double *py, double *pz)
{
  if (s <= 0.0) {
    *px = s_pts[0][0]; *py = s_pts[0][1]; *pz = s_pts[0][2];
    return;
  }
  double acc = 0.0;
  for (int i = 0; i < s_ptCount - 1; i++) {
    bool last = (i == s_ptCount - 2);
    double seg = dist3(s_pts[i], s_pts[i + 1]);
    if (s <= acc + seg || last) {
      double t = (seg > 1e-9) ? (s - acc) / seg : 1.0;
      t = clampDouble(t, 0.0, 1.0);
      *px = s_pts[i][0] + (s_pts[i + 1][0] - s_pts[i][0]) * t;
      *py = s_pts[i][1] + (s_pts[i + 1][1] - s_pts[i][1]) * t;
      *pz = s_pts[i][2] + (s_pts[i + 1][2] - s_pts[i][2]) * t;
      return;
    }
    acc += seg;
  }
}

static bool pathAdvance(double step)
{
  if (step <= 0.0) return true;
  if (step > s_totalLen - s_done) step = s_totalLen - s_done;

  double tryStep = step;
  for (int attempt = 0; attempt < 4; attempt++) {
    double p[3] = { 0.0, 0.0, 0.0 };
    int    nspan = s_span;
    double nu    = s_u;

    if (s_curved) {
      double sp = curveSpeed(s_span, s_u);
      double du = (sp > 1e-6) ? (tryStep / sp) : 1.0;
      nu = s_u + du;
      while (nu >= 1.0 && nspan < s_ptCount - 2) { nu -= 1.0; nspan++; }
      if (nu > 1.0) nu = 1.0;
      curvePoint(nspan, nu, p);
    } else {
      polyPointAt(s_done + tryStep, &p[0], &p[1], &p[2]);
    }

    if (applyPointStep(p[0], p[1], p[2], DRAW_MAX_DPS, applyDtSec(), MOVE_XYZ_TRACK)) {
      s_done += tryStep;
      s_span  = (int8_t)nspan;
      s_u     = nu;
      s_v     = (s_dtSec > 1e-6) ? (tryStep / s_dtSec) : 0.0;
      return true;
    }
    tryStep *= 0.5;
  }
  return false;
}

static void pathTick(void)
{
  double remain = s_totalLen - s_done;
  double v = speedLimit(s_done, s_totalLen, s_v, s_dtSec);
  double step = v * s_dtSec;
  if (step > remain) step = remain;

  if (step > DRAW_STEP_MAX) step = DRAW_STEP_MAX;
  (void) pathAdvance(step);

  for (int i = 0; i < s_ptCount; i++) {
    uint8_t bit = (uint8_t)(1u << i);
    if (s_ptHit & bit) continue;
    if (s_done + 1e-6 < s_ptArc[i]) continue;
    double dx = Pos.rec.x - s_pts[i][0];
    double dy = Pos.rec.y - s_pts[i][1];
    double dz = Pos.rec.z - s_pts[i][2];
    if (sqrt(dx * dx + dy * dy + dz * dz) <= DRAW_POINT_TOL) {
      s_ptHit |= bit;
      s_hitCount++;
    }
  }
}

static void beginLift(double z)
{
  beginMove(DRAW_PHASE_LIFT, Pos.rec.x, Pos.rec.y, z);
}

static void beginLiftToReturn(void)
{
  double lz = Pos.rec.z + DRAW_LIFT_DZ;
  if (!pointOk(Pos.rec.x, Pos.rec.y, lz, NULL, NULL, NULL)) lz = Pos.rec.z;
  beginLift(lz);
  s_nextAfterMove = DRAW_PHASE_RETURN;
  s_phase = DRAW_PHASE_LIFT;
}

static void teachJogTick(void)
{
  struct joyState st;
  joystickReadState(&st);

  unsigned long now = millis();
  const int amp[4]   = { st.base, st.shoulder, st.elbow, st.tool };
  const int raw[4]   = { st.sx,   st.sy,        st.ty,      st.tx };

  for (int i = 0; i < 4; i++) {
    if (amp[i] <= 0) continue;
#if !DRAW_JOG_TOOL_ENABLE
    if (i == 3) continue;
#endif
    int interval = speed.stepDelayMs;
    if (now - s_jogLastMs[i] < (unsigned long)interval) continue;
    s_jogLastMs[i] = now;

    int sign = (raw[i] > DRAW_JOG_CENTER) ? 1 : -1;

    if (i == 3) {
      double deg = speed.stepSize * DRAW_JOG_SCALE *
                   ((double)amp[i] / (double)DRAW_JOG_CENTER);
      if (deg < 0.05) deg = 0.05;
      (void) posSetAngle4(Pos.ser.angle4 - (double)sign * deg);
      continue;
    }

    double step = DRAW_JOG_STEP_MAX * ((double)amp[i] / (double)DRAW_JOG_CENTER);
    if (step < DRAW_JOG_STEP_MIN) step = DRAW_JOG_STEP_MIN;

    double nx = Pos.rec.x;
    double ny = Pos.rec.y;
    double nz = Pos.rec.z;
    if (i == 0) {
      int dir = DRAW_JOG_INVERT_X ? -sign : sign;
      nx += (double)dir * step;
    } else if (i == 1) {
      int dir = DRAW_JOG_INVERT_Y ? -sign : sign;
      ny += (double)dir * step;
    } else {
      int dir = DRAW_JOG_INVERT_Z ? sign : -sign;
      nz += (double)dir * step;
    }

    if (!applyPointStep(nx, ny, nz, DRAW_JOG_MAX_DPS, (double)interval / 1000.0, MOVE_XYZ_JOG)) {
#if DRAW_DEBUG_SERIAL
      Serial.println(F("[draw] 点动被挡：该方向不可达或超出工作空间"));
#endif
    }
  }
}

static int teachRecord(void)
{
  if (s_ptCount >= DRAW_TEACH_MAX_POINTS) return PROTO_RES_BUSY;

  s_pts[s_ptCount][0] = Pos.rec.x;
  s_pts[s_ptCount][1] = Pos.rec.y;
  s_pts[s_ptCount][2] = Pos.rec.z;
  s_ptCount++;

#if DRAW_DEBUG_SERIAL
  Serial.print(F("[draw] 记录示教点 "));
  Serial.print((int)s_ptCount);
  Serial.print(F("/"));
  Serial.print(DRAW_TEACH_MAX_POINTS);
  Serial.print(F("  x="));
  Serial.print(s_pts[s_ptCount - 1][0], 2);
  Serial.print(F(" y="));
  Serial.print(s_pts[s_ptCount - 1][1], 2);
  Serial.print(F(" z="));
  Serial.println(s_pts[s_ptCount - 1][2], 2);
#endif

  if (s_ptCount >= DRAW_TEACH_MAX_POINTS) {
    s_teachWaitMs = millis();
    s_phase = DRAW_PHASE_TEACH_WAIT;
  }
  return PROTO_RES_DRAW_TEACH_POINT;
}

static int teachFinish(void)
{
  if (s_ptCount < 2) return PROTO_RES_DRAW_REJECTED;

  s_curved = (s_task == DRAW_TASK_CURVE);
  measurePath();
  if (!validatePath()) {
#if DRAW_DEBUG_SERIAL
    Serial.println(F("[draw] 轨迹校验失败，拒绝开始绘制"));
#endif
    return PROTO_RES_DRAW_REJECTED;
  }
  beginSequence();
  return PROTO_RES_DRAW_STARTED;
}

void drawSetup(void)
{
  s_task   = DRAW_TASK_LINE;
  s_phase  = DRAW_PHASE_IDLE;
  s_paused = false;
  s_lastMs = millis();
  s_applyMs = s_lastMs;
  s_lastRes = PROTO_RES_NONE;
  s_ptCount = 0;
  s_curved  = false;
  s_isTeach = false;

#if DRAW_DEBUG_SERIAL
  Serial.println(F("[draw] 绘图模块就绪（铅笔固定方案）："));
  Serial.print(F("[draw]   当前任务 "));
  Serial.print(DRAW_TASK_NAME[s_task]);
  Serial.print(F("，纸面 z="));
  Serial.print(s_penZ, 2);
  Serial.print(F("，中心 ("));
  Serial.print(s_centerX, 2);
  Serial.print(F(","));
  Serial.print(s_centerY, 2);
  Serial.print(F(")，半宽 "));
  Serial.println(s_half, 2);
  Serial.println(F("[draw]   按键: 示教中 1=记录 2=撤销 3=取消 4=开始；绘制中 1=暂停 2=继续 3=取消"));
  Serial.println(F("[draw]   串口: F 换任务  D 开始  G 记录  E 撤销  Q 暂停  U 继续  W 取消"));
  Serial.println(F("[draw]   标定: p<纸面高>  n<半宽>  o<中心x>,<中心y>"));
#endif
}

int drawSelectTask(int task)
{
  if (task < 0 || task >= DRAW_TASK_COUNT) return -1;
  if (s_phase != DRAW_PHASE_IDLE) return -1;
  s_task = (int8_t)task;
  return s_task;
}

int drawTaskCycle(void)
{
  if (s_phase != DRAW_PHASE_IDLE) return -1;
  s_task = (int8_t)((s_task + 1) % DRAW_TASK_COUNT);
  return s_task;
}

int drawGetTask(void) { return s_task; }

const char *drawTaskName(int task)
{
  if (task < 0 || task >= DRAW_TASK_COUNT) return "未知";
  return DRAW_TASK_NAME[task];
}

const char *drawTaskTag(int task)
{
  if (task < 0 || task >= DRAW_TASK_COUNT) return "?";
  return DRAW_TASK_TAG[task];
}

int drawStartTask(void)
{
  s_lastRes = PROTO_RES_BUSY;

  if (s_phase != DRAW_PHASE_IDLE) {
#if DRAW_DEBUG_SERIAL
    Serial.println(F("[draw] 忙：先取消当前绘图任务再开始新的"));
#endif
    return PROTO_RES_BUSY;
  }
  if (pickPlaceIsBusy() || buttonControlBusy()) {
#if DRAW_DEBUG_SERIAL
    Serial.println(F("[draw] 忙：取放序列或按键录制/播放/回中正在进行"));
#endif
    return PROTO_RES_BUSY;
  }

  s_paused  = false;
  s_isTeach = (s_task == DRAW_TASK_POLYLINE || s_task == DRAW_TASK_CURVE);

  if (s_isTeach) {
    s_ptCount = 0;
    s_curved  = (s_task == DRAW_TASK_CURVE);
    beginHome(AFTER_HOME_TEACH, DRAW_PHASE_HOME);
#if DRAW_DEBUG_SERIAL
    Serial.print(F("[draw] 进入示教（"));
    Serial.print(DRAW_TASK_NAME[s_task]);
    Serial.print(F("），用摇杆把笔尖移到目标点，按键1 记录，共 "));
    Serial.print(DRAW_TEACH_MAX_POINTS);
    Serial.println(F(" 个点"));
#endif
    s_lastRes = PROTO_RES_DRAW_STARTED;
    return PROTO_RES_DRAW_STARTED;
  }

  buildShapePath(s_task);
  measurePath();
  if (!validatePath()) {
#if DRAW_DEBUG_SERIAL
    Serial.println(F("[draw] 轨迹校验失败，拒绝开始绘制"));
#endif
    s_lastRes = PROTO_RES_DRAW_REJECTED;
    return PROTO_RES_DRAW_REJECTED;
  }
  beginSequence();
#if DRAW_DEBUG_SERIAL
  Serial.print(F("[draw] 开始绘制 "));
  Serial.print(DRAW_TASK_NAME[s_task]);
  Serial.print(F("：总弧长 "));
  Serial.print(s_totalLen, 2);
  Serial.println(F(" 单位"));
#endif
  s_lastRes = PROTO_RES_DRAW_STARTED;
  return PROTO_RES_DRAW_STARTED;
}

int drawTeachRecord(void)
{
  if (s_phase != DRAW_PHASE_TEACH) {
    s_lastRes = PROTO_RES_BUSY;
    return PROTO_RES_BUSY;
  }
  s_lastRes = teachRecord();
  return s_lastRes;
}

int drawTeachUndo(void)
{
  if (s_phase != DRAW_PHASE_TEACH || s_ptCount <= 0) {
    s_lastRes = PROTO_RES_DRAW_REJECTED;
    return PROTO_RES_DRAW_REJECTED;
  }
  s_ptCount--;
#if DRAW_DEBUG_SERIAL
  Serial.print(F("[draw] 撤销一个示教点，剩 "));
  Serial.println((int)s_ptCount);
#endif
  s_lastRes = PROTO_RES_DRAW_TEACH_UNDO;
  return PROTO_RES_DRAW_TEACH_UNDO;
}

int drawTeachFinish(void)
{
  if (s_phase != DRAW_PHASE_TEACH && s_phase != DRAW_PHASE_TEACH_WAIT) {
    s_lastRes = PROTO_RES_BUSY;
    return PROTO_RES_BUSY;
  }
  s_lastRes = teachFinish();
  return s_lastRes;
}

int drawTeachCount(void) { return s_ptCount; }

int drawPause(void)
{
  if (s_phase == DRAW_PHASE_IDLE || s_phase == DRAW_PHASE_TEACH ||
      s_phase == DRAW_PHASE_TEACH_WAIT) {
    s_lastRes = PROTO_RES_BUSY;
    return PROTO_RES_BUSY;
  }
  s_paused = true;
#if DRAW_DEBUG_SERIAL
  Serial.println(F("[draw] 已暂停（按键2 继续，按键3 取消）"));
#endif
  s_lastRes = PROTO_RES_DRAW_PAUSED;
  return PROTO_RES_DRAW_PAUSED;
}

int drawResume(void)
{
  if (!s_paused) {
    s_lastRes = PROTO_RES_BUSY;
    return PROTO_RES_BUSY;
  }
  s_paused = false;
  s_v      = 0.0;
  s_mV     = 0.0;
#if DRAW_DEBUG_SERIAL
  Serial.println(F("[draw] 继续绘制"));
#endif
  s_lastRes = PROTO_RES_DRAW_RESUMED;
  return PROTO_RES_DRAW_RESUMED;
}

int drawCancel(void)
{
  if (s_phase == DRAW_PHASE_IDLE) {
    s_lastRes = PROTO_RES_BUSY;
    return PROTO_RES_BUSY;
  }
  s_paused = false;

  if (s_phase == DRAW_PHASE_TEACH || s_phase == DRAW_PHASE_TEACH_WAIT) {
    s_ptCount = 0;
    beginHome(AFTER_HOME_IDLE, DRAW_PHASE_HOME);
  } else {
    beginLiftToReturn();
  }
#if DRAW_DEBUG_SERIAL
  Serial.println(F("[draw] 已取消：抬笔后回待机"));
#endif
  s_lastRes = PROTO_RES_DRAW_CANCELED;
  return PROTO_RES_DRAW_CANCELED;
}

bool drawSetPaperZ(double z)
{
  if (z != z) return false;
  if (z < DRAW_PEN_Z_MIN || z > DRAW_PEN_Z_MAX) return false;
  s_penZ = z;
  return true;
}
double drawGetPaperZ(void) { return s_penZ; }

bool drawSetHalfSize(double half)
{
  if (half != half) return false;
  if (half < DRAW_HALF_MIN || half > DRAW_HALF_MAX) return false;
  s_half = half;
  return true;
}
double drawGetHalfSize(void) { return s_half; }

bool drawSetCenter(double x, double y)
{
  if (x != x || y != y) return false;
  if (fabs(x) > DRAW_CENTER_LIMIT || fabs(y) > DRAW_CENTER_LIMIT) return false;
  s_centerX = x;
  s_centerY = y;
  return true;
}
double drawGetCenterX(void) { return s_centerX; }
double drawGetCenterY(void) { return s_centerY; }

int drawHandleButton(int key)
{
  switch (key) {
    case DRAW_KEY_1:
      if (s_phase == DRAW_PHASE_TEACH)  return drawTeachRecord();
      if (s_phase == DRAW_PHASE_TEACH_WAIT) return PROTO_RES_BUSY;
      return drawPause();
    case DRAW_KEY_2:
      if (s_phase == DRAW_PHASE_TEACH)  return drawTeachUndo();
      if (s_phase == DRAW_PHASE_TEACH_WAIT) return PROTO_RES_BUSY;
      return drawResume();
    case DRAW_KEY_3:
      return drawCancel();
    case DRAW_KEY_4:
      if (s_phase == DRAW_PHASE_TEACH || s_phase == DRAW_PHASE_TEACH_WAIT) {
        return drawTeachFinish();
      }
#if DRAW_DEBUG_SERIAL
      Serial.println(F("[draw] 绘制中按键4 无动作（按键1 暂停 / 2 继续 / 3 取消）"));
#endif
      return PROTO_RES_BUSY;
    default:
      return PROTO_RES_UNKNOWN;
  }
}

bool drawAcceptButton(int key)
{
  (void) key;
  return (s_phase != DRAW_PHASE_IDLE);
}

bool drawIsCommandChar(char c)
{
  return (c == 'F' || c == 'D' || c == 'G' || c == 'E' ||
          c == 'Q' || c == 'U' || c == 'W' ||
          c == 'p' || c == 'n' || c == 'o');
}

int drawHandleCommand(char c)
{
  switch (c) {
    case 'F': {
      int t = drawTaskCycle();
      if (t < 0) {
        s_lastRes = PROTO_RES_BUSY;
        return PROTO_RES_BUSY;
      }
#if DRAW_DEBUG_SERIAL
      Serial.print(F("[draw] 当前任务 -> "));
      Serial.println(DRAW_TASK_NAME[t]);
#endif
      s_lastRes = PROTO_RES_DRAW_TASK_SELECTED;
      return PROTO_RES_DRAW_TASK_SELECTED;
    }
    case 'D':
      return drawStartTask();
    case 'G':
      return drawTeachRecord();
    case 'E':
      return drawTeachUndo();
    case 'Q':
      return drawPause();
    case 'U':
      return drawResume();
    case 'W':
      return drawCancel();
    default:
      return PROTO_RES_UNKNOWN;
  }
}

bool drawControlBusy(void)  { return (s_phase != DRAW_PHASE_IDLE); }
bool drawControlLocked(void) { return (s_phase != DRAW_PHASE_IDLE); }
int  drawGetPhase(void)     { return s_phase; }
bool drawIsPaused(void)     { return s_paused; }

const char *drawPhaseName(void)
{
  if (s_phase < 0 || s_phase > DRAW_PHASE_RETURN) return "未知";
  return DRAW_PHASE_NAME[s_phase];
}

const char *drawStateName(void)
{
  if (s_phase == DRAW_PHASE_IDLE) return "空闲";
  if (s_phase == DRAW_PHASE_TEACH) return "示教中";
  if (s_phase == DRAW_PHASE_TEACH_WAIT) return "准备绘制";
  if (s_paused) return "已暂停";
  return DRAW_PHASE_NAME[s_phase];
}

unsigned long drawLastRunMs(void) { return s_lastRunMs; }
int drawLastPointsHit(void)   { return s_hitCount; }
int drawLastPointsTotal(void) { return s_hitTotal; }
int drawLastResult(void)      { return s_lastRes; }

void drawLoop(void)
{
  unsigned long now = millis();
  unsigned long dtMs = now - s_lastMs;
  if (dtMs == 0UL) return;
  s_lastMs = now;
  if (dtMs > DRAW_TICK_MAX_MS) dtMs = DRAW_TICK_MAX_MS;
  s_dtSec = (double)dtMs / 1000.0;

  if (s_phase == DRAW_PHASE_IDLE) return;

  if (s_phase == DRAW_PHASE_TEACH) {
    teachJogTick();
    return;
  }

  if (s_phase == DRAW_PHASE_TEACH_WAIT) {
    if (now - s_teachWaitMs >= DRAW_TEACH_START_DELAY_MS) {
      s_lastRes = teachFinish();
      if (s_lastRes != PROTO_RES_DRAW_STARTED) {
        s_phase = DRAW_PHASE_IDLE;
      }
    }
    return;
  }

  if (s_paused) return;

  switch (s_phase) {
    case DRAW_PHASE_HOME: {
      if (homeTick()) {
        if (s_afterHome == AFTER_HOME_TEACH) {
          s_phase = DRAW_PHASE_TEACH;
        } else if (s_afterHome == AFTER_HOME_IDLE) {
          s_phase = DRAW_PHASE_IDLE;
        } else {
          double lz = liftZFor(s_pts[0]);
          beginMove(DRAW_PHASE_PLUNGE, s_pts[0][0], s_pts[0][1], lz);
          s_phase = DRAW_PHASE_TRAVEL;
        }
      }
      break;
    }

    case DRAW_PHASE_TRAVEL:
    case DRAW_PHASE_PLUNGE:
    case DRAW_PHASE_LIFT: {
      double px = Pos.rec.x, py = Pos.rec.y, pz = Pos.rec.z;
      bool arrived = moveTick();
      double moved = fabs(Pos.rec.x - px) + fabs(Pos.rec.y - py) + fabs(Pos.rec.z - pz);
      if (!arrived) {
        (void) stallGuard(moved);
        break;
      }
      if (s_phase == DRAW_PHASE_TRAVEL) {
        beginMove(DRAW_PHASE_PATH, s_pts[0][0], s_pts[0][1], s_pts[0][2]);
        s_phase = DRAW_PHASE_PLUNGE;
      } else if (s_phase == DRAW_PHASE_PLUNGE) {
        s_done = 0.0;
        s_v    = 0.0;
        s_span = 0;
        s_u    = 0.0;
        s_stallCount = 0;
        s_pathStartMs = millis();
        s_phase = DRAW_PHASE_PATH;
      } else {
        if (s_nextAfterMove == DRAW_PHASE_RETURN) {
          beginHome(AFTER_HOME_IDLE, DRAW_PHASE_RETURN);
        } else {
          s_phase = s_nextAfterMove;
        }
      }
      break;
    }

    case DRAW_PHASE_PATH: {
      double doneBefore = s_done;
      pathTick();
      if (stallGuard(s_done - doneBefore)) break;
      if (s_done >= s_totalLen - 1e-6) {
        s_lastRunMs = millis() - s_pathStartMs;
#if DRAW_DEBUG_SERIAL
        Serial.print(F("[draw] 绘制完成：用时 "));
        Serial.print(s_lastRunMs);
        Serial.print(F(" ms，笔尖停在 x="));
        Serial.print(Pos.rec.x, 2);
        Serial.print(F(" y="));
        Serial.print(Pos.rec.y, 2);
        Serial.print(F(" z="));
        Serial.println(Pos.rec.z, 2);
        if (s_isTeach) {
          Serial.print(F("[draw] 过点 "));
          Serial.print((int)s_hitCount);
          Serial.print(F("/"));
          Serial.println((int)s_hitTotal);
        }
#endif
        beginLiftToReturn();
      }
      break;
    }

    case DRAW_PHASE_RETURN: {
      if (homeTick()) {
#if DRAW_DEBUG_SERIAL
        Serial.println(F("[draw] 已回到待机位，绘图任务结束"));
#endif
        s_phase = DRAW_PHASE_IDLE;
      }
      break;
    }

    default:
      s_phase = DRAW_PHASE_IDLE;
      break;
  }
}

#endif
