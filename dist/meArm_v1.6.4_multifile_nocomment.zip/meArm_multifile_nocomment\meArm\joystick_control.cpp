#include "Arduino.h"
#include "constant_and_positions.h"
#include "move.h"
#include "joystick_control.h"
#include "pick_place.h"
#include "button_control.h"
#include "draw_control.h"

#include "weArm_config.h"
#define WEARM_JOY_DEBUG    0
#define WEARM_HAVE_BUTTONS 0

#if WEARM_DEBUG_SERIAL
  #define JLOG(msg)   Serial.println(F(msg))
#else
  #define JLOG(msg)   ((void)0)
#endif

#define JOY_LX_PIN     A0
#define JOY_LY_PIN     A1
#define JOY_RX_PIN     A2
#define JOY_RY_PIN     A3

#define PIN_LED_MODE   13

#define JOY_CENTER     512
#define JOY_DEADZONE   40
#define JOY_FULL_SCALE 500

#define JOY_CAL_SAMPLES  32
#define JOY_CAL_MAX_OFF 80

#define JOY_STEP_MIN_DEG 0.1

#define JOY_HYST 25
#define JOY_TRACK_MS 20

#define JOY_BTN_DEBOUNCE_MS 30
#define LED_FAST_MS    100

enum JointIdx { JIDX_BASE = 0, JIDX_SHOULDER, JIDX_ELBOW, JIDX_TOOL, JIDX_COUNT };

static const unsigned char JOY_DIR_NEG[JIDX_COUNT] PROGMEM = {
  (unsigned char)JOINT_B_LEFT,
  (unsigned char)JOINT_R_FWD,
  (unsigned char)JOINT_C_UP,
  0
};

#ifdef __AVR__
#define JOY_DIRNEG(i) ((int)pgm_read_byte(&JOY_DIR_NEG[(i)]))
#else
#define JOY_DIRNEG(i) ((int)JOY_DIR_NEG[(i)])
#endif

static const unsigned char JOY_RAW_SLOT[JIDX_COUNT] PROGMEM = { 0, 1, 3, 2 };

#ifdef __AVR__
#define JOY_RAWSLOT(i) ((int)pgm_read_byte(&JOY_RAW_SLOT[(i)]))
#else
#define JOY_RAWSLOT(i) ((int)JOY_RAW_SLOT[(i)])
#endif

static unsigned long lastStepTime[JIDX_COUNT] = { 0, 0, 0, 0 };

static int s_centerOff[4] = { 0, 0, 0, 0 };

static bool          s_axisHot[JIDX_COUNT] = { false, false, false, false };
static unsigned long s_trackMs[JIDX_COUNT] = { 0, 0, 0, 0 };

#if WEARM_DEBUG_SERIAL
static unsigned long lastBlockLogTime = 0;
#endif

#if WEARM_HAVE_BUTTONS
static bool sw1Prev = false;
static bool sw2Prev = false;
static bool sw2LongFired = false;
static unsigned long sw2DownTime = 0;
#endif

static void logBlocked(const __FlashStringHelper *msg) {
#if WEARM_DEBUG_SERIAL
  unsigned long now = millis();
  if (now - lastBlockLogTime < 500) return;
  lastBlockLogTime = now;
  Serial.println(msg);
#else
  (void) msg;
#endif
}

#if WEARM_HAVE_BUTTONS
static bool buttonDown(uint8_t pin) {
  static bool stable[20] = { false };
  static unsigned long changeAt[20] = { 0 };
  if (pin >= 20) return false;

  bool raw = (digitalRead(pin) == LOW);
  if (raw == stable[pin]) return stable[pin];

  unsigned long now = millis();
  if (changeAt[pin] == 0) {
    changeAt[pin] = now;
    return stable[pin];
  }
  if (now - changeAt[pin] >= JOY_BTN_DEBOUNCE_MS) {
    stable[pin] = raw;
    changeAt[pin] = 0;
  }
  return stable[pin];
}
#endif

static void joyCalibrateAxis(uint8_t pin) {
  long sum = 0;
  for (uint8_t i = 0; i < JOY_CAL_SAMPLES; i++) { sum += analogRead(pin); }
  int off = (int)(sum / (long)JOY_CAL_SAMPLES) - JOY_CENTER;
  if (off > JOY_CAL_MAX_OFF || off < -JOY_CAL_MAX_OFF) { off = 0; }
  s_centerOff[pin - A0] = off;
}

static int readAxisAmp(uint8_t pin, int *raw) {
  int idx = pin - A0;
  int v = analogRead(pin) - s_centerOff[idx];
  if (raw != NULL) *raw = v;
  int d = v - JOY_CENTER;
  int a = (d >= 0) ? d : -d;
  int gate = s_axisHot[idx] ? JOY_DEADZONE : (JOY_DEADZONE + JOY_HYST);
  if (a < gate) {
    unsigned long now = millis();
    if ((unsigned long)(now - s_trackMs[idx]) >= (unsigned long)JOY_TRACK_MS) {
      s_trackMs[idx] = now;
      int next = s_centerOff[idx] + ((d > 0) ? 1 : ((d < 0) ? -1 : 0));
      if (next >= -JOY_CAL_MAX_OFF && next <= JOY_CAL_MAX_OFF) { s_centerOff[idx] = next; }
    }
    s_axisHot[idx] = false;
    return 0;
  }
  s_axisHot[idx] = true;
  a -= JOY_DEADZONE;
  return (a > 0) ? a : 0;
}

void joystickReadState(struct joyState *st) {
  if (st == NULL) return;

  st->base     = readAxisAmp(JOY_LX_PIN, &st->sx);
  st->shoulder = readAxisAmp(JOY_LY_PIN, &st->sy);
  st->tool     = readAxisAmp(JOY_RX_PIN, &st->tx);
  st->elbow    = readAxisAmp(JOY_RY_PIN, &st->ty);

  int mask  = 0;
  int mag   = 0;
  int best  = JOY_DIR_NONE;

  if (st->base > 0) {
    mask |= JOY_ACT_BASE;
    if (st->base > mag) {
      mag = st->base;
      best = (st->sx > JOY_CENTER) ? JOY_DIR_RIGHT : JOY_DIR_LEFT;
    }
  }
  if (st->shoulder > 0) {
    mask |= JOY_ACT_SHOULDER;
    if (st->shoulder > mag) {
      mag = st->shoulder;
      best = (st->sy > JOY_CENTER) ? JOY_DIR_BWD : JOY_DIR_FWD;
    }
  }
  if (st->elbow > 0) {
    mask |= JOY_ACT_ELBOW;
    if (st->elbow > mag) {
      mag = st->elbow;
      best = (st->ty > JOY_CENTER) ? JOY_DIR_DOWN : JOY_DIR_UP;
    }
  }
  if (st->tool > 0) {
    mask |= JOY_ACT_TOOL;
    if (st->tool > mag) mag = st->tool;
  }

  st->mask = mask;
  st->dir  = best;
  st->mag  = mag;
}

int joystickRead(void) {
  struct joyState st;
  joystickReadState(&st);
  return st.dir;
}

static bool toolStep(int amp, int sign) {
  if (amp <= 0) return false;

  if (amp > JOY_FULL_SCALE) amp = JOY_FULL_SCALE;

  double step = speed.stepSize * ((double)amp / (double)JOY_FULL_SCALE);
  if (sign < 0) step = -step;

  return posSetAngle4(Pos.ser.angle4 + step);
}

static void updateLed(bool moving) {
  if (!moving) {
    PORTB &= (unsigned char)~_BV(PB5);
    return;
  }
  bool on = ((millis() / (unsigned long)LED_FAST_MS) % 2UL) == 0UL;
  if (on) PORTB |= (unsigned char)_BV(PB5);
  else    PORTB &= (unsigned char)~_BV(PB5);
}

void joystickSetup(void) {
  DDRC &= (unsigned char)~(_BV(PC0) | _BV(PC1) | _BV(PC2) | _BV(PC3));
  DDRB |= (unsigned char)_BV(PB5);
  PORTB &= (unsigned char)~_BV(PB5);

#if WEARM_DEBUG_SERIAL
  JLOG("[joy] MeArm dual-stick JOINT control ready (A0-A3)");
  JLOG("[joy] A0 -> b angle1 base   A1 -> r angle2 shoulder");
  JLOG("[joy] A3 -> c angle3 elbow  A2 -> f angle4 tool");
#endif

  joyCalibrateAxis(JOY_LX_PIN);
  joyCalibrateAxis(JOY_LY_PIN);
  joyCalibrateAxis(JOY_RX_PIN);
  joyCalibrateAxis(JOY_RY_PIN);

  for (int i = 0; i < JIDX_COUNT; i++) lastStepTime[i] = millis();
#if WEARM_DEBUG_SERIAL
  lastBlockLogTime = 0;
#endif
#if WEARM_HAVE_BUTTONS
  sw1Prev = false;
  sw2Prev = false;
  sw2LongFired = false;
#endif
}

void joystickLoop(void) {
  struct joyState st;
  joystickReadState(&st);

  bool locked = pickPlaceIsBusy() | buttonControlLocked() | drawControlLocked();
  bool moved = false;

  const int *amp  = &st.base;
  const int *rawp = &st.sx;

  if (!locked) {
    unsigned long now = millis();

    for (int i = 0; i < JIDX_COUNT; i++) {
      if (amp[i] <= 0) continue;

      int interval = speed.stepDelayMs;
      if (now - lastStepTime[i] < (unsigned long)interval) continue;

      int raw = rawp[JOY_RAWSLOT(i)];

      if (i == JIDX_TOOL) {
        int sign = (raw > JOY_CENTER) ? -1 : 1;
        if (toolStep(amp[i], sign)) {
          moved = true;
        } else {
          logBlocked(F("[joy] blocked: tool at servo limit"));
        }
      } else {
        int dirNeg = JOY_DIRNEG(i);
        int dir = (raw > JOY_CENTER) ? (dirNeg + 1) : dirNeg;
        int ampNow = amp[i];
        if (ampNow > JOY_FULL_SCALE) ampNow = JOY_FULL_SCALE;
        double step = speed.stepSize * ((double)ampNow / (double)JOY_FULL_SCALE);
        if (step < JOY_STEP_MIN_DEG) step = JOY_STEP_MIN_DEG;
        int res = moveJointStep(dir, step);
        if (res == MOVE_OK) {
          moved = true;
        } else if (res == MOVE_AT_LIMIT) {
          logBlocked(F("[joy] blocked: joint at travel limit"));
        } else if (res == MOVE_UNREACHABLE) {
          logBlocked(F("[joy] blocked: position out of workspace"));
        }
      }
      lastStepTime[i] = now;
    }
  }

#if WEARM_JOY_DEBUG
  static unsigned long lastJoyDbgMs = 0;
  unsigned long dbgNow = millis();
  if (moved || (unsigned long)(dbgNow - lastJoyDbgMs) >= 500UL) {
    lastJoyDbgMs = dbgNow;
    Serial.print(F("[joy] raw A0..A3="));
    Serial.print(st.sx); Serial.print(',');
    Serial.print(st.sy); Serial.print(',');
    Serial.print(st.tx); Serial.print(',');
    Serial.print(st.ty);
    Serial.print(F("  amp b/r/c/f="));
    Serial.print(st.base);     Serial.print('/');
    Serial.print(st.shoulder); Serial.print('/');
    Serial.print(st.elbow);    Serial.print('/');
    Serial.print(st.tool);
    Serial.print(F("  b=")); Serial.print(Pos.ser.angle1);
    Serial.print(F(" r="));  Serial.print(Pos.ser.angle2);
    Serial.print(F(" c="));  Serial.print(Pos.ser.angle3);
    Serial.print(F(" f="));  Serial.print(Pos.ser.angle4);
    Serial.print(F("  rec x=")); Serial.print(Pos.rec.x);
    Serial.print(F(" y="));      Serial.print(Pos.rec.y);
    Serial.print(F(" z="));      Serial.println(Pos.rec.z);
  }
#endif

  updateLed(moved || locked);
}
