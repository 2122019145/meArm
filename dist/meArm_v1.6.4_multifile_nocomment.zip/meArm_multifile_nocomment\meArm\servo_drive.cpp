#include "servo_drive.h"

#define SERVO_MIN_US      544
#define SERVO_MAX_US      2400
#define SERVO_TRIM_US     2
#define SERVO_TICKS_PER_US 2u
#define SERVO_FRAME_TICKS 40000u
#define SERVO_FIRST_TICKS 1000u
#define SERVO_DEFAULT_TICKS 3000u
#define SERVO_PIN_NONE    0xFFu

static uint8_t  s_pin[SERVO_CH_COUNT];
static volatile uint16_t s_ticks[SERVO_CH_COUNT];
static uint8_t  s_ch;

uint16_t servoDriveTicksForDeg(double deg) {
  int a = (int)deg;
  if (a < 0) { a = 0; } else if (a > 180) { a = 180; }
  uint16_t us = (uint16_t)(SERVO_MIN_US + (int)(((long)a * (SERVO_MAX_US - SERVO_MIN_US)) / 180L));
  us = (uint16_t)(us - SERVO_TRIM_US);
  return (uint16_t)(us * SERVO_TICKS_PER_US);
}

void servoDriveBegin(void) {
  for (uint8_t i = 0; i < SERVO_CH_COUNT; i++) {
    s_pin[i]   = SERVO_PIN_NONE;
    s_ticks[i] = SERVO_DEFAULT_TICKS;
  }
  s_ch    = SERVO_CH_COUNT;
#if defined(__AVR__)
  TCCR1A = 0;
  TCCR1B = _BV(CS11);
  TCNT1  = 0;
  TIFR1 |= _BV(OCF1A);
  OCR1A  = SERVO_FIRST_TICKS;
  TIMSK1 |= _BV(OCIE1A);
#endif
}

void servoDriveAttach(uint8_t ch, uint8_t pin) {
  if (ch >= SERVO_CH_COUNT) { return; }
  s_pin[ch] = pin;
  pinMode(pin, OUTPUT);
  digitalWrite(pin, LOW);
}

void servoDriveWrite(uint8_t ch, double deg) {
  if (ch >= SERVO_CH_COUNT) { return; }
  uint16_t t = servoDriveTicksForDeg(deg);
#if defined(__AVR__)
  uint8_t s = SREG;
  cli();
  s_ticks[ch] = t;
  SREG = s;
#else
  s_ticks[ch] = t;
#endif
}

uint8_t servoDriveStep(uint16_t nowTicks, uint16_t *nextDelayTicks) {
  if (s_ch >= SERVO_CH_COUNT) {
    s_ch = 0u;
    if (s_pin[0] != SERVO_PIN_NONE) { digitalWrite(s_pin[0], HIGH); }
    *nextDelayTicks = s_ticks[0];
    return 1u;
  }

  if (s_pin[s_ch] != SERVO_PIN_NONE) { digitalWrite(s_pin[s_ch], LOW); }
  s_ch++;
  if (s_ch < SERVO_CH_COUNT) {
    if (s_pin[s_ch] != SERVO_PIN_NONE) { digitalWrite(s_pin[s_ch], HIGH); }
    *nextDelayTicks = (uint16_t)(nowTicks + s_ticks[s_ch]);
    return 0u;
  }

  *nextDelayTicks = SERVO_FRAME_TICKS;
  return 0u;
}

#if defined(__AVR__)
ISR(TIMER1_COMPA_vect) {
  uint16_t next;
  if (servoDriveStep((uint16_t)TCNT1, &next) != 0u) {
    TCNT1 = 0;
  }
  OCR1A = next;
}
#endif
