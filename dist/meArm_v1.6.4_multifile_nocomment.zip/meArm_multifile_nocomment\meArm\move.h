#ifndef WEARM_MOVE_H
#define WEARM_MOVE_H

#include "Arduino.h"
#include "constant_and_positions.h"
#include <math.h>

void moveup(void);
void movedown(void);
void moveleft(void);
void moveright(void);
void moveforward(void);
void movebackward(void);

enum MoveDir {
  DIR_UP = 1, DIR_DOWN,
  DIR_LEFT, DIR_RIGHT,
  DIR_FWD, DIR_BWD
};

enum JointDir {
  JOINT_C_UP    = DIR_UP,
  JOINT_C_DOWN  = DIR_DOWN,
  JOINT_B_LEFT  = DIR_LEFT,
  JOINT_B_RIGHT = DIR_RIGHT,
  JOINT_R_FWD   = DIR_FWD,
  JOINT_R_BWD   = DIR_BWD
};

enum MoveResult {
  MOVE_NONE        = 0,
  MOVE_OK          = 1,
  MOVE_AT_LIMIT    = 2,
  MOVE_UNREACHABLE = 3
};

int moveJointStep(int dir, double stepSize);

enum MoveXyzResult {
  MOVE_XYZ_REJECTED = 0,
  MOVE_XYZ_OK       = 1
};

#define MOVE_XYZ_TRACK 0
#define MOVE_XYZ_JOG   1
#define MOVE_XYZ_NOW   2

int moveToPoint(const double *goal, uint8_t seen, double maxDps, double dtSec, int mode);

#endif
