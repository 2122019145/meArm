#include "Arduino.h"
#include "constant_and_positions.h"

#include "weArm_config.h"

#if WEARM_DEBUG_SERIAL
  #define WEARM_LOG(msg)   Serial.println(F(msg))
#else
  #define WEARM_LOG(msg)   ((void)0)
#endif

static const REC POS_HOME = { 20, 0, 20 };

struct arm arm1 = { 20, 20, 0 };

pos Pos = { { 0, 0, 0, 0 }, { POS_HOME.x, POS_HOME.y, POS_HOME.z } };

struct speedCfg speed = {
  .stepSize    = 1.0,
  .stepDelayMs = 40
};

int servoLimitMode = SERVO_LIMIT_CLAMP;

static int speedLevel = SPEED_NORMAL;

static bool __attribute__((noinline)) isFiniteNum(double v) {
  return (v - v) == 0.0;
}

static double __attribute__((noinline)) clampDouble(double v, double lo, double hi) {
  if (lo > hi) { double t = lo; lo = hi; hi = t; }
  if (v < lo) return lo;
  if (v > hi) return hi;
  return v;
}

bool isReachable(const REC *rec) {
  if (rec == NULL) return false;
  if (!isFiniteNum(rec->x) || !isFiniteNum(rec->y) || !isFiniteNum(rec->z)) return false;

  double zv = rec->z - arm1.armheight;
  double R = sqrt(rec->x * rec->x + rec->y * rec->y + zv * zv);

  double L1 = arm1.armLength1;
  double L2 = arm1.armLength2;
  if (L1 <= 0 || L2 <= 0) return false;

  const double GEOM_EPS = 1e-9;
  if (R > L1 + L2 + GEOM_EPS || R < fabs(L1 - L2) - GEOM_EPS) return false;
  return true;
}

static void __attribute__((noinline)) fkPlanar(double alpha, double beta,
                                               double *outX, double *outZ) {
  const double L1 = arm1.armLength1;
  const double L2 = arm1.armLength2;
  *outX = L1 * cos(alpha) + L2 * cos(beta);
  *outZ = L1 * sin(alpha) + L2 * sin(beta);
}

bool recFromServo(REC *rec, const SER *ser) {
  if (rec == NULL || ser == NULL) return false;

  double b = ser->angle1;
  double r = ser->angle2;
  double c = ser->angle3;
  if (!isFiniteNum(b) || !isFiniteNum(r) || !isFiniteNum(c)) return false;

  double alpha = r / RADtoDEG;
  double beta  = (r - c) / RADtoDEG;
  double xPlanar;
  double z;
  fkPlanar(alpha, beta, &xPlanar, &z);
  z += arm1.armheight;

  double theta = (90.0 - b) / RADtoDEG;
  double x = xPlanar * cos(theta);
  double y = xPlanar * sin(theta);
  if (!isFiniteNum(x) || !isFiniteNum(y) || !isFiniteNum(z)) return false;

  rec->x = x;
  rec->y = y;
  rec->z = z;
  return true;
}

static void ikBranch(double rhoP, double zv, double delta, double L1, double L2,
                     double *beta, double *err) {
  double phiBase = atan2(zv, rhoP);
  double argW    = atan2(L2 * sin(delta), L1 + L2 * cos(delta));
  *beta = phiBase - argW;
  double alpha = *beta + delta;
  double fx, fz;
  fkPlanar(alpha, *beta, &fx, &fz);
  double dx = fx - rhoP, dz = fz - zv;
  *err = sqrt(dx * dx + dz * dz);
}

static double __attribute__((noinline)) normRevAngle(double b) {
  if (b < 0.0)    b += 360.0;
  if (b >= 360.0) b -= 360.0;
  if (b > 360.0 - 1e-6) b = 0.0;
  return b;
}

bool getAngle(pos *pos1) {
  return getAngleEx(pos1, NULL);
}

bool getAngleEx(pos *pos1, bool *clamped) {
  if (clamped != NULL) *clamped = false;
  if (pos1 == NULL) return false;

  if (!isReachable(&pos1->rec)) {
    WEARM_LOG("[kin] reject: target out of reachable workspace");
    return false;
  }

  const double L1 = arm1.armLength1;
  const double L2 = arm1.armLength2;

  double rho = sqrt(pos1->rec.x * pos1->rec.x + pos1->rec.y * pos1->rec.y);
  double zv  = pos1->rec.z - arm1.armheight;
  double R2  = rho * rho + zv * zv;

  double cosC = (R2 - L1 * L1 - L2 * L2) / (2.0 * L1 * L2);
  if (cosC >  1.0) cosC =  1.0;
  if (cosC < -1.0) cosC = -1.0;
  double cAbs = acos(cosC);

  const double EPS = 1e-9;

  const double minB = 0.0, maxB = 180.0;
  const double minR = 0.0, maxR = 180.0;
  const double minC = 0.0, maxC = 180.0;

  double bFwd = 90.0, bRev = 90.0;
  if (rho > 1e-9) {
    bFwd = 90.0 - RADtoDEG * atan2( pos1->rec.y,  pos1->rec.x);
    bRev = 90.0 - RADtoDEG * atan2(-pos1->rec.y, -pos1->rec.x);
  }
  bFwd = normRevAngle(bFwd);
  bRev = normRevAngle(bRev);

  double bestB = 0.0, bestR = 0.0, bestC = 0.0, bestErr = 1e30;
  int pick = -1;

  for (int i = 0; i < 4; i++) {
    const bool reversePlane = (i >= 2);
    const double k = ((i & 1) == 0) ? 1.0 : -1.0;
    const double rhoP  = reversePlane ? -rho : rho;
    const double delta = k * cAbs;
    const double b = reversePlane ? bRev : bFwd;

    if (b < minB - EPS || b > maxB + EPS) continue;

    double beta, err;
    ikBranch(rhoP, zv, delta, L1, L2, &beta, &err);
    double rDeg = RADtoDEG * (beta + delta);
    double cDeg = RADtoDEG * delta;

    if (!(rDeg >= minR - EPS && rDeg <= maxR + EPS)) continue;
    if (!(cDeg >= minC - EPS && cDeg <= maxC + EPS)) continue;
    if (!isFiniteNum(err)) continue;

    if (pick < 0 || err < bestErr) {
      pick = i; bestErr = err;
      bestB = b; bestR = rDeg; bestC = cDeg;
    }
  }

  if (pick < 0) {
    WEARM_LOG("[kin] reject: no planar branch fits the joint travel");
    return false;
  }

  if (!(bestErr <= 0.05)) {
    WEARM_LOG("[kin] reject: residual too large, no valid solution");
    return false;
  }

  double angle1 = bestB;
  double angle2 = bestR;
  double angle3 = bestC;

  if (angle2 > -ANGLE_EPS && angle2 < 0) angle2 = 0;
  if (angle3 > -ANGLE_EPS && angle3 < 0) angle3 = 0;

  const double LIM_EPS = 1e-9;
  const double a4 = pos1->ser.angle4;
  const double minF = 60.0, maxF = 150.0;
  const bool toolBad = (a4 < minF - LIM_EPS || a4 > maxF + LIM_EPS);

  if (toolBad && servoLimitMode == SERVO_LIMIT_REJECT) {
    WEARM_LOG("[servo] reject joint f out of tool range");
    return false;
  }

  pos1->ser.angle1 = angle1;
  pos1->ser.angle2 = angle2;
  pos1->ser.angle3 = angle3;

  bool limClamped = false;
  if (toolBad) {
    double v = a4;
    if (v < minF) v = minF;
    if (v > maxF) v = maxF;
    pos1->ser.angle4 = v;
    limClamped = true;
  }
  if (clamped != NULL) *clamped = limClamped;
  return true;
}

void posInit(void) {
  Pos.rec.x = POS_HOME.x;
  Pos.rec.y = POS_HOME.y;
  Pos.rec.z = POS_HOME.z;

  Pos.ser.angle4 = (60.0 + 150.0) * 0.5;

  if (!getAngle(&Pos)) {
    WEARM_LOG("[pos] ERROR: POS_HOME unreachable");
  }
#if WEARM_DEBUG_SERIAL
  {
    REC chk;
    if (recFromServo(&chk, &Pos.ser)) {
      Serial.print(F("[pos] home fk check: x="));
      Serial.print(chk.x);
      Serial.print(F(" y="));
      Serial.print(chk.y);
      Serial.print(F(" z="));
      Serial.print(chk.z);
      Serial.print(F("  (POS_HOME x="));
      Serial.print(POS_HOME.x);
      Serial.print(F(" y="));
      Serial.print(POS_HOME.y);
      Serial.print(F(" z="));
      Serial.print(POS_HOME.z);
      Serial.println(F(")"));
    } else {
      Serial.println(F("[pos] home fk check: recFromServo failed"));
    }
  }
#endif
}

bool posGetHomeAngles(SER *ser) {
  if (ser == NULL) return false;

  pos p;
  p.ser = *ser;
  p.rec.x = POS_HOME.x;
  p.rec.y = POS_HOME.y;
  p.rec.z = POS_HOME.z;
  if (!getAngle(&p)) return false;

  ser->angle1 = p.ser.angle1;
  ser->angle2 = p.ser.angle2;
  ser->angle3 = p.ser.angle3;
  return true;
}

void setSpeed(double stepSize, int stepDelayMs) {
  bool changed = false;
  if (stepSize > 0 && stepSize != speed.stepSize) {
    speed.stepSize = stepSize; changed = true;
  }
  if (stepDelayMs > 0 && stepDelayMs != speed.stepDelayMs) {
    speed.stepDelayMs = stepDelayMs; changed = true;
  }
  if (changed) speedLevel = -1;
}

int adjustSpeed(int level) {
  if (level < SPEED_SLOW || level > SPEED_FAST) return -1;
  setSpeed(0.5 * (1 << level), 80 >> level);
  speedLevel = level;
  return level;
}

int speedGetLevel(void) {
  return speedLevel;
}

const char * __attribute__((noinline)) speedLevelName(int level) {
  switch (level) {
    case SPEED_SLOW:   return "慢速";
    case SPEED_NORMAL: return "中速";
    case SPEED_FAST:   return "快速";
    default:           return "自定义";
  }
}

int speedStepDown(void) {
  int cur = speedLevel;
  if (cur < SPEED_SLOW || cur > SPEED_FAST) cur = SPEED_FAST;
  return adjustSpeed((cur + 1) % 3);
}

bool posSetAngle4(double angleDeg) {
  if (!isFiniteNum(angleDeg)) return false;

  double v = clampDouble(angleDeg, 60.0, 150.0);
  if (v == Pos.ser.angle4) return false;
  Pos.ser.angle4 = v;
  return true;
}
