#include "Arduino.h"
#include "constant_and_positions.h"
#include "pick_place.h"
#include "protocol_constants.h"
#include "button_control.h"
#include "draw_control.h"

#if WEARM_ENABLE_BUTTONS

#if WEARM_BUTTON_PINS
#define BTN_PIN_CYCLE   2
#define BTN_PIN_RECORD  3
#define BTN_PIN_PLAY    4
#define BTN_PIN_HOME    5
#endif

#define BTN_DEBOUNCE_MS     25UL
#define BTN_TICK_MS         ((unsigned long) WEARM_REC_TICK_MS)
#define BTN_RAMP_MS         1500UL
#define BTN_REC_MIN_TRAVEL  10.0
#define BTN_REC_ENTRIES     WEARM_REC_ENTRIES
#define BTN_REC_BYTES       4
#define BTN_REC_LIMIT       128
#define BTN_ANGLE_UNIT      2.0
#define BTN_PLAY_SUBSTEPS   4

#if WEARM_BUTTON_PINS
static const uint8_t BTN_PIN[BTN_COUNT] = {
  BTN_PIN_CYCLE, BTN_PIN_RECORD, BTN_PIN_PLAY, BTN_PIN_HOME
};
#endif

static uint8_t s_buf[BTN_REC_ENTRIES * BTN_REC_BYTES];

enum { BS_IDLE = 0, BS_RAMP, BS_PLAY };

static uint8_t s_state       = BS_IDLE;
static uint8_t s_cycleIdx    = 0;
static bool    s_recording   = false;
static bool    s_rampThenPlay = false;

static uint16_t      s_recCount     = 0;
static uint16_t      s_recLen       = 0;
static bool          s_hasRec       = false;
static bool          s_recOverflow  = false;
static unsigned long s_recStartMs    = 0;
static unsigned long s_recDurationMs = 0;
static unsigned long s_tickNow       = 0;
static double        s_snap[4]      = {0.0, 0.0, 0.0, 0.0};
static double        s_recStart[4]  = {0.0, 0.0, 0.0, 0.0};
static double        s_recTravel    = 0.0;
static double        s_bbMin[3]     = {0.0, 0.0, 0.0};
static double        s_bbMax[3]     = {0.0, 0.0, 0.0};

static double        s_rampFrom[4] = {0.0, 0.0, 0.0, 0.0};
static double        s_rampTo[4]   = {0.0, 0.0, 0.0, 0.0};
static unsigned long s_rampStartMs = 0;

static uint16_t      s_playIdx   = 0;
static unsigned long s_playDueMs = 0;
static uint8_t       s_subIdx    = 0;
static double        s_subDelta[4]   = {0.0, 0.0, 0.0, 0.0};
static double        s_subApplied[4] = {0.0, 0.0, 0.0, 0.0};

#if WEARM_BUTTON_PINS
static bool          s_btnStable[BTN_COUNT] = {false, false, false, false};
static bool          s_btnArmed[BTN_COUNT]  = {false, false, false, false};
static unsigned long s_btnChangeAt[BTN_COUNT] = {0UL, 0UL, 0UL, 0UL};
#endif

static double *btnAngle(int joint) {
  return &Pos.ser.angle1 + joint;
}

static void btnCommitAngles(void) {
  SER tmp = Pos.ser;
  if (tmp.angle1 < 0.0)   tmp.angle1 = 0.0;
  if (tmp.angle1 > 180.0) tmp.angle1 = 180.0;
  if (tmp.angle2 < 0.0)   tmp.angle2 = 0.0;
  if (tmp.angle2 > 180.0) tmp.angle2 = 180.0;
  if (tmp.angle3 < 0.0)   tmp.angle3 = 0.0;
  if (tmp.angle3 > 180.0) tmp.angle3 = 180.0;
  if (tmp.angle4 < 60.0)  tmp.angle4 = 60.0;
  if (tmp.angle4 > 150.0) tmp.angle4 = 150.0;
  Pos.ser = tmp;
  (void) recFromServo(&Pos.rec, &Pos.ser);
}

static int btnToUnits(double deltaDeg) {
  double u = deltaDeg * BTN_ANGLE_UNIT;
  return (int) ((u >= 0.0) ? (u + 0.5) : (u - 0.5));
}

static double btnFromUnits(int units) {
  return (double) units / BTN_ANGLE_UNIT;
}

static void btnUpdateTravel(const REC *rec) {
  const double *v = &rec->x;
  for (int a = 0; a < 3; a++) {
    double x = v[a];
    if (x < s_bbMin[a]) s_bbMin[a] = x;
    if (x > s_bbMax[a]) s_bbMax[a] = x;
  }
}

static const char *btnObjectName(int object) {
  static const char *const name[PICK_OBJECT_COUNT] = { "A", "B", "C" };
  if (object < 0 || object >= PICK_OBJECT_COUNT) return "?";
  return name[object];
}

static double btnTravelSpan(void) {
  double t = s_bbMax[0] - s_bbMin[0];
  for (int a = 1; a < 3; a++) {
    double d = s_bbMax[a] - s_bbMin[a];
    if (d > t) t = d;
  }
  return t;
}

static void btnRecPut(const int *u) {
  if (s_recCount >= BTN_REC_ENTRIES) {
    s_recOverflow = true;
    return;
  }
  uint8_t *p = &s_buf[s_recCount * BTN_REC_BYTES];
  uint32_t v = 0;
  for (int j = 0; j < 4; j++) {
    v |= ((uint32_t) (u[j] & 0xFF)) << (8 * j);
  }
  p[0] = (uint8_t) v;
  p[1] = (uint8_t) (v >> 8);
  p[2] = (uint8_t) (v >> 16);
  p[3] = (uint8_t) (v >> 24);
  s_recCount++;
}

static bool btnRecCollect(int *u) {
  bool moved = false;
  for (int j = 0; j < 4; j++) {
    int d = btnToUnits(*btnAngle(j) - s_snap[j]);
    if (d >  BTN_REC_LIMIT - 1) d =  BTN_REC_LIMIT - 1;
    if (d < -BTN_REC_LIMIT)     d = -BTN_REC_LIMIT;
    u[j] = d;
    if (d != 0) {
      moved = true;
      s_snap[j] += btnFromUnits(d);
    }
  }
  return moved;
}

static int  btnStopRecording(void);

static void btnStartRecording(void) __attribute__((noinline));

static void btnStartRecording(void) {
  s_recCount      = 0;
  s_recOverflow   = false;
  s_recording     = true;
  s_recStartMs    = millis();
  s_tickNow       = 0;
  s_recDurationMs = 0;
  s_recTravel     = 0.0;
  for (int j = 0; j < 4; j++) {
    s_snap[j]     = *btnAngle(j);
    s_recStart[j] = s_snap[j];
  }
  s_bbMin[0] = s_bbMax[0] = Pos.rec.x;
  s_bbMin[1] = s_bbMax[1] = Pos.rec.y;
  s_bbMin[2] = s_bbMax[2] = Pos.rec.z;

#if WEARM_DEBUG_SERIAL
  Serial.print(F("[btn] 开始录制：请用摇杆操控机械臂（要有明显位移，最长 "));
  Serial.print((unsigned long) BTN_REC_ENTRIES * BTN_TICK_MS / 1000UL);
  Serial.println(F(" 秒）"));
  Serial.println(F("[btn] 提示：本次录制会覆盖上一次的录制数据"));
#endif
}

static void btnRecTick(unsigned long now) {
  unsigned long tick = (now - s_recStartMs) / BTN_TICK_MS;

  while (s_tickNow < tick && !s_recOverflow) {
    int u[4];
    s_tickNow++;
    (void) btnRecCollect(u);
    btnUpdateTravel(&Pos.rec);
    btnRecPut(u);
  }

  if (s_recOverflow) {
#if WEARM_DEBUG_SERIAL
    Serial.print(F("[btn] 录制缓冲已满（"));
    Serial.print((unsigned int) BTN_REC_ENTRIES);
    Serial.println(F(" 条），自动结束录制"));
#endif
    (void) btnStopRecording();
  }
}

static int btnStopRecording(void) {
  unsigned long now = millis();

  if (!s_recOverflow) {
    int u[4];
    for (int i = 0; i < 8 && !s_recOverflow; i++) {
      if (!btnRecCollect(u)) break;
      btnUpdateTravel(&Pos.rec);
      btnRecPut(u);
    }
  }

  s_recording     = false;
  s_recDurationMs = now - s_recStartMs;

  s_recTravel = btnTravelSpan();

#if WEARM_DEBUG_SERIAL
  Serial.print(F("[btn] 结束录制：时长 "));
  Serial.print(s_recDurationMs);
  Serial.print(F(" ms，条目 "));
  Serial.print(s_recCount);
  Serial.print(F(" 条，末端位移 "));
  Serial.print(s_recTravel, 2);
  Serial.println(F("（坐标单位）"));
#endif

  bool ok = true;
  if (s_recOverflow) {
    ok = false;
#if WEARM_DEBUG_SERIAL
    Serial.print(F("[btn] 不合格：动作太长把 "));
    Serial.print((unsigned int) BTN_REC_ENTRIES);
    Serial.println(F(" 条缓冲写满了，尾部动作丢失"));
#endif
  } else if (s_recCount <= 0) {
    ok = false;
#if WEARM_DEBUG_SERIAL
    Serial.println(F("[btn] 不合格：缓冲里没有任何动作"));
#endif
  } else if (s_recTravel < BTN_REC_MIN_TRAVEL) {
    ok = false;
#if WEARM_DEBUG_SERIAL
    Serial.println(F("[btn] 不合格：位移太小，看不出明显移动"));
#endif
  }

  if (!ok) {
    s_recLen = 0;
    s_recCount = 0;
    s_hasRec = false;
#if WEARM_DEBUG_SERIAL
    Serial.println(F("[btn] 本次录制已丢弃，上一次的录制数据也已被覆盖，请重录"));
#endif
    return PROTO_RES_REC_REJECTED;
  }

  s_recLen = s_recCount;
  s_hasRec = true;
#if WEARM_DEBUG_SERIAL
  Serial.print(F("[btn] 录制已保存："));
  Serial.print(s_recLen);
  Serial.println(F(" 条，按按键3 可播放"));
#endif
  return PROTO_RES_REC_SAVED;
}

static void btnStartRamp(const double *target, bool thenPlay) {
  for (int j = 0; j < 4; j++) {
    s_rampFrom[j] = *btnAngle(j);
    s_rampTo[j]   = target[j];
  }
  s_rampStartMs  = millis();
  s_rampThenPlay = thenPlay;
  s_state        = BS_RAMP;
}

static void btnRampTick(unsigned long now) {
  double t = (double) (now - s_rampStartMs) / (double) BTN_RAMP_MS;
  if (t > 1.0) t = 1.0;

  for (int j = 0; j < 4; j++) {
    *btnAngle(j) = s_rampFrom[j] + (s_rampTo[j] - s_rampFrom[j]) * t;
  }
  btnCommitAngles();

  if (t < 1.0) return;

  for (int j = 0; j < 4; j++) {
    *btnAngle(j) = s_rampTo[j];
  }
  btnCommitAngles();

  if (s_rampThenPlay) {
    s_rampThenPlay = false;
    s_state        = BS_PLAY;
    s_playIdx      = 0;
    s_playDueMs    = millis();
    s_subIdx       = 0;
#if WEARM_DEBUG_SERIAL
    Serial.println(F("[btn] 已摆到录制起点，开始播放"));
#endif
  } else {
    s_state = BS_IDLE;
#if WEARM_DEBUG_SERIAL
    Serial.println(F("[btn] 已回到初始位置"));
#endif
  }
}

static void btnPlayLoad(void) {
  const uint8_t *p = &s_buf[s_playIdx * BTN_REC_BYTES];
  uint32_t v = (uint32_t) p[0] | ((uint32_t) p[1] << 8) |
               ((uint32_t) p[2] << 16) | ((uint32_t) p[3] << 24);
  for (int j = 0; j < 4; j++) {
    int u = (int) ((v >> (8 * j)) & 0xFF);
    u = (u ^ BTN_REC_LIMIT) - BTN_REC_LIMIT;
    s_subDelta[j]   = btnFromUnits(u);
    s_subApplied[j] = 0.0;
  }
  s_subIdx = 0;
}

static void btnPlaySub(void) {
  s_subIdx++;
  for (int j = 0; j < 4; j++) {
    double target = s_subDelta[j] * (double) s_subIdx / (double) BTN_PLAY_SUBSTEPS;
    *btnAngle(j) += target - s_subApplied[j];
    s_subApplied[j] = target;
  }
  btnCommitAngles();
}

static void btnPlayTick(unsigned long now) {
  const unsigned long subMs = BTN_TICK_MS / (unsigned long) BTN_PLAY_SUBSTEPS;

  while (s_playIdx < s_recLen) {
    if (s_subIdx == 0) btnPlayLoad();

    unsigned long due = s_playDueMs + subMs;
    if ((long) (now - due) < 0L) break;
    s_playDueMs = due;
    btnPlaySub();
    if (s_subIdx >= BTN_PLAY_SUBSTEPS) {
      s_subIdx = 0;
      s_playIdx++;
    }
  }

  if (s_playIdx >= s_recLen) {
    s_state = BS_IDLE;
#if WEARM_DEBUG_SERIAL
    Serial.println(F("[btn] 播放结束"));
#endif
  }
}

static int btnActionCycle(void) {
  if (s_recording) {
#if WEARM_DEBUG_SERIAL
    Serial.println(F("[btn] 正在录制，按键1 忽略（先按按键2 结束录制）"));
#endif
    return PROTO_RES_BUSY;
  }
  if (s_state != BS_IDLE) {
#if WEARM_DEBUG_SERIAL
    Serial.println(F("[btn] 正在播放/回中，按键1 忽略"));
#endif
    return PROTO_RES_BUSY;
  }

  int object = s_cycleIdx;
  int rc = pickPlaceStart(object);
  if (rc != 0) {
#if WEARM_DEBUG_SERIAL
    Serial.print(F("[btn] 取放启动失败 rc="));
    Serial.println(rc);
#endif
    return PROTO_RES_BUSY;
  }

#if WEARM_DEBUG_SERIAL
  Serial.print(F("[btn] 按键1 循环执行：夹取物体 "));
  Serial.print(btnObjectName(object));
  Serial.print(F("，下一次是 "));
  Serial.println(btnObjectName((object + 1) % PICK_OBJECT_COUNT));
#endif
  s_cycleIdx = (uint8_t)((object + 1) % PICK_OBJECT_COUNT);
  return PROTO_RES_PICK_STARTED;
}

static int btnActionRecord(void) {
  if (!s_recording) {
    if (pickPlaceIsBusy() || s_state != BS_IDLE) {
#if WEARM_DEBUG_SERIAL
      Serial.println(F("[btn] 机械臂正忙，现在不能开始录制"));
#endif
      return PROTO_RES_BUSY;
    }
    btnStartRecording();
    return PROTO_RES_REC_STARTED;
  }
  return btnStopRecording();
}

static int btnActionPlay(void) {
  if (s_recording) {
    int stopped = btnStopRecording();
    if (stopped != PROTO_RES_REC_SAVED) {
      return stopped;
    }
  }
  if (pickPlaceIsBusy() || s_state != BS_IDLE) {
#if WEARM_DEBUG_SERIAL
    Serial.println(F("[btn] 机械臂正忙，按键3 忽略"));
#endif
    return PROTO_RES_BUSY;
  }
  if (!s_hasRec) {
#if WEARM_DEBUG_SERIAL
    Serial.println(F("[btn] 还没有录制数据，先按按键2 录一段"));
#endif
    return PROTO_RES_PLAY_NO_RECORD;
  }

  btnStartRamp(s_recStart, true);
#if WEARM_DEBUG_SERIAL
  Serial.print(F("[btn] 按键3 播放：先平滑摆到录制起点，再复现 "));
  Serial.print(s_recLen);
  Serial.println(F(" 条动作"));
#endif
  return PROTO_RES_PLAY_STARTED;
}

static int btnActionHome(void) {
  if (s_recording) {
#if WEARM_DEBUG_SERIAL
    Serial.println(F("[btn] 正在录制，按键4 忽略（先按按键2 结束录制）"));
#endif
    return PROTO_RES_BUSY;
  }
  if (pickPlaceIsBusy() || s_state != BS_IDLE) {
#if WEARM_DEBUG_SERIAL
    Serial.println(F("[btn] 正在播放/回中或取放中，按键4 忽略"));
#endif
    return PROTO_RES_BUSY;
  }

  SER home;
  home.angle4 = Pos.ser.angle4;
  if (!posGetHomeAngles(&home)) {
#if WEARM_DEBUG_SERIAL
    Serial.println(F("[btn] 回中失败：初始位姿反解不成功"));
#endif
    return PROTO_RES_BUSY;
  }

  btnStartRamp(&home.angle1, false);

#if WEARM_DEBUG_SERIAL
  Serial.println(F("[btn] 按键4 回中：平滑回到开机初始位姿"));
#endif
  return PROTO_RES_HOME_STARTED;
}

static int btnAction(int key) {
  if (drawAcceptButton(key)) {
    return drawHandleButton(key);
  }

  switch (key) {
    case BTN_KEY_CYCLE:  return btnActionCycle();
    case BTN_KEY_RECORD: return btnActionRecord();
    case BTN_KEY_PLAY:   return btnActionPlay();
    case BTN_KEY_HOME:   return btnActionHome();
    default:             return PROTO_RES_UNKNOWN;
  }
}

#if WEARM_BUTTON_PINS
static bool btnEdge(int key) {
  bool raw = (digitalRead(BTN_PIN[key]) == LOW);
  unsigned long now = millis();

  if (raw == s_btnStable[key]) {
    s_btnArmed[key] = false;
    return false;
  }
  if (!s_btnArmed[key]) {
    s_btnArmed[key]    = true;
    s_btnChangeAt[key] = now;
    return false;
  }
  if ((now - s_btnChangeAt[key]) < BTN_DEBOUNCE_MS) return false;

  s_btnStable[key] = raw;
  s_btnArmed[key]  = false;
  return raw;
}
#endif

void buttonSetup(void) {
#if WEARM_BUTTON_PINS
  for (int k = 0; k < BTN_COUNT; k++) {
    pinMode(BTN_PIN[k], INPUT_PULLUP);
    s_btnStable[k]   = (digitalRead(BTN_PIN[k]) == LOW);
    s_btnArmed[k]    = false;
    s_btnChangeAt[k] = 0UL;
  }
#endif

  s_state        = BS_IDLE;
  s_recording    = false;
  s_hasRec       = false;
  s_recLen       = 0;
  s_recCount     = 0;
  s_recOverflow  = false;
  s_cycleIdx     = 0;
  s_rampThenPlay = false;

#if WEARM_DEBUG_SERIAL
  Serial.println(F("[btn] 按键初始化："));
#if WEARM_BUTTON_PINS
  Serial.println(F("[btn]   按键1 D2  循环执行（每次按顺序夹 A -> B -> C，串口 N）"));
  Serial.println(F("[btn]   按键2 D3  录制 开/关（有明显位移即可，串口 R）"));
  Serial.println(F("[btn]   按键3 D4  播放上一次录制的内容（串口 P）"));
  Serial.println(F("[btn]   按键4 D5  回中：回到开机初始位姿（串口 M 或 0）"));
#else
  Serial.println(F("[btn]   不读 D2~D5 物理按键（WEARM_BUTTON_PINS=0）："));
  Serial.println(F("[btn]     N 循环执行（夹 A -> B -> C）  R 录制开/关"));
  Serial.println(F("[btn]     P 播放上一次录制            M 或 0 回中"));
#endif
#endif
}

void buttonLoop(void) {
  unsigned long now = millis();

  if (s_recording)            btnRecTick(now);
  if (s_state == BS_RAMP)     btnRampTick(now);
  else if (s_state == BS_PLAY) btnPlayTick(now);

#if WEARM_BUTTON_PINS
  for (int k = 0; k < BTN_COUNT; k++) {
    if (!btnEdge(k)) continue;
    (void) btnAction(k);
  }
#endif
}

int buttonHandleCommand(char c) {
  switch (c) {
    case PROTO_CMD_BTN_CYCLE:    return btnAction(BTN_KEY_CYCLE);
    case PROTO_CMD_BTN_RECORD:   return btnAction(BTN_KEY_RECORD);
    case PROTO_CMD_BTN_PLAY:     return btnAction(BTN_KEY_PLAY);
    case PROTO_CMD_BTN_HOME:
    case PROTO_CMD_BTN_HOME_ALT: return btnAction(BTN_KEY_HOME);
    default:                     return PROTO_RES_UNKNOWN;
  }
}

bool buttonIsCommandChar(char c) {
  return (c == PROTO_CMD_BTN_CYCLE)
      || (c == PROTO_CMD_BTN_RECORD)
      || (c == PROTO_CMD_BTN_PLAY)
      || (c == PROTO_CMD_BTN_HOME)
      || (c == PROTO_CMD_BTN_HOME_ALT);
}

int buttonPickNext(void) {
  return s_cycleIdx;
}

bool buttonIsRecording(void) {
  return s_recording;
}

bool buttonPlaybackActive(void) {
  return (s_state == BS_PLAY) || (s_state == BS_RAMP && s_rampThenPlay);
}

int buttonRecordingEntries(void) {
  return s_recording ? s_recCount : s_recLen;
}

unsigned long buttonRecordingMs(void) {
  if (s_recording) return millis() - s_recStartMs;
  return s_recDurationMs;
}

double buttonRecordingTravel(void) {
  return s_recTravel;
}

bool buttonHasRecording(void) {
  return s_hasRec;
}

bool buttonControlBusy(void) {
  return s_recording || (s_state != BS_IDLE);
}

bool buttonControlLocked(void) {
  return (s_state != BS_IDLE);
}

const char *buttonName(int key) {
  switch (key) {
    case BTN_KEY_CYCLE:  return "按键1 循环执行";
    case BTN_KEY_RECORD: return "按键2 录制";
    case BTN_KEY_PLAY:   return "按键3 播放";
    case BTN_KEY_HOME:   return "按键4 回中";
    default:             return "未知按键";
  }
}

const char *buttonStateName(void) {
  if (s_recording)          return "录制中";
  if (s_state == BS_PLAY)   return "播放中";
  if (s_state == BS_RAMP)   return s_rampThenPlay ? "预摆中" : "回中中";
  return "空闲";
}

#endif
