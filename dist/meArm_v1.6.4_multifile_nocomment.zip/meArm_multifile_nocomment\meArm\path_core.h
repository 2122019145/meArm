#ifndef PATH_CORE_H
#define PATH_CORE_H

#include <math.h>
#include "constant_and_positions.h"

inline bool pathCoreSolveJoint(double x, double y, double z,
                               double *b, double *r, double *c) {
  pos p;
  p.rec.x = x;
  p.rec.y = y;
  p.rec.z = z;
  p.ser = Pos.ser;
  bool clamped = false;
  if (!getAngleEx(&p, &clamped)) return false;
  if (clamped) return false;
  if (b) *b = p.ser.angle1;
  if (r) *r = p.ser.angle2;
  if (c) *c = p.ser.angle3;
  return true;
}

inline bool pathCorePointOk(double x, double y, double z,
                            double *b, double *r, double *c) {
  REC rec;
  rec.x = x;
  rec.y = y;
  rec.z = z;
  if (!isReachable(&rec)) return false;

  return pathCoreSolveJoint(x, y, z, b, r, c);
}

inline void pathCoreSetJoints(double b, double r, double c) {
  Pos.ser.angle1 = b;
  Pos.ser.angle2 = r;
  Pos.ser.angle3 = c;
  (void) recFromServo(&Pos.rec, &Pos.ser);
}

inline bool pathCoreSegmentOk(const double *p0, const double *p1,
                              double sampleStep, int sampleMax, double jumpDeg) {
  double x0 = p0[0], y0 = p0[1], z0 = p0[2];
  double dx = p1[0] - x0;
  double dy = p1[1] - y0;
  double dz = p1[2] - z0;
  double len = sqrt(dx * dx + dy * dy + dz * dz);

  int steps = (int)(len / sampleStep) + 1;
  if (steps < 2) steps = 2;
  if (steps > sampleMax) steps = sampleMax;

  double pb = 0.0, pr = 0.0, pc = 0.0;
  for (int i = 0; i <= steps; i++) {
    double t = (double)i / (double)steps;
    double b = 0.0, r = 0.0, c = 0.0;
    if (!pathCorePointOk(x0 + dx * t, y0 + dy * t, z0 + dz * t, &b, &r, &c)) {
      return false;
    }
    if (i > 0) {
      if (fabs(b - pb) > jumpDeg ||
          fabs(r - pr) > jumpDeg ||
          fabs(c - pc) > jumpDeg) {
        return false;
      }
    }
    pb = b;
    pr = r;
    pc = c;
  }
  return true;
}

#endif
