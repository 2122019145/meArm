#ifndef SERVO_DRIVE_H
#define SERVO_DRIVE_H

#include <Arduino.h>

#define SERVO_CH_COUNT 4u

void servoDriveBegin(void);

void servoDriveAttach(uint8_t ch, uint8_t pin);

void servoDriveWrite(uint8_t ch, double deg);

uint16_t servoDriveTicksForDeg(double deg);

uint8_t servoDriveStep(uint16_t nowTicks, uint16_t *nextDelayTicks);

#endif
