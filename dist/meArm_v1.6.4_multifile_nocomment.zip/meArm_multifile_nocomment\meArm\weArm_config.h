#ifndef WEARM_CONFIG_H
#define WEARM_CONFIG_H

#ifndef WEARM_DEBUG_SERIAL
#  define WEARM_DEBUG_SERIAL 0
#endif

#ifndef WEARM_ENABLE_PICK_PLACE
#  define WEARM_ENABLE_PICK_PLACE 1
#endif

#ifndef WEARM_ENABLE_BUTTONS
#  define WEARM_ENABLE_BUTTONS 1
#endif

#ifndef WEARM_ENABLE_DRAW
#  define WEARM_ENABLE_DRAW 1
#endif

#ifndef WEARM_MIRROR_BASE
#  define WEARM_MIRROR_BASE 1
#endif
#ifndef WEARM_MIRROR_TOOL
#  define WEARM_MIRROR_TOOL 1
#endif

#ifndef WEARM_BUTTON_PINS
#  define WEARM_BUTTON_PINS 0
#endif

#ifndef WEARM_REC_TICK_MS
#  define WEARM_REC_TICK_MS 200
#endif
#ifndef WEARM_REC_ENTRIES
#  define WEARM_REC_ENTRIES 192
#endif

#endif
