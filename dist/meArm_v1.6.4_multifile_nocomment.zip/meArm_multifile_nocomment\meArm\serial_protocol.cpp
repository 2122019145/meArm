#include "Arduino.h"
#include "constant_and_positions.h"
#include "pick_place.h"
#include "protocol_constants.h"
#include "serial_protocol.h"
#include "button_control.h"
#include "draw_control.h"
#include "weArm_config.h"

static char s_line[PROTO_LINE_BUF_SIZE];
static int  s_len = 0;
static bool s_pending = false;
static bool s_dropUntilEol = false;
static unsigned long s_lastCharMs = 0;

static void protoFlushLine(void);
static bool protoParseAxisLine(const char *s, double angles[3], uint8_t *seen);
static bool protoParseNumber(const char **pp, double *out);
static void protoApplyAngles(const double angles[3], uint8_t seen);
static int protoSpeedStep(int delta);
static int protoHandleDrawCalib(const char *line, char cmd);
#define PROTO_FEATURE_PICK   0x01u
#define PROTO_FEATURE_BUTTON 0x02u
#define PROTO_FEATURE_DRAW   0x04u

static bool protoRuntimeEnabled(uint8_t feature);
static uint8_t protoCompiledFeatures(void);
static uint8_t s_runtimeFeatures =
    (WEARM_ENABLE_PICK_PLACE ? PROTO_FEATURE_PICK : 0u) |
    (WEARM_ENABLE_BUTTONS ? PROTO_FEATURE_BUTTON : 0u) |
    (WEARM_ENABLE_DRAW ? PROTO_FEATURE_DRAW : 0u);

static const char *protoSkipBlanks(const char *p)
{
  while (*p == ' ' || *p == '\t') {
    p++;
  }
  return p;
}

#define PROTO_SKIP_BLANKS(p) do { (p) = protoSkipBlanks(p); } while (0)

#ifndef PSTR
#define PSTR(s) (s)
#endif
#ifndef pgm_read_byte
#define pgm_read_byte(addr) (*(const unsigned char *)(addr))
#endif
#ifndef PROGMEM
#define PROGMEM
#endif

#ifndef WEARM_SERIAL_ARDUINO
#define WEARM_SERIAL_ARDUINO 0
#endif

#if defined(__AVR__) && !WEARM_SERIAL_ARDUINO
#define WEARM_UART_RAW 1
#else
#define WEARM_UART_RAW 0
#endif

#if WEARM_UART_RAW
#include <avr/interrupt.h>

#define PROTO_RX_BUF_MASK 63u
static volatile uint8_t s_rxBuf[PROTO_RX_BUF_MASK + 1u];
static volatile uint8_t s_rxHead = 0;
static volatile uint8_t s_rxTail = 0;

static void protoRxStore(uint8_t b)
{
  uint8_t next = (uint8_t)((s_rxHead + 1u) & PROTO_RX_BUF_MASK);

  if (next != s_rxTail) {
    s_rxBuf[s_rxHead] = b;
    s_rxHead = next;
  }
}

ISR(USART_RX_vect)
{
  protoRxStore(UDR0);
}

static void protoPut(char c)
{
  while ((UCSR0A & (1u << UDRE0)) == 0u) {
  }
  UDR0 = (uint8_t)c;
}

static int protoRxTake(void)
{
  uint8_t b;

  if (s_rxHead == s_rxTail) {
    return -1;
  }
  b = s_rxBuf[s_rxTail];
  s_rxTail = (uint8_t)((s_rxTail + 1u) & PROTO_RX_BUF_MASK);
  return (int)b;
}

static void protoSerialBegin(void)
{
  uint16_t ubrr = (uint16_t)((F_CPU / 4UL / (unsigned long)PROTO_BAUD - 1UL) / 2UL);

  UCSR0A = (uint8_t)(1u << U2X0);
  UBRR0H = (uint8_t)(ubrr >> 8);
  UBRR0L = (uint8_t)ubrr;
  UCSR0C = (uint8_t)((1u << UCSZ01) | (1u << UCSZ00));
  UCSR0B = (uint8_t)((1u << RXEN0) | (1u << TXEN0) | (1u << RXCIE0));
}
#else
static void protoPut(char c)
{
  Serial.print(c);
}

static int protoRxTake(void)
{
  if (Serial.available() <= 0) {
    return -1;
  }
  return Serial.read();
}

static void protoSerialBegin(void)
{
  Serial.begin(PROTO_BAUD);
}
#endif

#if WEARM_SERIAL_RESPONSES

static void protoWriteInt(int v)
{
  if (v >= 100) {
    protoPut((char)('0' + v / 100));
  }
  if (v >= 10) {
    protoPut((char)('0' + (v / 10) % 10));
  }
  protoPut((char)('0' + v % 10));
}

__attribute__((noinline, noclone))
static void protoReply(const char *text)
{
  char c;

  while ((c = (char)pgm_read_byte(text++)) != '\0') {
    if (c == '#') {
      protoWriteInt((int)Pos.ser.angle4);
    } else {
      protoPut(c);
    }
  }
  protoPut('\n');
}

static const char s_rOk[] PROGMEM = "OK";
static const char s_rErr[] PROGMEM = "ERR";
static const char s_rRej[] PROGMEM = "REJECTED";
static const char s_rOkN[] PROGMEM = "OK #";
static const char s_rBusy[] PROGMEM = "BUSY";
static const char s_rDiscard[] PROGMEM = "DISCARD";
static const char s_rEmpty[] PROGMEM = "EMPTY";
static const char s_rOff[] PROGMEM = "OFF";
static const char s_rBoot[] PROGMEM = "CMD OSHL 123 kK ABC NRPM0 FDGEQUW pno ANG x,y,z ! !P !B !D";

__attribute__((noinline))
static void protoReplyTaskTag(const char *tag)
{
  protoPut('O');
  protoPut('K');
  protoPut(' ');
  protoPut('F');
  protoPut('=');
  while (*tag != '\0') {
    protoPut(*tag++);
  }
  protoPut('\n');
}

#define R_OK()   protoReply(s_rOk)
#define R_ERR()  protoReply(s_rErr)
#define R_REJ()  protoReply(s_rRej)
#define R_OKN()  protoReply(s_rOkN)
#define R_BUSY() protoReply(s_rBusy)
#define R_DISCARD() protoReply(s_rDiscard)
#define R_EMPTY() protoReply(s_rEmpty)
#define R_OFF()  protoReply(s_rOff)
#define R_BOOT() protoReply(s_rBoot)
#define R_FEATURE() do { protoPut('P'); protoPut('='); protoPut((s_runtimeFeatures & PROTO_FEATURE_PICK) ? '1' : '0'); protoPut(' '); protoPut('B'); protoPut('='); protoPut((s_runtimeFeatures & PROTO_FEATURE_BUTTON) ? '1' : '0'); protoPut(' '); protoPut('D'); protoPut('='); protoPut((s_runtimeFeatures & PROTO_FEATURE_DRAW) ? '1' : '0'); protoPut(10); } while (0)
#else
#define R_OK()   do { } while (0)
#define R_ERR()  do { } while (0)
#define R_REJ()  do { } while (0)
#define R_OKN()  do { } while (0)
#define R_BUSY() do { } while (0)
#define R_DISCARD() do { } while (0)
#define R_EMPTY() do { } while (0)
#define R_OFF()  do { } while (0)
#define R_BOOT() do { } while (0)
#define R_FEATURE() do { } while (0)
#define protoReplyTaskTag(tag) do { (void)(tag); } while (0)
#endif

static const uint8_t s_liveBits[9] PROGMEM = { 0x0F, 0x00, 0xF0, 0x71, 0xA7, 0x00, 0x00, 0xC0, 0x01 };
static const uint8_t s_fastBits[9] PROGMEM = { 0x0E, 0x00, 0x0E, 0x99, 0x08, 0x00, 0x00, 0x08, 0x00 };

__attribute__((noinline)) static bool protoCmdBit(const uint8_t *bits, char cmd)
{
  uint8_t i = (uint8_t)cmd - (uint8_t)'0';

  if (i > 64u) {
    return false;
  }
  return (pgm_read_byte(bits + (i >> 3)) & (uint8_t)(1u << (i & 7u))) != 0;
}

static const uint8_t s_featureBits[17] PROGMEM = {
  0x02,
  0x00, 0x00, 0x00,
  0x54,
  0xFF,
  0x00,
  0x28,
  0x2E,
  0xCC,
  0x00, 0x00, 0x00, 0x00, 0x00,
  0xF0,
  0x03
};

__attribute__((noinline)) static uint8_t protoCmdFeature(char cmd)
{
  uint8_t i = (uint8_t)cmd - (uint8_t)'0';

  if (i > 64u) {
    return 0u;
  }
  return (uint8_t)((pgm_read_byte(s_featureBits + (i >> 2)) >> (uint8_t)((i & 3u) * 2u)) & 0x03u);
}

void serialProtocolLoop(void)
{
  int c;

  while ((c = protoRxTake()) >= 0) {
    s_lastCharMs = millis();

    if (c == '\n' || c == '\r') {
      if (s_dropUntilEol) {
        s_dropUntilEol = false;
        s_len = 0;
        s_pending = false;
      } else {
        protoFlushLine();
      }
      continue;
    }
    if (s_dropUntilEol) {
      continue;
    }

    if (s_len >= PROTO_LINE_BUF_SIZE - 1) {
      s_dropUntilEol = true;
      s_len = 0;
      s_pending = false;
      continue;
    }

    s_line[s_len++] = (char)c;
    s_pending = true;

    if (s_len == 1 && protoCmdBit(s_fastBits, s_line[0])) {
      protoFlushLine();
    }
  }

  if (s_pending && (millis() - s_lastCharMs) >= PROTO_LINE_TIMEOUT_MS) {
    protoFlushLine();
  }

  if (s_dropUntilEol && (millis() - s_lastCharMs) >= PROTO_LINE_TIMEOUT_MS) {
    s_dropUntilEol = false;
    s_line[0] = '\0';
    s_len = 0;
    s_pending = false;
  }
}

static bool protoRuntimeEnabled(uint8_t feature)
{
  return (s_runtimeFeatures & feature) != 0;
}

static uint8_t protoCompiledFeatures(void)
{
  return (WEARM_ENABLE_PICK_PLACE ? PROTO_FEATURE_PICK : 0u) |
         (WEARM_ENABLE_BUTTONS ? PROTO_FEATURE_BUTTON : 0u) |
         (WEARM_ENABLE_DRAW ? PROTO_FEATURE_DRAW : 0u);
}

static void protoReplyButtonResult(int result)
{
  (void)result;
  if (result == PROTO_RES_BUSY) {
    R_BUSY();
  } else if (result == PROTO_RES_REC_REJECTED) {
    R_DISCARD();
  } else if (result == PROTO_RES_PLAY_NO_RECORD) {
    R_EMPTY();
  } else if (result < 0) {
    R_ERR();
  } else {
    R_OK();
  }
}

static void protoRefuseModule(uint8_t feature)
{
  if ((protoCompiledFeatures() & feature) != 0u) {
    R_OFF();
  } else {
    R_REJ();
  }
}

static void protoFlushLine(void)
{
  s_line[s_len] = '\0';
  if (s_len > 0) {
    protoHandleLine(s_line);
  }
  s_len = 0;
  s_pending = false;
}

int protoHandleLine(const char *line)
{
  if (line == NULL) {
    return PROTO_RES_NONE;
  }

  const char *p = line;
  PROTO_SKIP_BLANKS(p);

  const char cmd = *p;
  if (cmd == '\0') {
    return PROTO_RES_NONE;
  }

  const char *tail = p + 1;
  PROTO_SKIP_BLANKS(tail);
  const bool single = (*tail == '\0');

  if (cmd == '!' && !single) {
    const char *q = tail;
    uint8_t feature;
    if (q[1] != '\0' || (q[0] != 'P' && q[0] != 'B' && q[0] != 'D')) {
      R_REJ();
      return PROTO_RES_UNKNOWN;
    }
    feature = q[0] == 'P' ? PROTO_FEATURE_PICK :
              q[0] == 'B' ? PROTO_FEATURE_BUTTON : PROTO_FEATURE_DRAW;
    if (!(protoCompiledFeatures() & feature)) {
      R_REJ();
      return PROTO_RES_UNKNOWN;
    }
    if (!protoRuntimeEnabled(feature)) s_runtimeFeatures |= feature;
    else s_runtimeFeatures &= (uint8_t)~feature;
    R_FEATURE();
    return PROTO_RES_FEATURE;
  }
  if (cmd == '!' && single) {
    R_FEATURE();
    return PROTO_RES_NONE;
  }

  if (!single && (cmd == PROTO_CMD_BTN_CYCLE || cmd == PROTO_CMD_BTN_RECORD ||
      cmd == PROTO_CMD_BTN_PLAY || cmd == PROTO_CMD_BTN_HOME ||
      cmd == PROTO_CMD_BTN_HOME_ALT)) {
    R_ERR();
    return PROTO_RES_BAD_SYNTAX;
  }
  if (single) {
    uint8_t module = protoCmdFeature(cmd);

    if (module != 0u) {
      uint8_t feature = (module == 1u) ? PROTO_FEATURE_PICK :
                        (module == 2u) ? PROTO_FEATURE_BUTTON : PROTO_FEATURE_DRAW;

      if (!protoRuntimeEnabled(feature)) {
        protoRefuseModule(feature);
        return PROTO_RES_UNKNOWN;
      }
    }
  }

  if (drawControlBusy() || buttonControlBusy() || pickPlaceIsBusy()) {
    if (!protoCmdBit(s_liveBits, cmd)) {
      R_BUSY();
      return PROTO_RES_BUSY;
    }
  }

  if (single) {
    if (cmd == PROTO_CMD_BTN_HOME_ALT) {
      int result = buttonHandleCommand(cmd);
      protoReplyButtonResult(result);
      return result < 0 ? PROTO_RES_UNKNOWN : result;
    }

    if (cmd == PROTO_CMD_GRIPPER_OPEN) {
      posSetAngle4(150.0);
      R_OKN();
      return PROTO_RES_GRIPPER_OPEN;

    } else if (cmd == PROTO_CMD_GRIPPER_CLOSE) {
      posSetAngle4(60.0);
      R_OKN();
      return PROTO_RES_GRIPPER_CLOSE;

    } else if (cmd == PROTO_CMD_SPEED_UP || cmd == PROTO_CMD_SPEED_DOWN) {
        protoSpeedStep((cmd == PROTO_CMD_SPEED_UP) ? +1 : -1);
        R_OK();
        return (cmd == PROTO_CMD_SPEED_UP) ? PROTO_RES_SPEED_UP : PROTO_RES_SPEED_DOWN;

    } else if (cmd == PROTO_CMD_PICK_A || cmd == PROTO_CMD_PICK_B ||
               cmd == PROTO_CMD_PICK_C) {
        int object = PICK_OBJECT_A + (cmd - PROTO_CMD_PICK_A);
        int rc = pickPlaceStart(object);
        if (rc == 0) {
          R_OK();
          return PROTO_RES_PICK_STARTED;
        }
        R_BUSY();
        return PROTO_RES_BUSY;

    } else if (cmd == PROTO_CMD_BTN_CYCLE || cmd == PROTO_CMD_BTN_RECORD ||
               cmd == PROTO_CMD_BTN_PLAY || cmd == PROTO_CMD_BTN_HOME) {
      int result = buttonHandleCommand(cmd);
      protoReplyButtonResult(result);
      return result < 0 ? PROTO_RES_UNKNOWN : result;

    } else if (cmd == PROTO_CMD_DRAW_TASK || cmd == PROTO_CMD_DRAW_START ||
               cmd == PROTO_CMD_DRAW_RECORD || cmd == PROTO_CMD_DRAW_UNDO ||
               cmd == PROTO_CMD_DRAW_PAUSE || cmd == PROTO_CMD_DRAW_RESUME ||
               cmd == PROTO_CMD_DRAW_CANCEL) {
      int result = drawHandleCommand(cmd);
      if (result == PROTO_RES_DRAW_TASK_SELECTED) {
        protoReplyTaskTag(drawTaskTag(drawGetTask()));
      } else if (result == PROTO_RES_BUSY) R_BUSY();
      else if (result == PROTO_RES_DRAW_REJECTED) R_REJ();
      else if (result < 0) R_ERR();
      else R_OK();
      return result;
    }
  }

  if ((cmd == PROTO_CMD_DRAW_PAPER_Z ||
       cmd == PROTO_CMD_DRAW_HALF ||
       cmd == PROTO_CMD_DRAW_CENTER) && !single) {
    if (!protoRuntimeEnabled(PROTO_FEATURE_DRAW)) {
      protoRefuseModule(PROTO_FEATURE_DRAW);
      return PROTO_RES_UNKNOWN;
    }
    int result = protoHandleDrawCalib(p, cmd);
    if (result == PROTO_RES_DRAW_REJECTED) R_REJ();
    return result;
  }

  if (protoAxisIndexFromChar(cmd) >= 0) {
    double angles[3];
    uint8_t seen = 0;

    if (!protoParseAxisLine(p, angles, &seen)) {
      R_ERR();
      return PROTO_RES_BAD_SYNTAX;
    }

    protoApplyAngles(angles, seen);

    R_OK();
    return PROTO_RES_ANGLES_SET;
  }

  {
    const char *scan = p;
    while (*scan != '\0' && *scan != ',') {
      scan++;
    }
    if (*scan != ',' && cmd != '=') {
      R_ERR();
      return PROTO_RES_UNKNOWN;
    }
  }

  R_ERR();
  return PROTO_RES_BAD_SYNTAX;
}

static bool protoParseAxisLine(const char *s, double angles[3], uint8_t *seen)
{
  const char *p = s;
  int groups = 0;

  for (;;) {
    PROTO_SKIP_BLANKS(p);

    int axis = protoAxisIndexFromChar(*p);
    if (axis < 0) return false;
    p++;

    PROTO_SKIP_BLANKS(p);

    if (*p == '=') {
      p++;
      PROTO_SKIP_BLANKS(p);
    }

    if (!protoParseNumber(&p, &angles[axis])) return false;

    *seen |= (uint8_t)(1u << axis);
    groups++;

    PROTO_SKIP_BLANKS(p);
    if (*p == '\0') break;
    if (*p != ',') return false;
    p++;
  }

  return (groups > 0);
}

static bool protoParseNumber(const char **pp, double *out)
{
  const char *p = *pp;
  bool neg = false;
  unsigned int ip = 0;
  double value;

  if (*p == '+') {
    p++;
  } else if (*p == '-') {
    neg = true;
    p++;
  }

  if (*p < '0' || *p > '9') {
    return false;
  }
  do {
    if (ip < 9999u) {
      ip = ip * 10u + (unsigned int)(*p - '0');
    }
    p++;
  } while (*p >= '0' && *p <= '9');

  value = (double)ip;

  if (*p == '.') {
    double decimal_place = 0.1;
    p++;
    if (*p < '0' || *p > '9') {
      return false;
    }
    do {
      value += (*p - '0') * decimal_place;
      decimal_place *= 0.1;
      p++;
    } while (*p >= '0' && *p <= '9');
  }

  *out = neg ? -value : value;
  *pp = p;
  return true;
}

static void protoApplyAngles(const double angles[3], uint8_t seen)
{
  for (int a = 0; a < PROTO_AXIS_COUNT; a++) {
    if ((seen & (uint8_t)(1u << a)) == 0u) continue;
    double v = angles[a];
    if (v < 0.0)   v = 0.0;
    if (v > 180.0) v = 180.0;
    (&Pos.ser.angle1)[a] = v;
  }

  (void) recFromServo(&Pos.rec, &Pos.ser);
}

static int protoHandleDrawCalib(const char *line, char cmd)
{
  const char *p = line + 1;
  double v1;
  double v2;

  PROTO_SKIP_BLANKS(p);
  if (!protoParseNumber(&p, &v1)) {
    R_ERR();
    return PROTO_RES_DRAW_REJECTED;
  }
  PROTO_SKIP_BLANKS(p);

  bool ok = false;
  if (cmd == PROTO_CMD_DRAW_PAPER_Z) {
    if (*p == '\0') ok = drawSetPaperZ(v1);
  } else if (cmd == PROTO_CMD_DRAW_HALF) {
    if (*p == '\0') ok = drawSetHalfSize(v1);
  } else if (*p == ',') {
    p++;
    PROTO_SKIP_BLANKS(p);
    if (protoParseNumber(&p, &v2) && *p == '\0') {
      ok = drawSetCenter(v1, v2);
    }
  }

  if (ok) {
    R_OK();
    return PROTO_RES_DRAW_CALIBRATED;
  }

  R_ERR();
  return PROTO_RES_DRAW_REJECTED;
}

static int protoSpeedStep(int delta)
{
  int current_level = speedGetLevel();

  if (current_level < PROTO_SPEED_LEVEL_MIN || current_level > PROTO_SPEED_LEVEL_MAX) {
    current_level = PROTO_SPEED_LEVEL_DEF;
  }

  int want_level = current_level + delta;

  if (want_level < PROTO_SPEED_LEVEL_MIN) {
    want_level = PROTO_SPEED_LEVEL_MIN;
  } else if (want_level > PROTO_SPEED_LEVEL_MAX) {
    want_level = PROTO_SPEED_LEVEL_MAX;
  }

  if (want_level == current_level) {
    return current_level;
  }

  want_level = adjustSpeed(want_level);
  return want_level;
}

void serialProtocolBegin(void)
{
  protoSerialBegin();
  s_runtimeFeatures = protoCompiledFeatures();

  R_BOOT();
}
