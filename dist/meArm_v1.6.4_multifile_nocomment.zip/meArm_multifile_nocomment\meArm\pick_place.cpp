#include <math.h>
#include <Arduino.h>
#include "constant_and_positions.h"
#include "path_core.h"
#include "pick_place.h"

#if WEARM_ENABLE_PICK_PLACE

#define PICK_GRASP_Z 12.0

#define PICK_APPROACH_DZ 6.0

struct pickPoint {
  double x;
  double y;
  double z;
};

static const struct pickPoint PICK_SRC[PICK_OBJECT_COUNT] PROGMEM = {
  { 24.0,  12.0, PICK_GRASP_Z },
  { 24.0, -12.0, PICK_GRASP_Z },
  { 12.0,  20.0, PICK_GRASP_Z }
};

static const struct pickPoint PICK_DST[PICK_OBJECT_COUNT] PROGMEM = {
  { 16.0, -14.0, PICK_GRASP_Z },
  { 18.0,  16.0, PICK_GRASP_Z },
  { 28.0,  -6.0, PICK_GRASP_Z }
};

static const char PICK_LETTER[PICK_OBJECT_COUNT] = { 'A', 'B', 'C' };

#define PICK_RATE_SLOW_DPS   25.0
#define PICK_RATE_NORMAL_DPS 50.0
#define PICK_RATE_FAST_DPS   90.0

#define PICK_TOOL_RATE_DPS 60.0
#define PICK_DWELL_MS      400

#define PICK_MIN_SEG_MS 180
#define PICK_MAX_SEG_MS 4000

#define PICK_PATH_SAMPLE_STEP 0.5
#define PICK_PATH_SAMPLE_MAX  64
#define PICK_BRANCH_JUMP_DEG  25.0

#define PICK_START_TOL_DEG 10.0

#define PICK_TOOL_OPEN_ANGLE  150.0
#define PICK_TOOL_CLOSE_ANGLE 60.0

enum {
  PICK_ST_IDLE = 0,
  PICK_ST_TO_SRC_APPROACH,
  PICK_ST_DESCEND_SRC,
  PICK_ST_CLOSE_TOOL,
  PICK_ST_DWELL_CLOSE,
  PICK_ST_LIFT,
  PICK_ST_TRAVERSE,
  PICK_ST_DESCEND_DST,
  PICK_ST_OPEN_TOOL,
  PICK_ST_DWELL_OPEN,
  PICK_ST_RETREAT
};

static const char *const PICK_STAGE_NAME[] = {
  "idle", "to-src-approach", "descend-src", "close-tool", "dwell-close",
  "lift", "traverse", "descend-dst", "open-tool", "dwell-open",
  "retreat"
};

enum { PICK_KIND_MOVE = 0, PICK_KIND_TOOL, PICK_KIND_DWELL };

static signed char s_obj = -1;
static signed char s_stage = PICK_ST_IDLE;
static signed char s_kind = PICK_KIND_DWELL;
static unsigned long s_stageStartMs = 0;
static unsigned short s_stageMs = 0;

static double s_fromX = 0.0, s_fromY = 0.0, s_fromZ = 0.0;
static double s_toX = 0.0, s_toY = 0.0, s_toZ = 0.0;

#ifdef __AVR__
#define PICK_COORD(tab, field) ((double)pgm_read_float((const float *)&(tab)->field))
#else
#define PICK_COORD(tab, field) ((double)((tab)->field))
#endif

static void loadPickPoint(const struct pickPoint *tab, double *out) {
  out[0] = PICK_COORD(tab, x);
  out[1] = PICK_COORD(tab, y);
  out[2] = PICK_COORD(tab, z);
}

static double pickRateDps(void) {
  int level = speedGetLevel();
  if (level == SPEED_SLOW) return PICK_RATE_SLOW_DPS;
  if (level == SPEED_FAST) return PICK_RATE_FAST_DPS;
  return PICK_RATE_NORMAL_DPS;
}

static unsigned long __attribute__((noinline, noclone))
durationMs(double degrees, double rateDps) {
  double ms = 0.0;
  if (degrees > 0.0 && rateDps > 0.0) {
    ms = degrees / rateDps * 1000.0;
  }
  if (ms < (double)PICK_MIN_SEG_MS) ms = (double)PICK_MIN_SEG_MS;
  if (ms > (double)PICK_MAX_SEG_MS) ms = (double)PICK_MAX_SEG_MS;
  return (unsigned long)(ms + 0.5);
}

static void beginMove(int stage, const double *p, int rise) {
  s_stage = (signed char)stage;
  s_kind = PICK_KIND_MOVE;
  s_fromX = Pos.rec.x;
  s_fromY = Pos.rec.y;
  s_fromZ = Pos.rec.z;
  s_toX = p[0];
  s_toY = p[1];
  s_toZ = rise ? (p[2] + PICK_APPROACH_DZ) : p[2];
  s_stageStartMs = millis();

  double dMax = 0.0;
  double b = 0.0, r = 0.0, c = 0.0;
  if (pathCoreSolveJoint(s_toX, s_toY, s_toZ, &b, &r, &c)) {
    double d;
    d = fabs(b - Pos.ser.angle1); if (d > dMax) dMax = d;
    d = fabs(r - Pos.ser.angle2); if (d > dMax) dMax = d;
    d = fabs(c - Pos.ser.angle3); if (d > dMax) dMax = d;
  }
  s_stageMs = (unsigned short)durationMs(dMax, pickRateDps());
}

static void __attribute__((noinline, noclone))
beginTool(int stage, double targetAngle) {
  s_stage = (signed char)stage;
  s_kind = PICK_KIND_TOOL;
  s_fromX = Pos.ser.angle4;
  s_toX = targetAngle;
  s_stageStartMs = millis();
  s_stageMs = (unsigned short)durationMs(fabs(s_toX - s_fromX), PICK_TOOL_RATE_DPS);
}

static void beginDwell(int stage, unsigned long ms) {
  s_stage = (signed char)stage;
  s_kind = PICK_KIND_DWELL;
  s_stageStartMs = millis();
  s_stageMs = (unsigned short)ms;
}

static void finishSequence(void) {
#if WEARM_DEBUG_SERIAL
  Serial.print(F("[pick] "));
  Serial.print(PICK_LETTER[s_obj]);
  Serial.print(F(" done, retreat pos = ("));
  Serial.print(Pos.rec.x, 2);
  Serial.print(F(", "));
  Serial.print(Pos.rec.y, 2);
  Serial.print(F(", "));
  Serial.print(Pos.rec.z, 2);
  Serial.println(F(")"));
#endif
  s_obj = -1;
  s_stage = PICK_ST_IDLE;
  s_kind = PICK_KIND_DWELL;
  s_stageMs = 0;
  s_stageStartMs = millis();
}

#if WEARM_DEBUG_SERIAL
static void abortSequence(const __FlashStringHelper *why) {
  Serial.print(F("[pick] ERROR: "));
  Serial.print(why);
  Serial.println(F(", sequence aborted (arm holds position)"));
  s_obj = -1;
  s_stage = PICK_ST_IDLE;
  s_kind = PICK_KIND_DWELL;
  s_stageMs = 0;
  s_stageStartMs = millis();
}
#define PICK_ABORT(msg) abortSequence(F(msg))
#else
static void abortSequence(void) {
  s_obj = -1;
  s_stage = PICK_ST_IDLE;
  s_kind = PICK_KIND_DWELL;
  s_stageMs = 0;
  s_stageStartMs = millis();
}
#define PICK_ABORT(msg) abortSequence()
#endif

static void advanceStage(void) {
  double src[3], dst[3];
  loadPickPoint(&PICK_SRC[s_obj], src);
  loadPickPoint(&PICK_DST[s_obj], dst);

  switch (s_stage) {
    case PICK_ST_TO_SRC_APPROACH:
      beginMove(PICK_ST_DESCEND_SRC, src, 0);
      break;

    case PICK_ST_DESCEND_SRC:
      beginTool(PICK_ST_CLOSE_TOOL, PICK_TOOL_CLOSE_ANGLE);
      break;

    case PICK_ST_CLOSE_TOOL:
#if WEARM_DEBUG_SERIAL
      Serial.print(F("[pick] gripper closed at angle4 = "));
      Serial.println(Pos.ser.angle4);
#endif
      beginDwell(PICK_ST_DWELL_CLOSE, PICK_DWELL_MS);
      break;

    case PICK_ST_DWELL_CLOSE:
      beginMove(PICK_ST_LIFT, src, 1);
      break;

    case PICK_ST_LIFT:
      beginMove(PICK_ST_TRAVERSE, dst, 1);
      break;

    case PICK_ST_TRAVERSE:
      beginMove(PICK_ST_DESCEND_DST, dst, 0);
      break;

    case PICK_ST_DESCEND_DST:
      beginTool(PICK_ST_OPEN_TOOL, PICK_TOOL_OPEN_ANGLE);
      break;

    case PICK_ST_OPEN_TOOL:
#if WEARM_DEBUG_SERIAL
      Serial.print(F("[pick] gripper opened at angle4 = "));
      Serial.println(Pos.ser.angle4);
#endif
      beginDwell(PICK_ST_DWELL_OPEN, PICK_DWELL_MS);
      break;

    case PICK_ST_DWELL_OPEN:
      beginMove(PICK_ST_RETREAT, dst, 1);
      break;

    case PICK_ST_RETREAT:
      finishSequence();
      break;

    default:
      PICK_ABORT("unexpected stage");
      break;
  }
}

int pickPlaceStart(int object) {
  if (object < 0 || object >= PICK_OBJECT_COUNT) return -1;

  if (s_obj >= 0) {
#if WEARM_DEBUG_SERIAL
    Serial.print(F("[pick] busy: "));
    Serial.print(PICK_LETTER[s_obj]);
    Serial.println(F(" still running, command ignored"));
#endif
    return -2;
  }

  double srcP[3], dstP[3], srcRiseP[3], dstRiseP[3];
  loadPickPoint(&PICK_SRC[object], srcP);
  loadPickPoint(&PICK_DST[object], dstP);
  srcRiseP[0] = srcP[0]; srcRiseP[1] = srcP[1]; srcRiseP[2] = srcP[2] + PICK_APPROACH_DZ;
  dstRiseP[0] = dstP[0]; dstRiseP[1] = dstP[1]; dstRiseP[2] = dstP[2] + PICK_APPROACH_DZ;

  double b = 0.0, r = 0.0, c = 0.0;
  if (!pathCorePointOk(Pos.rec.x, Pos.rec.y, Pos.rec.z, &b, &r, &c)) return -3;
  if (fabs(b - Pos.ser.angle1) > PICK_START_TOL_DEG ||
      fabs(r - Pos.ser.angle2) > PICK_START_TOL_DEG ||
      fabs(c - Pos.ser.angle3) > PICK_START_TOL_DEG) {
#if WEARM_DEBUG_SERIAL
    Serial.println(F("[pick] rejected: current pose is not on the ik branch of its own"
                     " coordinates, run posInit()/回到初始位姿后再试"));
#endif
    return -3;
  }

  double curP[3];
  curP[0] = Pos.rec.x; curP[1] = Pos.rec.y; curP[2] = Pos.rec.z;
  if (!pathCoreSegmentOk(curP, srcRiseP, PICK_PATH_SAMPLE_STEP,
                         PICK_PATH_SAMPLE_MAX, PICK_BRANCH_JUMP_DEG) ||
      !pathCoreSegmentOk(srcRiseP, srcP, PICK_PATH_SAMPLE_STEP,
                         PICK_PATH_SAMPLE_MAX, PICK_BRANCH_JUMP_DEG) ||
      !pathCoreSegmentOk(srcRiseP, dstRiseP, PICK_PATH_SAMPLE_STEP,
                         PICK_PATH_SAMPLE_MAX, PICK_BRANCH_JUMP_DEG) ||
      !pathCoreSegmentOk(dstRiseP, dstP, PICK_PATH_SAMPLE_STEP,
                         PICK_PATH_SAMPLE_MAX, PICK_BRANCH_JUMP_DEG)) {
#if WEARM_DEBUG_SERIAL
    Serial.print(F("[pick] rejected: path check failed for "));
    Serial.println(PICK_LETTER[object]);
#endif
    return -3;
  }

  s_obj = (signed char)object;
#if WEARM_DEBUG_SERIAL
  Serial.print(F("[pick] start "));
  Serial.print(PICK_LETTER[object]);
  Serial.print(F(": src=("));
  Serial.print(srcP[0], 2);
  Serial.print(F(", "));
  Serial.print(srcP[1], 2);
  Serial.print(F(", "));
  Serial.print(srcP[2], 2);
  Serial.print(F(") dst=("));
  Serial.print(dstP[0], 2);
  Serial.print(F(", "));
  Serial.print(dstP[1], 2);
  Serial.print(F(", "));
  Serial.print(dstP[2], 2);
  Serial.print(F(") speed="));
  Serial.println(speedLevelName(speedGetLevel()));
#endif

  beginMove(PICK_ST_TO_SRC_APPROACH, srcP, 1);
  return 0;
}

void pickPlaceLoop(void) {
  if (s_obj < 0 || s_stage == PICK_ST_IDLE) return;

  unsigned long elapsed = millis() - s_stageStartMs;
  bool stageDone = (elapsed >= s_stageMs);
  double t = 1.0;
  if (!stageDone && s_stageMs > 0) {
    t = (double)elapsed / (double)s_stageMs;
  }

  if (s_kind == PICK_KIND_MOVE) {
    double x = s_fromX + (s_toX - s_fromX) * t;
    double y = s_fromY + (s_toY - s_fromY) * t;
    double z = s_fromZ + (s_toZ - s_fromZ) * t;
    double b = 0.0, r = 0.0, c = 0.0;
    if (!pathCoreSolveJoint(x, y, z, &b, &r, &c)) {
      PICK_ABORT("ik failed mid-path");
      return;
    }
    pathCoreSetJoints(b, r, c);
  } else if (s_kind == PICK_KIND_TOOL) {
    (void) posSetAngle4(s_fromX + (s_toX - s_fromX) * t);
  } else {
  }

  if (stageDone) advanceStage();
}

bool pickPlaceIsBusy(void) {
  return s_obj >= 0;
}

int pickPlaceCurrentObject(void) {
  return s_obj;
}

const char *pickPlaceStageName(void) {
  return PICK_STAGE_NAME[s_stage];
}

bool pickPlaceGetSource(int object, double *x, double *y, double *z) {
  if (object < 0 || object >= PICK_OBJECT_COUNT) return false;
  if (x) *x = PICK_COORD(&PICK_SRC[object], x);
  if (y) *y = PICK_COORD(&PICK_SRC[object], y);
  if (z) *z = PICK_COORD(&PICK_SRC[object], z);
  return true;
}

bool pickPlaceGetTarget(int object, double *x, double *y, double *z) {
  if (object < 0 || object >= PICK_OBJECT_COUNT) return false;
  if (x) *x = PICK_COORD(&PICK_DST[object], x);
  if (y) *y = PICK_COORD(&PICK_DST[object], y);
  if (z) *z = PICK_COORD(&PICK_DST[object], z);
  return true;
}

double pickPlaceApproachDz(void) {
  return PICK_APPROACH_DZ;
}
#endif
