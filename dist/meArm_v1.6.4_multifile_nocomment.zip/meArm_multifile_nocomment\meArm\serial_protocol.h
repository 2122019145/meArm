#ifndef WEARM_SERIAL_PROTOCOL_H
#define WEARM_SERIAL_PROTOCOL_H

#include "constant_and_positions.h"

#ifndef WEARM_SERIAL_RESPONSES
#define WEARM_SERIAL_RESPONSES 1
#endif

#define PROTO_RES_NONE          0
#define PROTO_RES_GRIPPER_OPEN  1
#define PROTO_RES_GRIPPER_CLOSE 2
#define PROTO_RES_SPEED_UP      3
#define PROTO_RES_SPEED_DOWN    4
#define PROTO_RES_SPEED_LEVEL   5
#define PROTO_RES_FEATURE       6
#define PROTO_RES_ANGLES_SET    7
#define PROTO_RES_UNKNOWN       8
#define PROTO_RES_BAD_SYNTAX    9
#define PROTO_RES_PICK_STARTED 10
#define PROTO_RES_BUSY         11

#define PROTO_RES_REC_STARTED    12
#define PROTO_RES_REC_SAVED      13
#define PROTO_RES_REC_REJECTED   14
#define PROTO_RES_PLAY_STARTED   15
#define PROTO_RES_PLAY_NO_RECORD 16
#define PROTO_RES_HOME_STARTED   17

#define PROTO_RES_DRAW_TASK_SELECTED 18
#define PROTO_RES_DRAW_STARTED       19
#define PROTO_RES_DRAW_PAUSED        20
#define PROTO_RES_DRAW_RESUMED       21
#define PROTO_RES_DRAW_CANCELED      22
#define PROTO_RES_DRAW_TEACH_POINT   23
#define PROTO_RES_DRAW_TEACH_UNDO    24
#define PROTO_RES_DRAW_REJECTED      25
#define PROTO_RES_DRAW_CALIBRATED    26

void serialProtocolBegin(void);

void serialProtocolLoop(void);

int protoHandleLine(const char *line);

#endif
