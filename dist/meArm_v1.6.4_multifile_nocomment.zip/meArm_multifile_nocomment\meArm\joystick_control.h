#ifndef WEARM_JOYSTICK_CONTROL_H
#define WEARM_JOYSTICK_CONTROL_H

#include "Arduino.h"
#include "constant_and_positions.h"
#include "move.h"

struct joyState {
  int base;
  int shoulder;
  int elbow;
  int tool;

  int sx;
  int sy;
  int tx;
  int ty;

  int dir;
  int mag;
  int mask;
};

#define JOY_DIR_NONE   0
#define JOY_DIR_RIGHT  2
#define JOY_DIR_BWD    3
#define JOY_DIR_LEFT   4
#define JOY_DIR_FWD    5
#define JOY_DIR_UP     6
#define JOY_DIR_DOWN   7

#define JOY_ACT_BASE     0x01
#define JOY_ACT_SHOULDER 0x02
#define JOY_ACT_ELBOW    0x04
#define JOY_ACT_TOOL     0x08

void joystickSetup(void);

void joystickReadState(struct joyState *st);

int joystickRead(void);

void joystickLoop(void);

#endif
