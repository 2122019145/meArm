#ifndef PICK_PLACE_H
#define PICK_PLACE_H

#include "weArm_config.h"

#define PICK_OBJECT_A 0
#define PICK_OBJECT_B 1
#define PICK_OBJECT_C 2
#define PICK_OBJECT_COUNT 3

#if WEARM_ENABLE_PICK_PLACE
int pickPlaceStart(int object);

void pickPlaceLoop(void);

bool pickPlaceIsBusy(void);

int pickPlaceCurrentObject(void);

const char *pickPlaceStageName(void);

bool pickPlaceGetSource(int object, double *x, double *y, double *z);
bool pickPlaceGetTarget(int object, double *x, double *y, double *z);

double pickPlaceApproachDz(void);
#else
static inline int  pickPlaceStart(int object)   { (void)object; return -1; }
static inline void pickPlaceLoop(void)          { }
static inline bool pickPlaceIsBusy(void)        { return false; }
static inline int  pickPlaceCurrentObject(void) { return -1; }
static inline const char *pickPlaceStageName(void) { return ""; }
static inline bool pickPlaceGetSource(int object, double *x, double *y, double *z)
    { (void)object; (void)x; (void)y; (void)z; return false; }
static inline bool pickPlaceGetTarget(int object, double *x, double *y, double *z)
    { (void)object; (void)x; (void)y; (void)z; return false; }
static inline double pickPlaceApproachDz(void)  { return 0.0; }
#endif

#endif
