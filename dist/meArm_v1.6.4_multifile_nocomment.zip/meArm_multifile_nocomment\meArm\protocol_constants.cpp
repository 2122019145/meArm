#include "Arduino.h"
#include "protocol_constants.h"
#include "constant_and_positions.h"

const char protoAxisChar[PROTO_AXIS_COUNT] = { 'x', 'y', 'z' };

const char protoAxisJoint[PROTO_AXIS_COUNT] = { 'b', 'r', 'c' };

int protoAxisIndexFromChar(int c)
{
  char lower_c = (char)c;
  if (c >= 'A' && c <= 'Z') {
    lower_c = (char)(c - 'A' + 'a');
  }

  for (int i = 0; i < PROTO_AXIS_COUNT; i++) {
    if (protoAxisChar[i] == lower_c) {
      return i;
    }
  }
  return -1;
}

bool protoAxisGetLimit(int axis, double *minAngle, double *maxAngle)
{
  if (axis < 0 || axis >= PROTO_AXIS_COUNT || minAngle == NULL || maxAngle == NULL) {
    return false;
  }

  *minAngle = 0.0;
  *maxAngle = 180.0;

  return true;
}
