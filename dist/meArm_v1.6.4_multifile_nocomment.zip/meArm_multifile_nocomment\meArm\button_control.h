#ifndef BUTTON_CONTROL_H
#define BUTTON_CONTROL_H

#include "Arduino.h"
#include "constant_and_positions.h"
#include "serial_protocol.h"
#include "weArm_config.h"

#define BTN_COUNT      4
#define BTN_KEY_CYCLE  0
#define BTN_KEY_RECORD 1
#define BTN_KEY_PLAY   2
#define BTN_KEY_HOME   3

#if WEARM_ENABLE_BUTTONS
void buttonSetup(void);

void buttonLoop(void);

int buttonHandleCommand(char c);

bool buttonIsCommandChar(char c);

int buttonPickNext(void);

bool buttonIsRecording(void);
bool buttonPlaybackActive(void);

int buttonRecordingEntries(void);

unsigned long buttonRecordingMs(void);
double buttonRecordingTravel(void);

bool buttonHasRecording(void);

bool buttonControlBusy(void);

bool buttonControlLocked(void);

const char *buttonName(int key);
const char *buttonStateName(void);
#else
static inline void buttonSetup(void)                 {}
static inline void buttonLoop(void)                  {}
static inline int  buttonHandleCommand(char c)       { (void)c; return -1; }
static inline bool buttonIsCommandChar(char c)       { (void)c; return false; }
static inline int  buttonPickNext(void)              { return -1; }
static inline bool buttonIsRecording(void)           { return false; }
static inline bool buttonPlaybackActive(void)        { return false; }
static inline int  buttonRecordingEntries(void)      { return 0; }
static inline unsigned long buttonRecordingMs(void)  { return 0UL; }
static inline double buttonRecordingTravel(void)     { return 0.0; }
static inline bool buttonHasRecording(void)          { return false; }
static inline bool buttonControlBusy(void)           { return false; }
static inline bool buttonControlLocked(void)         { return false; }
static inline const char *buttonName(int key)       { (void)key; return ""; }
static inline const char *buttonStateName(void)     { return ""; }
#endif

#endif
