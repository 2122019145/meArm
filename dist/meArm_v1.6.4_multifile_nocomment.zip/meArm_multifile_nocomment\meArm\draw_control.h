#ifndef DRAW_CONTROL_H
#define DRAW_CONTROL_H

#include "Arduino.h"
#include "constant_and_positions.h"
#include "serial_protocol.h"
#include "weArm_config.h"

#define DRAW_TASK_LINE      0
#define DRAW_TASK_N         1
#define DRAW_TASK_TRIANGLE  2
#define DRAW_TASK_Z         3
#define DRAW_TASK_V         4
#define DRAW_TASK_POLYLINE  5
#define DRAW_TASK_CURVE     6
#define DRAW_TASK_COUNT     7

#define DRAW_TEACH_MAX_POINTS 5

#define DRAW_KEY_1 0
#define DRAW_KEY_2 1
#define DRAW_KEY_3 2
#define DRAW_KEY_4 3

#define DRAW_PHASE_IDLE      0
#define DRAW_PHASE_HOME      1
#define DRAW_PHASE_TRAVEL    2
#define DRAW_PHASE_PLUNGE    3
#define DRAW_PHASE_PATH      4
#define DRAW_PHASE_LIFT      5
#define DRAW_PHASE_TEACH     6
#define DRAW_PHASE_TEACH_WAIT 7
#define DRAW_PHASE_RETURN    8

#if WEARM_ENABLE_DRAW
void drawSetup(void);

void drawLoop(void);

int drawSelectTask(int task);
int drawTaskCycle(void);
int drawGetTask(void);
const char *drawTaskName(int task);
const char *drawTaskTag(int task);

int drawStartTask(void);

int drawHandleCommand(char c);
bool drawIsCommandChar(char c);

bool drawSetPaperZ(double z);
double drawGetPaperZ(void);
bool drawSetHalfSize(double half);
double drawGetHalfSize(void);
bool drawSetCenter(double x, double y);
double drawGetCenterX(void);
double drawGetCenterY(void);

int drawTeachRecord(void);
int drawTeachUndo(void);
int drawTeachFinish(void);
int drawTeachCount(void);

int drawPause(void);
int drawResume(void);
int drawCancel(void);

int drawHandleButton(int key);
bool drawAcceptButton(int key);

bool drawControlBusy(void);
bool drawControlLocked(void);
int drawGetPhase(void);
const char *drawPhaseName(void);
const char *drawStateName(void);
bool drawIsPaused(void);

unsigned long drawLastRunMs(void);
int drawLastPointsHit(void);
int drawLastPointsTotal(void);
int drawLastResult(void);
#else
static inline void drawSetup(void) { }
static inline void drawLoop(void) { }

static inline int drawSelectTask(int task) { (void)task; return -1; }
static inline int drawTaskCycle(void) { return -1; }
static inline int drawGetTask(void) { return -1; }
static inline const char *drawTaskName(int task) { (void)task; return ""; }
static inline const char *drawTaskTag(int task) { (void)task; return ""; }
static inline int drawStartTask(void) { return -1; }

static inline int drawHandleCommand(char c) { (void)c; return -1; }
static inline bool drawIsCommandChar(char c) { (void)c; return false; }

static inline bool drawSetPaperZ(double z) { (void)z; return false; }
static inline double drawGetPaperZ(void) { return 0.0; }
static inline bool drawSetHalfSize(double half) { (void)half; return false; }
static inline double drawGetHalfSize(void) { return 0.0; }
static inline bool drawSetCenter(double x, double y) { (void)x; (void)y; return false; }
static inline double drawGetCenterX(void) { return 0.0; }
static inline double drawGetCenterY(void) { return 0.0; }

static inline int drawTeachRecord(void) { return -1; }
static inline int drawTeachUndo(void) { return -1; }
static inline int drawTeachFinish(void) { return -1; }
static inline int drawTeachCount(void) { return 0; }

static inline int drawPause(void) { return -1; }
static inline int drawResume(void) { return -1; }
static inline int drawCancel(void) { return -1; }

static inline int drawHandleButton(int key) { (void)key; return -1; }
static inline bool drawAcceptButton(int key) { (void)key; return false; }

static inline bool drawControlBusy(void) { return false; }
static inline bool drawControlLocked(void) { return false; }
static inline int drawGetPhase(void) { return -1; }
static inline const char *drawPhaseName(void) { return ""; }
static inline const char *drawStateName(void) { return ""; }
static inline bool drawIsPaused(void) { return false; }

static inline unsigned long drawLastRunMs(void) { return 0UL; }
static inline int drawLastPointsHit(void) { return 0; }
static inline int drawLastPointsTotal(void) { return 0; }
static inline int drawLastResult(void) { return -1; }
#endif

#endif
