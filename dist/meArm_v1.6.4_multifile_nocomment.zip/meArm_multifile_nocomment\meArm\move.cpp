#include "move.h"
#include "constant_and_positions.h"
#include "path_core.h"

static const unsigned char DIR_CODE[7] PROGMEM = {
  0,
  (2 << 1) | 0,
  (2 << 1) | 1,
  (0 << 1) | 1,
  (0 << 1) | 0,
  (1 << 1) | 0,
  (1 << 1) | 1
};

static bool samePose(const SER *a, const SER *b) {
  const unsigned char *pa = (const unsigned char *)a;
  const unsigned char *pb = (const unsigned char *)b;
  for (unsigned char i = 0; i < 3 * sizeof(double); i++) {
    if (pa[i] != pb[i]) return false;
  }
  return true;
}

static void clampBCR(SER *s) {
  if (s->angle1 < 0.0)   s->angle1 = 0.0;
  if (s->angle1 > 180.0) s->angle1 = 180.0;
  if (s->angle2 < 0.0)   s->angle2 = 0.0;
  if (s->angle2 > 180.0) s->angle2 = 180.0;
  if (s->angle3 < 0.0)   s->angle3 = 0.0;
  if (s->angle3 > 180.0) s->angle3 = 180.0;
}

int moveJointStep(int dir, double stepSize) {
  if (stepSize <= 0) stepSize = speed.stepSize;

  if (dir <= 0 || dir > JOINT_R_BWD) {
    return MOVE_NONE;
  }
  SER next = Pos.ser;
  unsigned char code = pgm_read_byte(&DIR_CODE[dir]);
  double *ap = &next.angle1 + (code >> 1);
  double step = stepSize;
  if (code & 1) step = -step;
  *ap += step;

  clampBCR(&next);
  if (samePose(&next, &Pos.ser)) {
    return MOVE_AT_LIMIT;
  }

  REC nextRec;
  if (!recFromServo(&nextRec, &next)) {
    return MOVE_UNREACHABLE;
  }

  Pos.ser = next;
  Pos.rec = nextRec;
  return MOVE_OK;
}

static void stepFixed(int dir) {
  (void) moveJointStep(dir, 1.0);
}

void moveup(void)       { stepFixed(JOINT_C_UP); }
void movedown(void)     { stepFixed(JOINT_C_DOWN); }
void moveleft(void)     { stepFixed(JOINT_B_LEFT); }
void moveright(void)    { stepFixed(JOINT_B_RIGHT); }
void moveforward(void)  { stepFixed(JOINT_R_FWD); }
void movebackward(void) { stepFixed(JOINT_R_BWD); }

int moveToPoint(const double *goal, uint8_t seen, double maxDps, double dtSec, int mode) {
  if (goal == NULL) return MOVE_XYZ_REJECTED;

  pos target = Pos;
  if (seen & (uint8_t)(1u << 0)) target.rec.x = goal[0];
  if (seen & (uint8_t)(1u << 1)) target.rec.y = goal[1];
  if (seen & (uint8_t)(1u << 2)) target.rec.z = goal[2];

  bool clamped = false;
  if (!getAngleEx(&target, &clamped)) return MOVE_XYZ_REJECTED;

  if (mode == MOVE_XYZ_NOW) {
    Pos = target;
    (void) recFromServo(&Pos.rec, &Pos.ser);
    return MOVE_XYZ_OK;
  }

  if (clamped) return MOVE_XYZ_REJECTED;

  double cur[3];
  cur[0] = Pos.ser.angle1;
  cur[1] = Pos.ser.angle2;
  cur[2] = Pos.ser.angle3;
  double tgt[3];
  tgt[0] = target.ser.angle1;
  tgt[1] = target.ser.angle2;
  tgt[2] = target.ser.angle3;

  double maxStep = maxDps * dtSec;
  if (maxStep < 0.2) maxStep = 0.2;

  if (mode == MOVE_XYZ_TRACK) {
    for (unsigned char i = 0; i < 3; i++) {
      if (fabs(tgt[i] - cur[i]) > maxStep) return MOVE_XYZ_REJECTED;
    }
    pathCoreSetJoints(tgt[0], tgt[1], tgt[2]);
    return MOVE_XYZ_OK;
  }

  if (mode != MOVE_XYZ_JOG) return MOVE_XYZ_REJECTED;

  double d[3];
  for (unsigned char i = 0; i < 3; i++) {
    d[i] = tgt[i] - cur[i];
    if (d[i] > maxStep) d[i] = maxStep;
    else if (d[i] < -maxStep) d[i] = -maxStep;
  }
  pathCoreSetJoints(cur[0] + d[0], cur[1] + d[1], cur[2] + d[2]);
  return MOVE_XYZ_OK;
}
