#ifndef WEARM_PROTOCOL_CONSTANTS_H
#define WEARM_PROTOCOL_CONSTANTS_H

#include "constant_and_positions.h"

#define PROTO_CMD_GRIPPER_OPEN   'O'
#define PROTO_CMD_GRIPPER_CLOSE  'S'
#define PROTO_CMD_SPEED_UP       'H'
#define PROTO_CMD_SPEED_DOWN     'L'

#define PROTO_CMD_PICK_A    'A'
#define PROTO_CMD_PICK_B    'B'
#define PROTO_CMD_PICK_C    'C'

#define PROTO_CMD_BTN_CYCLE    'N'
#define PROTO_CMD_BTN_RECORD   'R'
#define PROTO_CMD_BTN_PLAY     'P'
#define PROTO_CMD_BTN_HOME     'M'
#define PROTO_CMD_BTN_HOME_ALT '0'

#define PROTO_CMD_DRAW_TASK    'F'
#define PROTO_CMD_DRAW_START   'D'
#define PROTO_CMD_DRAW_RECORD  'G'
#define PROTO_CMD_DRAW_UNDO    'E'
#define PROTO_CMD_DRAW_PAUSE   'Q'
#define PROTO_CMD_DRAW_RESUME  'U'
#define PROTO_CMD_DRAW_CANCEL  'W'

#define PROTO_CMD_DRAW_PAPER_Z 'p'
#define PROTO_CMD_DRAW_HALF    'n'
#define PROTO_CMD_DRAW_CENTER  'o'

#define PROTO_AXIS_COUNT 3
extern const char protoAxisChar[PROTO_AXIS_COUNT];
extern const char protoAxisJoint[PROTO_AXIS_COUNT];

#define PROTO_LINE_BUF_SIZE 40
#define PROTO_BAUD          115200
#define PROTO_LINE_TIMEOUT_MS 300

#define PROTO_SPEED_LEVEL_MIN SPEED_SLOW
#define PROTO_SPEED_LEVEL_MAX SPEED_FAST
#define PROTO_SPEED_LEVEL_DEF SPEED_NORMAL

int protoAxisIndexFromChar(int c);

bool protoAxisGetLimit(int axis, double *minAngle, double *maxAngle);

#endif
