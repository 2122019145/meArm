#ifndef WEARM_CONSTANT_AND_POSITIONS_H
#define WEARM_CONSTANT_AND_POSITIONS_H

#include <math.h>
#include <stdbool.h>

#define RADtoDEG (180 / 3.1415926535)
#ifndef PI
#define PI 3.1415926535
#endif
#define ANGLE_EPS 1e-6

struct arm {
  double armLength1;
  double armLength2;
  double armheight;
};

typedef struct servoAngle {
  double angle1;
  double angle2;
  double angle3;
  double angle4;
} SER;

typedef struct rectangularCoordinate {
  double x;
  double y;
  double z;
} REC;

typedef struct position {
  SER ser;
  REC rec;
} pos;

extern pos Pos;
extern struct arm arm1;

#define SERVO_LIMIT_CLAMP  0
#define SERVO_LIMIT_REJECT 1
extern int servoLimitMode;

struct speedCfg {
  double stepSize;
  int    stepDelayMs;
};
extern struct speedCfg speed;

bool isReachable(const REC *rec);

bool getAngle(pos *pos1);

bool getAngleEx(pos *pos1, bool *clamped);

bool recFromServo(REC *rec, const SER *ser);

void posInit(void);

bool posGetHomeAngles(SER *ser);

bool posSetAngle4(double angleDeg);

void setSpeed(double stepSize, int stepDelayMs);

#define SPEED_SLOW   0
#define SPEED_NORMAL 1
#define SPEED_FAST   2
int  adjustSpeed(int level);
int  speedGetLevel(void);
const char *speedLevelName(int level);
int  speedStepDown(void);

#endif
