meArm v1.6.4 源码（无注释版，多文件版）
========================================

这个包和仓库里的源码**功能完全一样**，只是把所有注释删掉了。

怎么来的：.selfcheck\strip_comments.py（一个 C/C++ 词法状态机）逐个文件删注释，
字符串字面量里的 // 与 /* 不会被动到，行尾以反斜杠续行的 // 注释按 C 规则处理。

怎么保证没删错：每个文件都做了"预处理记号流逐字符相同"的比对
（g++ -E -P 的输出折叠空白后比 SHA256，全功能与功能全关两种宏配置各比一遍），
并且用 -Wall -Wextra -Wshadow -Wconversion 严格编译过、零警告。

包内文件（21 个，Arduino 草图目录 meArm\）：
    meArm\button_control.cpp
    meArm\button_control.h
    meArm\constant_and_positions.cpp
    meArm\constant_and_positions.h
    meArm\draw_control.cpp
    meArm\draw_control.h
    meArm\joystick_control.cpp
    meArm\joystick_control.h
    meArm\meArm.ino
    meArm\move.cpp
    meArm\move.h
    meArm\path_core.h
    meArm\pick_place.cpp
    meArm\pick_place.h
    meArm\protocol_constants.cpp
    meArm\protocol_constants.h
    meArm\serial_protocol.cpp
    meArm\serial_protocol.h
    meArm\servo_drive.cpp
    meArm\servo_drive.h
    meArm\weArm_config.h

要不要带注释的版本：仓库根目录的 21 个文件（多文件版）或 single/meArm/meArm.ino
（单文件版）就是带注释版；.selfcheck\README.md 里有全部设计说明。

注意：注释删掉后行号不再与仓库里的带注释版对应，串口调试或编译报错的行号会不一样。