#include "servo_drive.h"
#include "constant_and_positions.h"
#include "joystick_control.h"
#include "serial_protocol.h"
#include "pick_place.h"
#include "button_control.h"
#include "draw_control.h"

void writeServo(void){
#if WEARM_MIRROR_BASE
    servoDriveWrite(0, 180.0 - Pos.ser.angle1);
#else
    servoDriveWrite(0, Pos.ser.angle1);
#endif

    servoDriveWrite(1, Pos.ser.angle2);
    servoDriveWrite(2, Pos.ser.angle3);

#if WEARM_MIRROR_TOOL
    servoDriveWrite(3, (60.0 + 150.0) - Pos.ser.angle4);
#else
    servoDriveWrite(3, Pos.ser.angle4);
#endif
}

void setup() {
  posInit();

  serialProtocolBegin();

  joystickSetup();

  buttonSetup();

  drawSetup();

  servoDriveBegin();
  servoDriveAttach(0, 9);
  servoDriveAttach(1, 7);
  servoDriveAttach(2, 8);
  servoDriveAttach(3, 6);

  writeServo();

}

void loop() {
  serialProtocolLoop();

  pickPlaceLoop();

  buttonLoop();

  drawLoop();

  joystickLoop();

  writeServo();
}
