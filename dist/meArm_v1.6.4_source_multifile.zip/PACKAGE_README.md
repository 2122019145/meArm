# meArm 机械臂固件 —— 代码包说明（多文件版，v1.6.4 工作区）

这个包是**多文件版本的完整源码**（不是 `single/meArm/meArm.ino` 那种单文件合并版，
单文件版也随包提供，见下）。打包时的代码状态 = 本地 `main` 分支 v1.6.3 之上、
已按题目要求做完下面三件事的工作区。

## 这一版相对 v1.6.3 改了什么

1. **串口 `x/y/z` 改回角度语义**
   题目给的例子是 `x10,y30,z20`，要求"三个指定舵机的 PWM 占空比同步改变"，
   所以 `x/y/z` 直接写三个关节角，不做逆解：

   | 轴 | 舵机 | 变量 |
   | --- | --- | --- |
   | `x` | 基座 b | `Pos.ser.angle1` |
   | `y` | 上臂 r | `Pos.ser.angle2` |
   | `z` | 下臂 c | `Pos.ser.angle3` |

   落地流程：`protoParseAxisLine()` 解析 → `protoApplyAngles()` 写角 →
   `clampServoAngles()` 按 `servoLimit` 夹取 → `recFromServo()` 刷新 `Pos.rec`。
   回复 `OK`；语法错 `ERR`；忙时 `BUSY` 且状态零改动。
   旧的"末端地面坐标 + 逆解"版本已备份：分支 `backup/xyz-cartesian`（= tag `v1.6.3`）。

2. **恢复内置图形 字母N / 三角形 / 字母Z，并回报当前模式**
   任务表：`LINE 0 / N 1 / TRIANGLE 2 / Z 3 / V 4 / POLYLINE 5 / CURVE 6`；
   串口 `F` 换任务时回一行 `OK F=<tag>`（`LINE / N / TRI / Z / V / POLY / CURVE`），
   例：`OK F=TRI`；`WEARM_DEBUG_SERIAL=1` 时另打印中文名。

3. **删掉与题目无关的代码**（同时给 Uno 腾 flash）
   `moveAxisStep()`、`joystickGetMode()` / `JOY_MODE_VERT` / `JOY_MODE_COUNT`、
   `atRangeEdge()`（都是无调用点的死代码）、`posToolOpen()` / `posToolClose()`、
   串口 `1/2/3`（档位直达，题目只要求 `H/L`）、串口 `k/K`（末端步进，题目只要求 `O/S`）、
   `protoAxisServoIndex[]`、`PROTO_RES_COORDS_REJECTED`、`WEARM_SHOULDER_HEIGHT`。
   结果码 `5` 留空，`6` 改为 `PROTO_RES_FEATURE`（`!` / `!P` / `!B` / `!D` 的返回值），
   12~26 不重编号，以免牵动探针与文档。

## 目录内容

```
*.h / *.cpp / meArm.ino     多文件版固件源码（Arduino IDE 直接打开本目录即可编译）
weArm_config.h              编译期功能开关与容量表
single/meArm/meArm.ino      由 make_single.ps1 自动生成的单文件合并版（内容等价）
.selfcheck/                 PC 端自检：严格编译 + 11 个回归探针 + AVR 实编容量脚本
docs/                       文档（docx / pdf）：
                              kinematics_derivation.*      运动学推导（任务四）
                                                           已同步本轮改动：删掉"肩高换算/两套坐标系"，
                                                           串口 x/y/z 明确写成"直接写关节角、不逆解"
                              meArm_program_guide.*        程序说明：评审向，7 页，只讲单文件版（当前交付）
                              meArm_review_guide.*         ⚠ 旧版详细手册（34 页），写在"串口 x/y/z = 末端坐标"
                                                           方案时期，与现在的角度语义不符，仅留档
PACKAGE_README.md           本文件
```

## 怎么验证（不需要插板子）

```powershell
# 1) 严格编译（-Wall -Wextra -Wshadow -Wconversion，零警告才算过）+ 11 个回归探针
powershell -NoProfile -ExecutionPolicy Bypass -File .\.selfcheck\run_all.ps1

# 2) 用本机 AVR 工具链按 Arduino IDE 的方式实编，看 flash / SRAM 占用
powershell -NoProfile -ExecutionPolicy Bypass -File .\.selfcheck\avr_build.ps1
```

最后一次跑的结论：**9 个固件编译单元零警告 + 11 个探针 ALL PASS**。

## 实编容量（avr-gcc 7.3.0 + Arduino AVR core 1.8.8，Uno 可用 flash 32256 B）

| 配置 | Program | Data |
| --- | --- | --- |
| 取放 + 按键 + 绘图（出厂默认） | 31912 B (97.4%) | 1457 B (71.1%) |
| 取放 + 绘图，按键关 | 28720 B (87.6%) | 540 B (26.4%) |
| 取放 + 按键，绘图关 | 19082 B (58.2%) | 1206 B (58.9%) |
| 绘图 + 按键，取放关 | 29148 B (89.0%) | 1423 B (69.5%) |

默认配置离 Uno 可用 flash 只剩 **344 B**，再加功能前先用 `weArm_config.h`
里的开关裁掉一块，或再做一轮瘦身。

## 注意

- 所有结论都是 PC 端自检（严格编译 + 探针 + AVR 实编）的结果，
  **没有在真实 Uno 上烧录验证过**。上机第一步建议：串口助手 115200-8N1，
  发 `!` 应回 `P=1 B=1 D=1`，发 `O`/`S` 回 `OK #`，发 `x10,y30,z20` 回 `OK`。
- `.selfcheck/avrbuild/` 是 AVR 中间产物目录，体积大、可随时重编，不随包提供。
