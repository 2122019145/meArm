# .selfcheck —— PC 端编译自检与回归探针

这个目录**不参与烧录**，只是让你在电脑上（不需要 Arduino 板子）验证固件的
语法、类型、运动学模型与手柄逻辑。烧录时忽略整个目录即可。

> 当前固件是**角度模式**：摇杆直接改变 4 个舵机角 `Pos.ser.angle1..angle4`，
> 且串口 `x/y/z` 也直接写这三个舵机角（不做逆解）；
> `Pos.rec.x/y/z` 是由正运动学 `recFromServo()` 算出的派生显示量。
> 旧的"末端坐标控制"版本备份在仓库内：分支 `backup/xyz-cartesian`（= tag `v1.6.3`）
> 与 `dist\meArm_xyz_cartesian_v1.6.3_source.zip`。

## 为什么需要它

`arduino-cli` 没有装，无法做真正的 AVR 编译；而历史上真正致命的错误
（`#endif}` 少一个花括号、`-Wenum-compare` 枚举混用、`-Wunused-but-set-variable`）
**全部是编译器抓到的，人工审查两次都没看出来**。所以改动固件后请务必跑一遍这里。

更要紧的是：这套自检抓到过**探针自己写错、反过来冤枉固件**的多次假失败
（详见下面"写新探针时的教训"），也抓到过真正的固件 bug。

## 工具链

- 编译器：`C:\ProgramData\mingw64\mingw64\bin\g++.exe`（16.1.0）
- mock 头文件在本目录 `mock\`：`Arduino.h`、`Servo.h`，仅用于 PC 端替代真机 API。
- 串口日志默认被丢弃；想看到固件里的 `Serial.println` 输出，先设环境变量
  `$env:WEARM_MOCK_SERIAL='1'`。

## 一键跑全部

```powershell
D:\dsh1\meArm\.selfcheck\run_all.cmd
```

（`.cmd` 只是个壳，用 `-ExecutionPolicy Bypass` 调 `run_all.ps1`——
Windows 默认禁止直接运行 `.ps1`。）

它做两件事，任一失败就 `exit 1`：

1. **严格编译 9 个固件 TU**（`-Wall -Wextra -Wshadow -Wconversion`），要求
   **零警告**；
2. **编译并运行 11 个自检程序**，逐个要求输出里有 `ALL PASS` 且退出码 0。

每个探针的完整输出会存到 `.selfcheck\out\<探针>.log`。

通过时输出：

```
================ 1) 固件严格编译（0 警告才算过）================
  [ OK ] constant_and_positions.cpp  EXIT=0  输出 0 行（零警告）
  [ OK ] servo_drive.cpp  EXIT=0  输出 0 行（零警告）
  [ OK ] move.cpp  EXIT=0  输出 0 行（零警告）
  [ OK ] joystick_control.cpp  EXIT=0  输出 0 行（零警告）
  [ OK ] protocol_constants.cpp  EXIT=0  输出 0 行（零警告）
  [ OK ] serial_protocol.cpp  EXIT=0  输出 0 行（零警告）
  [ OK ] pick_place.cpp  EXIT=0  输出 0 行（零警告）
  [ OK ] button_control.cpp  EXIT=0  输出 0 行（零警告）
  [ OK ] draw_control.cpp  EXIT=0  输出 0 行（零警告）

================ 2) 自检程序（必须 ALL PASS）================
  [ OK ] probe_axes  零警告编译 + ALL PASS
  [ OK ] probe_rt  零警告编译 + ALL PASS
  [ OK ] probe_move  零警告编译 + ALL PASS
  [ OK ] probe_joystick  零警告编译 + ALL PASS
  [ OK ] wearm_ino_test  零警告编译 + ALL PASS
  [ OK ] probe_protocol  零警告编译 + ALL PASS
  [ OK ] probe_pick_place  零警告编译 + ALL PASS
  [ OK ] probe_button  零警告编译 + ALL PASS
  [ OK ] probe_draw  零警告编译 + ALL PASS
  [ OK ] probe_servo_drive  零警告编译 + ALL PASS
  [ OK ] probe_pins_off  零警告编译 + ALL PASS

>>> 全部通过（固件零警告 + 11 个自检 ALL PASS）
```

## 每个探针在测什么

| 探针 | 覆盖内容 |
|---|---|
| `probe_rt` | 5 个标定点核对、反解→正解残差 0.05 阈值、关节角往复（1950 组：反解 false 0 / 被吸附 0 / 镜像分支 22 / 非镜像回转角最大误差 0.000°）、全网格残差（6270 组全部成功、最大残差 0.000000） |
| `probe_move` | 六向定长步进（`moveup` = 下臂 c +1°、`moveright` = 基座 b +1°、`moveforward` = 上臂 r +1°，其余关节一字节不动）、推到头返回 `MOVE_AT_LIMIT` 且零位移、非法方向 `MOVE_NONE`、`stepSize=0` 跟随全局调速、坐标与角度严格自洽且不出 `limit`、超臂展 `isReachable()==false`、三档调速参数、4000 步随机压力（零越界/零 NaN/零关节越限）；**[7] `moveToPoint()`（绘图与串口共用的"移动到指定 x,y,z"）**：不可达点整条拒绝且 `Pos` `memcmp` 逐字节不变、`TRACK` 超速整点拒绝/限内接受且写进去的角度与独立反解结果**逐位相同**、`JOG` 每步不超过 `maxDps×dtSec` 并反复调用收敛到反解结果、`NOW` 不限速一次到位（实测一次跳变 4.57°）且坐标自洽、部分 `seen` 只动被提及的轴、`NULL`/未知模式都返回 `REJECTED` 且不动 |
| `probe_joystick` | 四路轴各控一个关节角且互不干扰、坐标 = `recFromServo(Pos.ser)`、末端 A2 方向与限位、斜推可同时动多个关节、死区不动作、快速转角 > 慢速、四路推到头都停在 `servoLimit` 内、4000 轮随机推杆 |
| `probe_axes` | 5929741 个关节角组合扫出真实可达包络、验证 `limit` 完全覆盖包络且余量非负、单轴满行程自查（每个关节都能走到行程两端）、5 个标定点核对 |
| `wearm_ino_test` | **直接 `#include "../meArm.ino"`**（不手抄复刻；探针文件名保持不变，被 include 的主 sketch 已随工作区改名为 `meArm.ino`）：4 个舵机 attach 引脚、上电姿态 = POS_HOME、上电不是 0（不会甩向原点）、静置 20 轮 loop 不动、推杆后 loop 真的把新角度写进舵机 |
| `probe_protocol` | 串口协议完整测试：O/S/H/L 命令（爪子开/关/升档/降档）、角度指令格式（`x10,y30,z20` 及大小写/空格/小数点/`=` 变体、超行程按 `servoLimit` 夹取）、行缓冲与超时处理（PROTO_LINE_BUF_SIZE=40, PROTO_LINE_TIMEOUT_MS=300）、忙守卫（忙时动作指令一律回 BUSY 且状态零改动）、运行时功能开关 `!`/`!P`/`!B`/`!D`（回 `PROTO_RES_FEATURE`）、7 个绘图任务 `F` 循环并逐一核对 `OK F=<tag>`、MockSerial 64 字节缓冲边界、无换行超时、3000 轮随机角度压力（INV1~INV8） |
| `probe_pick_place` | A/B/C 自动取放：位置表（Δx、Δy 各 ≥5，三初始点/三放置点两两相距 ≥5，放置点离"别人的初始点" ≥5，实测最紧 7.21）、6 个取放点与接近点都"在 limit 内 + 可达 + 反解未被吸附"、启动语义（0 / -2 忙 / -1 编号非法）、完整跑三轮（A 305 轮、B 334 轮、C 335 轮，逐轮零违规、末点 = 放置点 + 抬升 6.0、`angle4 == servoLimit.maxF`）、忙时让位（O/S/x45/A 全返 BUSY 且状态零改动，H/L 仍生效）、空闲时反复调用不动状态 |
| `probe_button` | 四按键接口 11 段（编号跳过 [10]）：`pinMode` 记录断言 D2~D5 都是 `INPUT_PULLUP`、初始无录制/不忙/不让位；按键1 物理连按四次 A→B→C→A 且序列执行中再按不推进序号；录制门槛（未录制时播放回 16、录制中 `busy=true` 但 `locked=false`、录制中 O 被挡回 11 而 H/L 仍回 3/4、只录 3 秒但**没动**回 14、**8.2 秒短录像有位移 → 回 13、40 条、位移 20.54（时长门槛已删除的回归）**、录 11.5 秒无位移回 14）；真实摇杆录制 11.6 秒 → 保存回 13、57 条、位移 24.95；播放回 15、只在"仍被独占"时推摇杆验证让位、回放末态与录制末态误差 0.00、耗时 13.02 s = 录制 11.6 s + 预摆 1.5 s；**播放中按按键4 / 发别名 `0` 都被拒（回 11）且播放不被劫持**；回中回 17 且 b/r/c 与 `posGetHomeAngles()` 位级一致、angle4 不动、别名 `0` 同样有效；串口路径 N/R/P/M 与忙守卫豁免（序列忙时 N 回 11、录制中 R 回 14）；空闲 100 次调用零改动；**[9] 最坏情况**：四路摇杆每 700 ms 翻向、连续推 11.2 秒 → 仍保存成功（55/192 条、位移 32.32；旧"每周期另写 WAIT/增量"的格式要 ~560 条，必然溢出判废），回放后四轴末态差 0.00 度；**[11] 录制中直接按 P**：只录 2 秒没位移 → 回 14 且不播放；合格录制（11.5 s）按 P → 回 15、先收尾保存再立刻播放、回放末态 == 按 P 那一刻的位姿（四轴差 0.00）；**[12] 缓冲写满**：连续推杆录到 38.2 s 仍在录制且条目 190/192（stride 200 ms、uint16 计数不回绕），38.8 s 写满自动收尾并**判废不留半段数据**，事后按 P 回 16 |

| `probe_draw` | 绘图模块 8 段：[1] 初始化与纸面标定（默认任务=直线、纸面 z=12/半宽 6/中心 (20,0)、**7 个任务名齐全且 `DRAW_TASK_COUNT==7`**、非法任务回 -1、循环顺序 直线→字母N→三角形→字母Z→字母V→折线→曲线→直线、标定越界都被拒且不改动、空闲时暂停/继续/取消都回 11）；[2] 直线全流程（阶段顺序 回待机→抬笔移动→落笔→绘制中→抬笔→结束回待机→空闲；抬笔段 z 最低 16.00 > 纸面；落笔垂直 x/y 漂移 0.000、z 落到 12.00；绘制中 z 恒 12.0000、y 恒 0、x 14.00→26.00、相邻步最大 0.015、**离理想直线最远 0.0000**；抬笔段 z 最高 16.00、x/y 漂移 0.000；用时 4485 ms；结束后 b/r/c 都是 90.00）；[3] 四个内置图形逐个校验（N / 三角形 / Z / V 各跑一遍：**顶点最差 ≤0.30、离线最远 ≤0.05**，并逐个断言 `drawTaskTag()` 非空非 "?"）；[4] 暂停/继续（API 语义 + 暂停 800 ms 后四个关节角逐位不变 + 阶段仍是绘制中 + 继续后 x 不倒退、终点 26.00）；[5] 取消（立刻进抬笔阶段；**抬笔垂直 x/y 漂移 0.000、z 12.00→16.00、全程不再低于纸面**；回待机位 b/r/c=90.00 并空闲；能重新开任务）；[6] 五点示教折线（细步长 `setSpeed(0.5,20,60)` 下闭环点动记录 5 点、记满自动进入"准备绘制"、按按键1 暂停/按键2 继续、**5 个示教点最近距离最大 0.005、采样点离线 0.000、过点 5/5**、高度恒定 = 示教高度 12.250、相邻步最大 0.015；**示教点动逐轴回归：A0/A1/A3 单轴满偏只让对应坐标变化（串扰 <0.02）、每格 ≤0.26 单位、轻推步长小于满偏一半、A2 整路不响应**）；[7] 五点示教曲线（弧形 5 点、过点 5/5、**离线最远 0.689 证明是曲线不是折线**、相邻采样最大间距 0.015、每 5 ms 最大转角 0.38°、用时 9155 ms）；[8] 串口（`drawIsCommandChar` 全集、F 换任务回 18、p/n/o 标定与越界/非数字拒绝、D 启动回 19、**绘制中 x10 被忙守卫拒绝回 11、Q/U/W 豁免**、示教 G/E/W 与点数清零、取放忙时 `drawStartTask()` 回 11） |
| `probe_pins_off` | **用与出厂固件一致的 `-DWEARM_BUTTON_PINS=0` 编译**（其余探针用 1），专门守"物理按键完全不读、功能全走串口"这条路径：[0] 断言 `WEARM_BUTTON_PINS==0`（防止编译参数漂移后本探针变成什么都没测）；[1] `buttonSetup()` 之后 D2~D5 仍是 `INPUT`（证明连 `pinMode` 都没做）、启动日志含"不读 D2~D5"、初始空闲；[2] 把 D2~D5 全部按低电平 1 秒（模拟摇杆 SW 被机械压合）→ 不启动取放 / 不录制 / 循环序号仍 A / 串口零回复，松开 200 ms 也不会"补一次"；[3] 右摇杆 A3 推到 1023 → 下臂照常转（实测 90.00→67.00）、不触发取放、无串口回复；[4] 四个功能改由串口触发：`N` → 开始夹 A 且回 `OK`、跑完 305 轮回空闲，`R` → 录制 + `OK`、再 `R` → 太短回 `DISCARD` 且不留数据，`P`（无录制）→ `EMPTY`，`M` → 回中 + `OK`、回中后 b/r/c 与 `posGetHomeAngles()` 差 <0.01，`0`（按键4 别名）→ 同样回中 |

### 当前实测包络（r、c 都放开到 0~180 之后）

```
x[-40.00, 40.00]  y[-40.00, 40.00]  z[-20.00, 40.00]
limit    : x[-40.0,40.0] y[-40.0,40.0] z[-20.0,40.0]
余量     : x[0.00,0.00] y[0.00,0.00] z[0.00,0.00]   （非负 = limit 完整覆盖包络）
```

四个极端姿态：`x=+40` 在 (b,r,c)=(90,0,0)，`x=-40` 在 (90,180,0)，
`z=+40` 在 (90,90,0)，`z=-20` 在 (90,0,90)。

逐高度（每 2° 一层，y 恒为 `[-X, X]` 对称）：`z=0.0 → x[-40.00,40.00]`（最远）、
`z=-20.0 → x[0,26.18]`、`z=20.0 → x[-35.15,35.15]`、`z=40.0 → x[-8.66,8.66]`。

两点容易看错，先说明：

- 每一层是 `|z - 层高| <= 1` 的**一层**，不是"z 恰好等于层高"的精确平面。
  所以 `z=40.0` 那层不是 0 而是 ±8.66 —— 它含了 `z=39.05` 的姿态
  （`r=103,c=1` 给 -8.66；`r=78,c=1` 给 +8.66）。真正的 z=40 只有
  `(r,c)=(90,0)` 一个姿态，此时 x=y=0。
- 负 x 来自 **ρ<0 的"朝后伸直/反折"姿态**（`20cos(r)+20cos(r-c)` 变负），
  例如 `r=180,c=0` 时 ρ=-40，b=90° 就落在 x=-40。不是算错。

## 写新探针时的教训（都踩过，代价很大）

1. **直接 `#include "constant_and_positions.h"` 调用固件函数，不要重写公式。**
   探针里重写运动学必然引入符号错：曾经把基座角写成 `theta=(b-90)`（应为
   `(90-b)`），整张可达表镜像，于是把"可达"误判成"不可达"，浪费好几轮。
   `wearm_ino_test` 同理：**直接 include 真 `.ino`**。手抄复刻版曾把引脚写成
   9/10/11/6（真 sketch 是 9/7/8/6）却照样编译通过、零警告——
   接线漂移只有"直接编译真文件 + 核对行为"才抓得到。
2. **必须调 `servoSelfCheck()` 再反解**，否则 `jointMin/jointMax` 映射表仍是全 0，
   会把所有角度夹成 0（表现为打印全 0.00、可达率虚高）。
3. **不要把 `getAngle(&t)` 和读取 `t.ser.*` 写在同一个 `printf` 参数里** ——
   参数求值顺序未指定，会打印出"陈旧但看起来合理"的角度。先 `bool ok = getAngle(&t);`
   再打印。
4. **循环边界别硬编码关节行程**（`c <= 105` 这类）。行程一改（c 已从 105 放到 180），
   探针就悄悄只测一半网格。改成从 `servoLimit.minC/maxC` 取。
5. **探针自己报的失败要先怀疑探针。** 踩过的假失败：
   - "慢速测试的终点接着测快速，剩余行程不足导致快速位移反而更小" ——
     两次测量前都要 `resetInputs(); posInit();` 回到同一起点；
   - 把**不在 `limit` 体积内**的点（如 x<0）当反解失败 —— 那些点本来就会被
     `clampToRange` 挡住，应先用 `limit.minX/maxX/...` 过滤；
   - 用 `==` 比较浮点角度：`posInit()` 走"设坐标→反解→落角度"往返，
     角度带 ~1e-13 舍入误差，`89.99999999999999 != 90.0` 会报假失败
     （而 `%.1f` 打印出来完全正常）→ 用容差比较。

6. **串口必须单一读者**。旧函数 `handleSerialSpeedCmd()` 自己调用 `Serial.read()`，新的行缓冲也要读同一串数据，两个读者会把字节各吃一半、行永远拼不完整。因此旧函数已**整体删除**（连同 `constant_and_positions.h` 里的声明），串口字节只由 `serialProtocolLoop()` 读，调用点只在 `meArm.ino` 的 `loop()` 里（放在 `joystickLoop()` 之前）。`joystickSetup()` 也不再调用 `Serial.begin()`。
7. **mock 的串口输入缓冲只有 64 字节且只追加不压缩**：`.selfcheck\mock\Arduino.cpp` 里是 `static char inBuf[64]`，`mockSerialFeed()` 只 append，读空后 `inPos` 等于 `inLen` 但 `inLen` 不回退。所以连续喂超过 64 字节的测试，后面的字符根本进不去 —— 测的是 mock 缓冲被塞满，而不是固件行为。正确做法是穿插 `mockSerialClear()`（或分段重建缓冲）。反例：`probe_protocol` 原超长行用例注释写"60 个 A"，字面量实际是 70 个，行尾换行符根本没能进缓冲。
8. **无换行超时用例必须调用两次 `serialProtocolLoop()`**：固件在读到字符时把 `s_lastCharMs` 记成 `millis()`，若先喂数据、再一次性推进 400 毫秒、再调 loop，则超时判断里的时间差恒为 0。正确写法是先 `mockSerialFeed` 再调一次 loop，再 `g_mockMillis` 加 400，再调第二次 loop。
9. **mock 的 `MockSerial` 没有 `print` 的单字符重载**：写 `Serial.print(某个 char 变量)` 会被隐式提升到打印 int，串口里打出的是码值（例如字母 x 打成 120）。要打印单个字符必须用长度 2 的 C 串（`char ch[2] = { c, 0 }; Serial.print(ch);`），真机与 mock 都能出字母。
10. **`PROTO_ANGLE_MIN` 与 `PROTO_ANGLE_MAX` 已被删除**：本工程不为解析阶段定义名义角度区间。解析时不该因为角度超出某个区间就拒绝指令（那样 x200 就变成废指令），而是落地前按该关节真实的 `servoLimit` 夹取（x200 最终写 180）。探针要造随机角度请用自己的局部常量。
11. **探针直接赋值 `Pos.ser` 会造出固件永远不会产生的脏状态**：探针的 `resetInputs()` 直接写 `Pos.ser.angle1` 到 `angle4`，不走固件写入路径，因此 `Pos.rec` 不刷新；而固件唯一写角度的地方 `protoApplyAngles()` 在 `written` 大于 0 时会调一次 `recFromServo(&Pos.rec, &Pos.ser)`，即固件任何一次成功写入都保证 `Pos.rec` 自洽。曾因此在压力测试里出现 violations 等于 4 的假警报（全是"Pos.rec 必须等于 recFromServo(Pos.ser)"这一条不变量）。正确做法：压力测试开始前自己补一句 `(void) recFromServo(&Pos.rec, &Pos.ser);`。
12. **PowerShell 的逗号优先级高于加号**：把两个 `-I` 参数用 `@("-I" + $root, "-I" + $mock)` 这样写会拼成**一个**字符串，表现为编译报 `fatal error: Arduino.h: No such file or directory`。必须给每个拼接加括号。
13. **给子智能体的长文本（例如 workflow 脚本里的 prompt）不能出现反引号**：脚本里用模板字符串包住 prompt 时，正文里的 markdown 反引号会直接终结模板字符串，报 `workflow script does not parse` 与 `SyntaxError: Unexpected identifier`。
14. **探针不许引用只存在于某个 `.cpp` 里的私有宏**。`pick_place.cpp` 的 `PICK_GRASP_Z` / `PICK_APPROACH_DZ` 是文件内 `#define`，探针 include 了头文件也看不到它们（表现为 `'PICK_APPROACH_DZ' was not declared`）。修法不是把宏抄一遍（那会制造第二处真值），而是在头文件里加一个访问器：`double pickPlaceApproachDz(void);`。
15. **`REC` / `SER` / `pos` 是 `typedef`，不能写 `struct REC r;`**（C 语言习惯，C++ 里报 `expected primary-expression`）。写 `REC r;` 即可。
16. **子智能体说"编译通过/测试通过"一律要自己再验一遍**。本轮一个子智能体在**从未编译成功**的情况下写出"预期输出应该是所有测试通过"，还往 `.selfcheck\` 扔了 11 个一次性垃圾文件（`hello.c`、`probe_minimal.py`、`probe_report.txt` 之类）。验收口径：自己跑 `run_all.cmd`，看它在**你改完的磁盘文件**上是否真的全绿；子智能体贴的原始输出只当线索，不当证据。
17. **测"某期间摇杆被让位"时，别把"期间结束的那一瞬间"算进去**。`probe_button` 的收尾循环写的是 `buttonLoop()` 之后紧接着 `joystickLoop()`：播放恰好在 `buttonLoop()` 里收尾，于是同轮的 `joystickLoop()` 立刻用还按着的摇杆走了 1.0°（`angle2 86.1124 -> 85.1124`），报成"让位失效"。固件是对的 —— 播放一结束摇杆就该立刻恢复。正确写法：循环条件用 `buttonControlLocked()`，并且**只在仍然锁着时才调 `joystickLoop()`**，然后单独收尾跑完剩余流程。
18. **探针里对"循环序号"这类有状态的量，不要写死第几次的期望值**。`probe_button` 断言"mock 喂 `N\n` 应该夹 A"，但循环序号在前面用例里已经推进到 C，于是假失败。正确写法：调用**前**先取 `int nextBefore = buttonPickNext();`，再断言 `pickPlaceCurrentObject() == nextBefore`。
19. **用 `edit` 工具改 `.ps1` 会丢 UTF-8 BOM**（第 274 行那条坑的另一面：`write`/`edit` 都按无 BOM 写）。改完必须补：读成字节、前置 `EF BB BF`、`[System.IO.File]::WriteAllBytes()` 写回，再确认 `CRLF` 数正常、`loneLF` 为 0。`run_all.ps1` 因为要被 `powershell -File` 解析，BOM 丢了会直接语法报错。
20. **`run_all.ps1` 的汇总行用 `$probes.Count` 自动计数**，加探针不用手改文案；但 `README.md` 里的"6 个固件 TU / 7 个自检"是手写的，每加一个 TU 或探针都要同步改示例输出，否则文档与实测输出对不上。
21. **"缓冲能撑多久"必须按最坏情况的每周期条目数推一遍**。`button_control.cpp` 头部原写"条目速率上限约 25 条/秒、512 条 ≈ 20 秒"，把采样周期误当成了条目速率；实际每个有动作的周期最多写 `1 + 动的关节数` 条 → 四关节同时动 = 125 条/秒，512 条只够 4.1 秒 → 必然写满、必然低于 10 秒门槛、录完就判废。修法是换格式：把"推进一个周期"塞进增量条目的 bit7（`BTN_TICK_FLAG`），每周期只花"动了几个关节"条，并把 tick 从 40 ms 放宽到 100 ms；容量结论按 `512 / (1 + 关节数) × tick` 重算后才写进注释。**后续补充**：这一版格式与"最小时长"门槛后来都被又一轮重构换掉了 —— 现在是每个 200 ms 周期（`WEARM_REC_TICK_MS`）固定写一条 **4 字节**记录（四个关节各 8 位有符号增量），`WEARM_REC_ENTRIES` = **192 条 = 38.4 s = 768 B SRAM**，而"时长必须 >10 s"这条门槛**已被删除**（只剩位移门槛）。教训本身（容量必须按最坏情况推算、结论写进注释前先复测）仍然成立，而且**字段位宽也必须按最坏情况推算** —— 见教训 22。
22. **"周期性采样 → 回放"必须显式处理首尾零头**。采样是离散的，`btnRecTick()` 只在周期边界结算增量，于是"最后一个整周期 → 松手"之间的动作永远进不了缓冲。四关节在快速档每周期能走 10 度，回放终点就整整差 10.00 度（不是量化误差，是丢了一段）。修法：`btnStopRecording()` 一开头调 `btnRecFlushTail(now)` 把这一小段补成条目，只有跨进新周期时才给第一条挂 `BTN_TICK_FLAG`。修完 `probe_button` 的末态差从 `10.00/10.00/10.00/9.50` 变成 `0.00/0.00/0.00/0.00`。**后续补充（采样周期放宽到 200 ms 之后）**：这条教训又咬了一次，而且这次是**两个原因叠在一起**——(a) 记录字段只有 6 位（±16 度/条），200 ms 一周期时正常档就能走 20 度，超出的部分全靠 `s_snap[]` 顺延，于是每个周期都在积压；(b) 收尾只补**一条**记录，积压的尾巴被截掉，于是四轴同时全速时回放终点短 10~13.5 度。修法是同时把字段放宽到 **8 位（±63.5 度/条 = ±317 度/秒 @200 ms）**、并把收尾改成**排空循环**（最多 8 次，直到没有新增量）。**结论：字段位宽也是"最坏情况"的一部分，"补一条"永远不等于"排空"。**
23. **"每轮最多走多少度"的限速，不能拿循环周期当时间基准去卡事件驱动的动作**。`draw_control.cpp` 的 `tryApplyPoint()` 原来用 `DRAW_MAX_DPS * s_dtSec`（`s_dtSec` 是 `drawLoop()` 的循环周期，PC 探针里 5 ms → 上限 0.55°）做每轮上限。这对"每轮都写一个轨迹点"的路径跟随是对的，但**示教点动是事件驱动的**（每 `fullDelayMs~minDelayMs` 才动一次，10~40 ms，一步 1.4~2.9°），于是每一次点动都超限被整条拒绝 —— 上机表现就是"摇杆推了笔尖不动"，而路径跟随一切正常。修法有两条：(a) 让时间基准变成**距上次真正写入点位的时长** `applyDtSec()`（夹在 `[0.005, 0.1]` 秒，顺手防住长时间暂停后的巨大跳变），(b) 点动这种手动模式用**夹取**而不是拒绝（新增 `applyPointClamped()` 与 `DRAW_JOG_MAX_DPS 200`），因为手动点动只要求"大致往那边走"，被拒一次就等于卡死。
24. **"开始/结束一段动作"的辅助函数只装参数、不改阶段，别指望它顺手把状态也改了**。`drawCancel()` 的"绘制中取消"分支写了 `beginLift(lz); s_nextAfterMove = RETURN;` 却漏了 `s_phase = DRAW_PHASE_LIFT;`，于是取消后阶段还停在 TRAVEL/PLUNGE/PATH，状态机接着按原轨迹继续画 —— **取消等于没取消**（探针里表现为"取消后立刻进入抬笔阶段 FAIL"）。同文件"画完自动抬笔"那处三行齐全，就是靠对照才发现漏了一行。写这类状态机时，"设置下一阶段"和"装移动参数"必须是两个显式动作。
25. **"阶段没进顺序表"与"阶段顺序错"要分得清**。`probe_draw` 的 `runToIdleTrace()` 原来在 `drawGetPhase() == IDLE` 时**直接 return、不采样**，于是"回到空闲"这一步永远不出现在阶段顺序里，检查 `seqBefore(结束回待机, 空闲)` 假失败。同理，若在示教前不清空顺序表，`seqBefore(准备绘制, 回待机)` 会撞上"示教前那次回待机"，也假失败。修法：返回前补记一次采样；并且在"只关心某一段"的检查前 `seqReset()/traceReset()`。
26. **C++ 函数实参的求值顺序是未指定的**，别把"先调它、再读它"写成 Check 的两个实参。`check("选中五点折线", drawSelectTask(DRAW_TASK_POLYLINE) == DRAW_TASK_POLYLINE, drawTaskName(drawGetTask()))` 里的 `drawTaskName(...)` 可能先于 `drawSelectTask(...)` 求值，于是详情里印的还是**上一个**任务名（看起来像"选错了任务"）。修法：先 `(void) drawSelectTask(...)`，下一行再读状态。

## 编译器的坑（本机实测）

1. **`C:\msys64\ucrt64\bin\g++.exe` 在本沙箱下静默失败**：退出码 1、stderr 一个字都没有、连 `-v` 都不打印，`.exe`/`.o` 永不产出（看起来像"什么都没发生"）。**一切编译/链接都用 `C:\ProgramData\mingw64\mingw64\bin\g++.exe`** —— 它也是 `run_all.ps1` 里 `$gpp` 用的那一个。
2. **`cmd /c "... & echo ERRORLEVEL=%errorlevel%"` 的 `%errorlevel%` 是解析期展开的**，打印出来是命令**执行前**的值，会给出"编译成功"的错觉。PowerShell 里一律用 `$LASTEXITCODE`。

## 固件里的坑（自检抓到过的真 bug）

写固件时这几条都是"看起来对、实际错"的，已修：

1. **`clampToRange()` 会原地改 `Pos.rec` 并返回"是否夹到过"**，不能当只读判断用。
   旧 `moveJointStep()` 为了"给坐标一个临时落点"先挪坐标再判断越界，
   结果越界时该函数把坐标夹回边界值、返回值恰好让整步回退被跳过，
   末端坐标能停在界外（压力测试报 `violations=5722`）。修法是新增只读的
   `posOutOfRange()`，整步回退。
2. **`isReachable()` 判断 `R > L1+L2` 必须带浮点容差**。两杆完全伸直时 R 数学上
   恰为 40，浮点算出来是 40.000000000000004，严格比较会把"全伸直"整类姿态
   判成不可达（实测 19 组反解失败）。现在用 `GEOM_EPS = 1e-9`。
3. **`90 - RADtoDEG*atan2()` 的浮点误差会把"正好 0°"算成 -2.4e-10**，
   归一化 `while (b < 0) b += 360` 于是把它变成 359.9999999998，
   再和 `maxB = 180` 一比就丢掉这个分支：目标 `(0,20,20)` 的正确回转角恰好是 0°
   就踩在这里（表现为反解 false、`Pos.ser` 停在 `(0,0,0)`）。
   修法：归一化后把 `> 360-1e-6` 的值折回 0°。
4. **反解要试 4 个候选**：`{rhoP = ±rho} × {delta = ±|c|}`。
   只试一个分支会漏解（镜像姿态里常常只有一个满足机械行程）；
   而 `rhoP = -rho` 的反向平面分支是 `x<0` 类目标的唯一出路
   （正向平面会算出 190°~270° 的回转角，超出 `b` 的行程 `[0,180]`）。
5. **舵机角 `c = alpha - beta`，不是 `beta`、也不是 `|c|`**。模型是
   `beta = alpha - c`，所以反解必须先求出 `alpha` 与 `beta` 才能得到 `c`。
   曾把 `beta` 或 `|c|` 直接当舵机角，导致 `(28.28,0,0)` 这类点"解"残差很大。
6. **单个标定点无法区分模型**：`beta = r-c`、`r+c-180`、`180-r-c` 在 c=90 时
   全部退化成同一个点 (20,20)，只有代 c=105 才分道（正确模型给 (19.32,14.82)，
   `r+c-180` 给 (19.32,25.18)）。**凡是"唯一命中"的结论，先找第二个参数不同的标定点。**
7. **`getAngleEx()` 返回 false 时不能改 `Pos.ser`**。`applyJointLimits()` 在 CLAMP
   策略下就地吸附，写完才发现要拒绝时角度已被改掉一半——
   老代码踩过：一个反解失败的 `posInit()` 把 `Pos.ser` 留成 `(0,0,0)`，
   **上电时机械臂直接甩向原点**。现在先存 `oldA1..oldA4`，失败全部回滚。
8. **夹限位判断的容差不能用 `ANGLE_EPS = 1e-6`**：反解落在行程端点上的解常有
   -1e-14 量级舍入误差，于是几乎每个"正好在端点"的姿态都被判越界，
   `clamped` 标志天天误报。改用 `LIM_EPS = 1e-9`（远小于舵机可分辨的 0.1° 步进）。
9. **固件只能有一处运动学实现**。`posInit()` 的开机自检曾自己重写正解并写成
   `(angle2 + angle3)`（应为 `r - c`），公式错了照样打印一串"看起来很合理"的数字。
   现在整段改成调用固件自己的 `recFromServo()`。

10. **反解的"镜像分支"不是 bug，但必须用正解回代验证。** 同一个末端点可以有两组
    关节角到达：基座转 180°、两节臂在相反的竖直平面里镜像，两组都合法，反解器
    只能给出其中一个。r 放开到 0~180 之后镜像解也落进了行程，反解器可能先选到
    它，于是只比回转角就会误报 180° 的"误差"（实测 22 组）。修法**不是**放宽阈值
    或跳过这些点，而是**加强**判定：镜像分支（回转角与原来相差 180° 左右）必须用
    固件 fk() 正解回代、残差 < 0.05 才算通过，否则计入 branchBad 判 FAIL。
    （实测 1950 组里 22 组是合法镜像解，无法解释的 0 组。）

## mock 的引脚索引（容易搞错）

- `g_mockAnalog[]` 用**A0 起算的下标**：`MOCK_AX 0`(=A0)、`MOCK_AY 1`(=A1)、
  `MOCK_TX 2`(=A2)、`MOCK_TY 3`(=A3)。
- `g_mockDigital[]` 用**展开后的数字引脚号**：A0=14、A1=15、A2=16、A3=17。
- `mockSerialFeed("1")` 模拟串口收到字符，`mockSerialClear()` 清空输入。
- 推进时间：直接改 `g_mockMillis += ms;`（固件里没有 `delay`，全靠时间门控）。
- `mockServoPin(i)` / `mockServoAngle(i)` / `mockServoWriteCount()` 记录每个
  `Servo` 实例最后一次 attach 的引脚与写入的角度（`wearm_ino_test` 靠它核对接线）。

## 新增串口协议模块

本轮新增了完整的串口协议处理模块，包含：

- **协议常量**（`protocol_constants.h` 与 `.cpp`）：
  - 命令字符：`O`（爪子张开）、`S`（爪子关闭）、`H`/`L`（速度档升/降）、`x/y/z`（三个舵机的目标角度）
  - 角度轴字母：`protoAxisChar = {x,y,z}`，轴下标 `a` 直接写 `Pos.ser.angle(a+1)`，
    `protoAxisJoint = {'b','r','c'}` 只用于调试打印关节名（x=angle1 基座 b、y=angle2 上臂 r、z=angle3 下臂 c）
  - 协议参数：`PROTO_LINE_BUF_SIZE=40`、`PROTO_BAUD=115200`、`PROTO_LINE_TIMEOUT_MS=300`
  - 速度档位：`PROTO_SPEED_LEVEL_MIN`/`MAX`/`DEF`
  - 已删除（与题目命令集无关，同时给 Uno 腾 flash）：`1/2/3` 档位直达、`k/K` 末端步进开合
    （爪子的全开/全关由 `O`/`S` 覆盖，步进由摇杆 A2 覆盖）。结果码 `5` 因此留空，
    `!`/`!P`/`!B`/`!D` 改用 `PROTO_RES_FEATURE 6`（不重编号 12~26，避免动探针与文档）。

- **串口协议处理**（`serial_protocol.h` 与 `.cpp`）：
  - 字符读取、行缓冲、命令解析与落地写入
  - `!` 查询当前功能状态（P=取放、B=按键、D=绘图）；`!P` / `!B` / `!D` 切换运行时启用状态。只能切换编译进固件的模块，无法开启编译裁掉的代码。
  - 开启 `WEARM_SERIAL_RESPONSES` 后，每条识别命令都回一行短回复：
    `OK`（O/S 带夹爪角度 `OK #`、`x/y/z` 角度指令、`F` 换任务带模式 `OK F=<tag>`）、`BUSY`（懂了但现在忙）、`OFF`（模块被 `!P/!B/!D` 关掉）、
    `DISCARD`（R 结束录制时数据不合格已丢弃）、`EMPTY`（P 没有录制数据）、
    `ERR`（语法错）、`REJECTED`（固件没编进该模块 / 轨迹校验不过）。
    先确认串口助手设为 115200 baud，并且固件已烧录。
  - 对外接口：`serialProtocolBegin()`、`serialProtocolLoop()`、`protoHandleLine(const char*)`
  - 命令语义：`O`=爪子开、`S`=爪子关、`H/L`=速度档升降、
    `x20,y0,z40`=把 x/y/z 编号的三个舵机分别写 20/0/40 度（超出 `servoLimit` 行程按行程夹取，见下面"角度语义回归"一节）

- **探针更新**：
  - `probe_joystick` 中的旧串口用例已删除，移至 `probe_protocol` 专门测试
  - `probe_protocol` 探针现有 12 段，专门测试串口协议功能（含 3000 轮随机角度压力）

## 新增 A/B/C 自动取放模块

本轮新增 `pick_place.h` / `pick_place.cpp`：上位机发送单个字母 `A` 或 `B` 或 `C`，
机械臂自动把对应物体夹起来搬到另一个位置。

- **对外接口**（`pick_place.h`）：
  - `int pickPlaceStart(int object)`：启动某个物体的取放序列。返回 `0` 已启动、
    `-1` 编号非法、`-2` 已有序列在执行、`-3` 路径校验失败（**失败时不改任何全局状态**）。
  - `void pickPlaceLoop(void)`：非阻塞推进，每轮 `loop()` 调一次，不调用 `delay()`，
    不做等待式循环。
  - `bool pickPlaceIsBusy(void)` / `int pickPlaceCurrentObject(void)` / `const char *pickPlaceStageName(void)`
  - `bool pickPlaceGetSource(int, double*, double*, double*)` / `...GetTarget(...)`：
    读出物体初始位置与放置位置。
  - `double pickPlaceApproachDz(void)`：接近点相对物体的抬升高度（探针用它，避免抄死 6.0）。
  - 物体编号：`PICK_OBJECT_A/B/C` = 0/1/2，`PICK_OBJECT_COUNT` = 3。

- **位置表**（都写在 `pick_place.cpp` 顶部，改这里即可自定义）：

  | 物体 | 初始位置 | 放置位置 | x 位移 | y 位移 |
  |---|---|---|---|---|
  | A | (24, 12, 12) | (16, -14, 12) | -8 | -26 |
  | B | (24, -12, 12) | (18, 16, 12) | -6 | +28 |
  | C | (12, 20, 12) | (28, -6, 12) | +16 | -26 |

  三个初始点两两相距 24.00 / 14.42 / 34.18，三个放置点两两相距 30.07 / 14.42 / 24.17。
  另外每个放置点离**别人**的初始点都 ≥7.21（实测最近的是三对并列：B 放对 A 初始、B 放对 C 初始、
  C 放对 B 初始，都是 7.2111），免得给一个物体放件时夹爪蹭到还在地上的另一个物体。

- **动作拆解**（每个物体都是这套）：到物体上方 → 垂直下降到抓取高度 → 合爪
  （`angle4` 写成 `servoLimit.minF`，与串口 `S` 同角度）→ 停顿 400ms → 垂直抬起
  → 平移到放置点上方 → 垂直下降到放置高度 → 张爪（`servoLimit.maxF`，与 `O` 同角度）
  → 停顿 400ms → 垂直撤离。

- **启动前校验**：把 6 段直线按 0.5 的步长采样（每段最多 64 点），逐点要求
  "在 `limit` 内 + `isReachable()` + 反解成功且未被吸附"，且相邻采样点的关节角
  跳变不超过 25°（防止反解中途换分支）；还要求当前位姿与手里角度同分支（差 ≤10°）。
  任何一项不过就拒绝启动并保持现状 —— 宁可不动，也不能半路甩臂。

- **串口集成**：`serial_protocol.cpp` 在单字符命令 `switch` 里加了 `A/B/C` 三个分支，
  返回 `PROTO_RES_PICK_STARTED`（10）或 `PROTO_RES_BUSY`（11）；序列执行期间
  `protoHandleLine()` 最前面有忙守卫（`pickPlaceIsBusy() || buttonControlBusy()`），
  **只放行调速指令 `H/L` 与按键命令 `N/R/P/M`**，其余动作指令
  一律返回 `PROTO_RES_BUSY` 且不改状态，并回一行
  `[proto] busy: pick/place or record/play running, command ignored`（在
  `#if WEARM_DEBUG_SERIAL` 里，不影响返回值）。摇杆侧在
  `joystick_control.cpp` 的轴步进循环开头 `if (pickPlaceIsBusy() || buttonControlLocked()) break;` ——
  序列执行与播放/回中期间独占 b/r/c 与末端角（录制期间**不**独占，见下一节）。
  D13 指示灯把"序列在执行"也算作在动（`updateLed(moved || pickPlaceIsBusy() || buttonControlLocked())`），
  否则那十几秒灯是灭的，看着像死机。

## 新增四按键操作接口

本轮新增 `button_control.h` / `button_control.cpp`：四个按键的全部调用接口都封装在
**这一个 cpp** 里（这是需求原文的硬性要求），`meArm.ino` 只调 `buttonSetup()` /
`buttonLoop()`。

- **按键接线**：D2 = 按键1（循环执行取放）、D3 = 按键2（录制）、D4 = 按键3（播放）、
  D5 = 按键4（回中）。四脚 `INPUT_PULLUP`，按下为**低电平**（另一端接 GND），
  25 ms 时间消抖，只认按下沿。D6~D9 是舵机、D13 是灯、D0/D1 是串口、A0~A3 是摇杆，
  D2~D5 是唯一空闲好接的四个脚。
- **串口等价命令**（外部接口不只在按键上）：`N` = 按键1、`R` = 按键2、`P` = 按键3、
  `M`（别名 `0`）= 按键4。**不用 1/2/3/4**：数字键不与任何已占用的命令冲突，
  但用字母可以让一组命令在串口助手里一眼分辨出是按键等价命令。
- **按键1 循环执行**：每按一次依次夹 A、B、C，第四次回到 A。忙时（序列执行中）
  被拒绝且循环序号**不推进**。
- **按键2 录制**：第一次按下开始录（状态「录制中」，串口回 `PROTO_RES_REC_STARTED`=12），
  人工用摇杆操控；第二次按下结束并保存（13）。保存门槛**只剩一条**：末端在 x/y/z 的
  包围盒跨度（`btnTravelSpan()`）**≥10.0**（`BTN_REC_MIN_TRAVEL`）。**没有最小时长限制**
  ——原来还要求"录制时长 >10000 ms"（`BTN_REC_MIN_MS`），**已按要求删除**：1 秒的动作
  只要真走够了位移就照样保存。不达标回 `PROTO_RES_REC_REJECTED`=14。**录制失败会连带
  废掉上一次的录制**（缓冲区已被本次录制复用），代码注释与串口提示都写明了这一点。
- **录制格式**：每个 200 ms 采样周期（`WEARM_REC_TICK_MS`）写**恰好一条** 4 字节记录
  （`BTN_REC_BYTES`），里面把四个关节的增量各压成 8 位有符号数
  （`BTN_ANGLE_UNIT` = 0.5 度/单位，字段范围 ±127 单位 = 每周期最多 ±63.5 度）。
  **不动也要写一条全零记录**，所以回放的时间轴就是录制时的时间轴。超出 8 位字段的
  增量会被夹紧，多出来的部分由 `s_snap[]` 顺延到后面几个周期：总位移仍然精确，
  只是很快的动作会在回放时晚一两个周期到位。字段宽度是按"最快的一档"选的：
  ±63.5 度 / 200 ms = **±317 度/秒**，只有快速档（`setSpeed(2.0, 5, 20)`，最快
  400 度/秒）才会碰到夹紧。
  缓冲 `WEARM_REC_ENTRIES` = **192 条 × 4 字节 = 768 字节 SRAM**，即单次录制上限
  **38.4 秒**（`192 × 200 ms`）；写满置 `s_recOverflow` 并自动收尾，按"不合格"丢弃
  （回 `DISCARD`）。
- **回放子步**：每条记录在回放时被拆成 `BTN_PLAY_SUBSTEPS` = 4 个 50 ms 子步线性
  展开（`btnPlaySub()`），不会"200 ms 跳一格"；总时长仍等于 `s_recLen × 200 ms`，
  预摆 + 播放的耗时与录制时长同量级（探针 [5] 实测 13.02 s = 11.6 s + 1.5 s）。
- **收尾增量**：结束录制时会把积压的尾巴**排空**（`btnStopRecording()` 里最多 8 次
  `btnRecCollect()/btnRecPut()` 循环，直到没有新增量或缓冲写满），而不是只补一条。
  不做这一步，回放终点会停在最后一个整周期上 —— 四关节同时全速时积压正好一个周期的
  位移（200 ms × 100 度/秒 = 20 度），实测末态差 10~13.5 度，见教训 22。
- **按键3 播放**：先用 `BTN_RAMP_MS` = 1500 ms 在关节空间线性预摆到录制起点，
  再按录制时的时间轴复现，结束回空闲。没有录制时回 `PROTO_RES_PLAY_NO_RECORD`=16。
- **按键4 回中**：目标角由 `constant_and_positions.cpp` 新增的
  `bool posGetHomeAngles(SER *ser)` 对 `POS_HOME`（20,0,20）反解得到（`b/r/c` = 90/90/90），
  **angle4 保持当前值不动**；同样是 1500 ms 插值而不是瞬间跳变。探针直接拿这个函数
  当期望值，避免在探针里抄死 90。
- **忙与让位是两套语义**（这是本模块最容易写错的地方）：
  - `buttonControlBusy()` = 录制/播放/回中任一 → 串口动作指令（除调速与 N/R/P/M）被挡。
  - `buttonControlLocked()` = 播放/回中（**不含录制**） → 摇杆让位。
  - 忙守卫必须**豁免 N/R/P/M 本身**，否则录制中发 `R` 想结束录制会被自己的忙守卫吞掉
    （probe_button 专门有一条用例守着这个）。
- **新增返回值**：12 录制开始、13 录制已保存、14 录制被拒、15 播放开始、
  16 无可播放录制、17 回中开始（都定义在 `serial_protocol.h`）。

## 新增绘图功能（铅笔绘制，v1.0.0）

本轮新增 `draw_control.h` / `draw_control.cpp`：机械臂末端夹一支铅笔，在纸面上画图。
**接口、状态机、几何全在这一个 `.cpp` 里**，其它模块只加了一行转交。

- **纸面坐标系**：默认纸面高度 `z = 12.0`（与取放台面同高，笔尖"刚好落在纸上"），
  内置图形的中心 `(20,0)`、半宽 `6`（顶点落在 ±半宽 的正方形里 → 默认 x[14,26] y[-6,6]）。
  三个量都能标定：串口 `p<纸面高>` / `n<半宽>` / `o<x>,<y>`，越界一律拒绝且不改动。
- **任务与阶段**：任务号 0 直线 / 1 字母N / 2 三角形 / 3 字母Z / 4 字母V / 5 五点折线 / 6 五点曲线
  （默认直线，串口 `F` 循环切换，每换一次回一行 `OK F=<模式>`，模式标签见 `drawTaskTag()`：
  `LINE/N/TRI/Z/V/POLY/CURVE`；原来的 字母N / 三角形 / 字母Z 曾在分支 draw_control 里
  为省 flash 删掉，现已按题目"从 N/三角形/Z/V 里选一种、同组不得完全相同"的要求全部恢复）。
  阶段 `IDLE→HOME→TRAVEL→PLUNGE→PATH→LIFT→RETURN→IDLE`，
  示教任务先 `HOME→TEACH→TEACH_WAIT→HOME→…`。
- **抬笔/落笔高度**：`DRAW_LIFT_DZ 4.0`；`liftZFor()` 若"纸面 +4"不可达就每次降 0.5
  直到可达（避免在小臂展区域直接判失败）。**抬笔阶段必须整段高于纸面**，
  否则平移时笔尖会在纸上拖出一道多余的线（probe_draw 有一条专门守着）。
- **速度**：笔尖线速度上限 `DRAW_V_MAX 3.0` 单位/秒，梯形加减速（`DRAW_ACCEL 6.0`），
  关节角速度硬上限 `DRAW_MAX_DPS 70.0`（超限就拒绝这一步，由调用方减小步长）。
  **分支 draw_control 把它们整体放慢**（原 8.0 / 12.0 / 110.0），并且 `pathTick()`
  每一轮最多只送出 `DRAW_STEP_MAX 0.02` 单位的位移（正常 loop 周期下算出来的步长
  本来就只有 0.003~0.015，这个上限只在 loop 被拖长时才生效）
  （probe_draw 实测相邻两步最大 0.015 单位）。
- **路径校验**：复用 `pick_place.cpp` 的 `solveJoint/pointOk/segmentOk` 思路
  （`DRAW_PATH_SAMPLE_STEP 0.25`（本分支由 0.5 收紧）、最多 96 采样、相邻采样反解跳变 ≤ `25°` → 换分支就判这条直线不能走）。
  五点折线与曲线在启动前先把"待机位→起点上方→垂直落笔→轨迹本体→终点抬笔"整条路校验一遍，
  失败就回 `PROTO_RES_DRAW_REJECTED` 且 `Pos` 一个字节都不动。
- **曲线**：向心 Catmull-Rom（节点间距取 `sqrt(|dP|)`，端点用弦方向切线），
  逐段 64 采样求弧长后按弧长匀速走，所以"平滑"不是靠调参而是几何决定的
  （probe_draw 实测每 5 ms 最大转角 0.38°、相邻采样最大间距 0.015）。
- **五点示教**：`TEACH` 阶段由本模块**自己读摇杆**做**笛卡尔点动**
  （A0→x、A1→y、A3 前推→z 下降；**A2（夹爪）默认整路不响应**，见"示教摇杆点动修复"一节），
  按键1 记录（5 点记满自动开始，也可按键4 手动开始）、
  按键2 撤销、按键3 取消。记录的点就是 `Pos.rec`，绘制时按这些点连线/插值。
  每格位移按偏转比例在 `DRAW_JOG_STEP_MIN 0.02 ~ DRAW_JOG_STEP_MAX 0.25` 工作区单位之间缩放，
  步进间隔按偏转在 `speed.minDelayMs ~ fullDelayMs` 之间插值（**偏转越大间隔越长**）。
- **过点判定**：`pathTick()` 里当已走过的弧长越过第 i 个点的弧长位置时才量距离，
  `<= DRAW_POINT_TOL 0.8` 记为该点命中（`drawLastPointsHit()`）。
- **按键分工（按阶段自动切换语义）**：示教中 1=记录 2=撤销 3=取消 4=开始；
  绘制中 1=暂停 2=继续 3=取消；空闲时四个按键仍是原来的循环取放/录制/播放/回中。
  转交点只有一行：`button_control.cpp` 的 `btnAction()` 开头
  `if (drawAcceptButton(key)) return drawHandleButton(key);`。
- **暂停/继续/取消**：暂停只是置 `s_paused`（阶段与已走弧长都保留，笔尖一动不动）；
  继续清暂停并把速度清零重新加速（**从暂停处接续，不会从头重画**）；
  取消先**垂直抬笔**再回待机（`drawCancel()` 里那行 `s_phase = DRAW_PHASE_LIFT;`
  千万不能漏，见教训 24）。
- **串口**：`F` 换任务 / `D` 开始 / `G` 记录 / `E` 撤销 / `Q` 暂停 / `U` 继续 / `W` 取消，
  标定 `p`/`n`/`o`；新增返回值 **18~26**（任务已选/已开始/已暂停/已继续/已取消/示教点已记录/
  示教点已撤销/被拒/已标定，定义在 `serial_protocol.h`）。
- **三方互斥**：绘图与"取放序列""按键录制/播放/回中"互斥（`drawControlBusy()` 进串口忙守卫，
  `drawControlLocked()` 让摇杆整段让位）；**绘图命令本身必须豁免忙守卫**，
  否则"绘制中想暂停"会被自己的忙守卫吞掉（和 N/R/P/M 同一个坑）。
- **卡死保护**：连续 `DRAW_STALL_LIMIT 500` 轮没能让状态前进（关节速率或可达性受限），
  就退回空闲并打印原因，不会永远停在某个阶段。

## v1.1.0 —— Uno 容量压缩与配置开关

**问题**：v1.0.0 把取放、四按键、绘图三套功能全编进同一个固件，Arduino IDE 直接报

    Sketch uses 51452 bytes (159%) of program storage space. Maximum is 32256 bytes.
    Global variables use 2319 bytes (113%) of dynamic memory, leaving -271 bytes for
    local variables. Maximum is 2048 bytes.
    Sketch too big; ... text section exceeds available space in board

**结论**：逐函数压过一轮之后，三功能同时编进去是 **32842 B / 1163 B**
（比 v1.0.0 小 36%，其中 SRAM 从 2319 B 降到 1163 B，早就不超了），
但 **flash 仍然差 586 B**，所以 v1.1.0 的出厂默认只开「取放 + 绘图」两功能
（29476 B / 638 B），四按键在 `weArm_config.h` 里把 1 个数字改回 1 就能换回来。

### 第一步：把调试日志关掉（−9260 B）

`weArm_config.h` 的 `WEARM_DEBUG_SERIAL` 默认 0。六个模块各自的中文
`Serial.print(F("..."))` 日志加起来 **9260 B**（51452 → 42192）。
顺带纠正 v1.0.0 注释里的一个错误说法：**AVR 的 `.rodata` 是并进 `.text` 的
（`avr-size -A` 实测），字符串常量只在 flash 里，不占 SRAM**；
真正让 SRAM 涨的是 `button_control.cpp` 那个 1024 B 的录制缓冲和一堆 `static` 表。

同时把「必须保留的应答」和「可删的调试明细」拆成两级开关：
`WEARM_DEBUG_SERIAL`（明细，默认 0）与 `WEARM_SERIAL_RESPONSES`（`OK`/`REJECTED`
这类应答，默认 1）。v1.0.0 里所有 `Serial.print` 都被 `#if WEARM_DEBUG_SERIAL`
包着，**一旦关调试整机就变成哑巴**——开机没有任何输出、任何命令都没有回显。

### 第二步：逐函数压缩（42192 → 32842，−9350 B）

一轮一轮实测出来的，按收益从大到小：

- **合并三个模块重复的几何核心**（−936 B）：`pick_place.cpp` 与 `draw_control.cpp`
  各自有一份 `solveJoint` / `pointOk` / `segmentOk` / `setJoints`，LTO 已经把
  它们复制成 2~3 份（`lto_priv.*`）。抽到新文件 `path_core.h`，用
  **非 static 的 `inline`**（走 COMDAT，链接器保证只留一份），
  `draw_control.cpp` 保留同名转发函数，调用点一行不用改。
- **`constant_and_positions.cpp`**（−542 B）：`getAngleEx` 去掉冗余的候选角枚举
  （2530 → 2040）；删掉整个 `applyJointLimits` 与它的备份/回滚——进函数前
  angle1..3 已被**同样容差**的区间判断筛过，"微小负角归零"只会把角推向区间内部，
  于是只需要判 angle4 并且在写 `Pos.ser` **之前**返回 false，回滚自然就不需要了。
- **`move.cpp` + `joystick_control.cpp`**（−814 B）：改为"副本试算、全通过才提交"；
  6 个 `switch` 分支折成 PROGMEM 打包表 `DIR_CODE[7]`；`posOutOfRange`/`samePose`
  改成 3 轴循环与逐位比较；摇杆的浮点比例夹取改成整数夹取。
- **`serial_protocol.cpp`**（−86 B）：`protoHandleLine` 的 19 路 `switch` 换成
  `if/else` 链——原来 GCC 会生成 64 项 `.rodata` 跳表 + 24 位范围检查 + `_tablejump2`。
  这个文件里很多"看起来能省"的写法实测是**变大的**（例如给 `protoFlushLine`
  加 `noinline` 反而 +150 B）。
- **`button_control.cpp`**（−264 B）：录制缓冲从 512 × 2 B 的 `(code, arg)` 条目
  改成 **128 × 3 B 的打包记录**（每 100 ms 一条，四个关节的 6 位有符号增量、
  0.5° 为单位），`s_buf` 从 1024 B 掉到 384 B；单次录制上限 12.8 s
- **`draw_control.cpp`**（−2020 B）：5 张图形表进 PROGMEM；`s_segLen[5]` 删掉
  （弧长现算）；`curveSpan` 从 2398 B 压到 1470 B；状态变量收窄成 `int8_t`。
- 常量表一律 PROGMEM，但注意：**这只能省 SRAM，省不了 flash**——
  `.data` 的初值本来就在 flash 里有一份（`Program = .text + .data`），
  搬进 `.rodata` 还是那一份，只是不用再拷进 RAM。

### 实测容量矩阵（`avr-size --mcu=atmega328p`）

| 配置 | Program | 占 32256 | Data | 占 2048 |
|---|---|---|---|---|
| 取放 + 四按键 + 绘图（v1.0.0 默认） | 51452 | **159%** | 2319 | **113%** |
| 同上，仅关调试日志 | 42192 | 130.8% | 2133 | 104.2% |
| 取放 + 四按键 + 绘图（压缩后） | 32842 | **101.8%** | 1163 | 56.8% |
| 取放 + 绘图（**v1.1.0 默认**） | 29476 | 91.4% | 638 | 31.2% |
| 绘图 + 四按键 | 30074 | 93.2% | 1129 | 55.1% |
| 取放 + 四按键 | 20126 | 62.4% | 953 | 46.5% |
| 只要取放 | 16866 | 52.3% | 428 | 20.9% |
| 只要绘图 | 26922 | 83.5% | 605 | 29.5% |
| 只要四按键 | 15796 | 49.0% | 919 | 44.9% |

复现任意一行：

    powershell -NoProfile -ExecutionPolicy Bypass -File .selfcheck\avr_build.ps1 `
        -SketchDir . -BuildRoot .selfcheck\out\chk `
        -ExtraDefs @('-DWEARM_ENABLE_BUTTONS=0')

### 为什么三功能不再挤一挤（剩下的 586 B 在哪）

最大的一笔"外部"开销是 **Arduino 的 `Serial` 栈：实测 1014 B flash / 181 B RAM**。
量法：同一个最小 sketch，只做 4 个 `Servo` 的 `attach`/`write` 是
Program 1876 / Data 63，再加一句 `Serial.begin(115200); Serial.print("boot");`
就变成 2890 / 244（两个 sketch 留在
`.selfcheck/out/probe/a_noserial/sk.ino` 与 `.selfcheck/out/probe/b_serial/sk.ino`）。
另外 `Serial`/`Servo` 的全局对象还有 202 B 的构造代码（`_GLOBAL__I_...`），
反汇编看就是库自己的 `servo_info[]` 注册循环。

也就是说，要再挤出 586 B 只剩"把 `Serial` 换成裸 UART 寄存器读写"这一条路。
它要重写 `begin/print/println/write/available/read/flush` 一整层、
自己管接收中断，属于**在硬件通信这个最不能出错的地方动刀**，
不适合放在一个"修编译错误"的版本里，所以 v1.1.0 不做，如实记录在这里。

**本轮把这条路走通了**（详见下一节）：省 852 B flash / 109 B SRAM，
三功能全开 32842 → 31936 B，**默认配置就是全功能**。

顺带发现但**没有采纳**的几个写法（实测不划算或不等价）：

- `-Wl,--relax` 能再省 400 B 出头，但要用户在 `platform.local.txt` 里加链接参数，
  默认编译享受不到，所以不作为交付方案。
- `constant_and_positions.cpp` 里只剩一处 `acos`（`acos(cosC)` 消分支用），
  删掉能省 100~150 B，但改写会动到反解的数值，而探针对反解残差很敏感。
- 位折叠命令分派（`'M'/'N'/'P'/'R'` 折成 0/1/2/3）看着能省几十字节，
  实测**直接打断功能**：那四个字符的差值其实是 0/1/3/5，`'R'` 会被判成未知命令，
  串口再也结束不了录制。这一处已经在 `button_control.cpp` 里加了警示注释。

### 怎么选配置

改 `weArm_config.h` 里三个数字即可（0 = 关，1 = 开），别的文件都不用动：

    WEARM_ENABLE_PICK_PLACE   取放序列（串口 A/B/C、按键1 循环取放）
    WEARM_ENABLE_BUTTONS      按键模块（录制/播放/回中/循环取放，串口 N/R/P/M/0）
    WEARM_ENABLE_DRAW         绘图（铅笔轨迹）
    WEARM_BUTTON_PINS         0 = 不读 D2~D5 的物理按键（本轮起的默认值）
                              1 = 四个独立按键接 D2~D5（INPUT_PULLUP、按下接地）

关掉的功能会被链接器整段丢掉（头文件里退化成空 inline 桩），
命令行 `-D` 依然可以覆盖本文件的默认值。
**v1.1.0 时默认是「取放 + 绘图」，四按键关着；本轮起三个功能开关默认都是 1**
（见下一节）。但**物理按键默认不读**：本机 D2~D5 上没有独立按键，只把摇杆自带的
SW 脚接到 D2，而右摇杆推到最前会压合那颗轻触开关、假触发"按键1 循环取放"，
所以 `WEARM_BUTTON_PINS` 默认 0，四个功能全部走串口字符
（`N` 循环执行 / `R` 录制开关 / `P` 播放 / `M` 或 `0` 回中）。
详见"上机才能确认"第 7 条。

**注意**：`mock/Arduino.h` 为配合 `draw_control.cpp` / `pick_place.cpp` 的
`PROGMEM` 常量表，新增了 `pgm_read_byte/word/dword/float/ptr`；
因为 PC 上 `double` 是 64 位而 AVR 上就是 32 位 float，`pgm_read_float`
在 mock 里直接按 `double` 读，才能让两端算出一模一样的结果。

### 两个新踩到的坑

1. **LTO 偶发 `lto1.exe: internal compiler error: resolution sub id ... not in object file`**：
   换一个全新的 `-BuildRoot`（清掉 `core.a` 之外的中间 `.o`/`.ltrans`）重试即可，
   是 avr-gcc 7.3.0 的 LTO 缓存问题，不是代码问题。
2. **写完新构建目录记得先更新 `.gitignore`**：`avr_build.ps1` 默认的
   `-BuildRoot` 是 `.selfcheck/avrbuild`，`git add -A` 会把 `core.a`
   和几十个中间文件一起提交进去。

## 角度语义回归 / 七任务恢复 / 与任务无关代码删减（当前版本）

这一节描述**现在**的行为，优先级高于下面任何历史章节（凡与本节冲突的，
以本节为准；冲突章节都加了 ⚠ 作废标注）。

### 1) 串口 `x/y/z` = 三个舵机的角度（不是末端坐标）

题目的例子是 `x10,y30,z20`，要求"三个指定舵机的 PWM 占空比同步改变"，所以
`x/y/z` 直接映射到三个关节角，**不做逆解**：

| 轴 | 舵机 | `Pos` 成员 |
| --- | --- | --- |
| `x` | 基座 b | `Pos.ser.angle1` |
| `y` | 上臂 r | `Pos.ser.angle2` |
| `z` | 下臂 c | `Pos.ser.angle3` |

- 解析：`protoParseAxisLine()`（接受大小写、空格、`x=20`、小数、只给一部分轴）
- 落地：`protoApplyAngles()` —— 把提到的轴写进 `Pos.ser.angle1..3`，
  再 `clampServoAngles()`（按 `servoLimit` 夹取，**夹取而不拒绝**，保证位姿有定义）
  与 `recFromServo()`（正解刷新 `Pos.rec`，保持"关节角是唯一真值"）
- 回复：成功 `OK`（`PROTO_RES_ANGLES_SET`）；语法错 `ERR`；忙时 `BUSY` 且状态零改动
- `x200` 这类超行程值会被夹到 180（`servoLimit.maxB`），不会静默丢掉

### 2) 绘图任务表回到 7 项，并回报当前模式

`LINE 0 / N 1 / TRIANGLE 2 / Z 3 / V 4 / POLYLINE 5 / CURVE 6`；
`drawTaskTag()` 给出 ASCII 短标签 `LINE / N / TRI / Z / V / POLY / CURVE`，
串口 `F` 换任务时回一行 `OK F=<tag>`（例如 `OK F=TRI`），
`WEARM_DEBUG_SERIAL=1` 时另打印中文名。

### 3) 删掉的代码（与题目无关或已无调用点）

| 符号 | 原因 |
| --- | --- |
| `moveAxisStep()` | 只是 `moveJointStep()` 的转发，无调用点 |
| `joystickGetMode()` / `JOY_MODE_VERT` / `JOY_MODE_COUNT` | 恒返回 `JOY_MODE_PLANE`，无调用点 |
| `atRangeEdge()` | 边界判定，无调用点 |
| `posToolOpen()` / `posToolClose()` | 只被串口 `k/K` 使用 |
| 串口 `1/2/3` | 档位直达，题目只要求 `H/L` 升降档 |
| 串口 `k/K` | 末端步进开合，题目只要求 `O/S` 全开全关 |
| `protoAxisServoIndex[]` | 无调用点（轴→舵机的映射直接写成 `angle(a+1)`） |
| `PROTO_RES_COORDS_REJECTED` | 坐标语义专用，逆解路径已删 |
| `WEARM_SHOULDER_HEIGHT` | 坐标语义专用 |

对应地，结果码 `5`（原 `1/2/3`）留空，`6` 改为 `PROTO_RES_FEATURE`
（`!` / `!P` / `!B` / `!D` 的返回值），12~26 一律不动以免牵动探针与文档。

## 本轮改动 —— 地面坐标系指令 / 全功能默认开启 / 裸 UART 后端 / 失败回复分级

> **⚠ 本章第 1 节已作废**（v1.6.4 起）：串口 `x,y,z` 又改回"直接写三个舵机的角度"
> —— 题目给的例子是 `x10,y30,z20`，要求三个指定舵机的 PWM 占空比同步改变，
> 逆解出来的中间量反而对不上题。地面坐标系版本保留在分支 `backup/xyz-cartesian`
> （= tag `v1.6.3`）与 `dist\meArm_xyz_cartesian_v1.6.3_source.zip`。
> 下面这一节只作为历史记录保留，**不要照它理解现在的串口语义**；
> 现行语义见"角度语义回归"一节。

三个目标：把串口 `x,y,z` 从"直接写关节角"改成**地面坐标系下的末端点**；
让串口 `R` 不再动辄回一行含混的 `REJECTED`；把三功能全开压进 Uno 并设为默认。

### 1) `x,y,z` 改成地面坐标系（**破坏性变更**）

坐标系按题目要求：**原点 = 过肩关节的地面垂线的垂足，x 轴 = 机械臂初始面朝
方向，z 轴 = 垂直地面向上**（右手系，+y 在初始面朝方向的左手边）。

内部坐标本来就已经是同一套：`constant_and_positions.cpp` 的 `recFromServo()`
里 `theta = (90 - b)/RADtoDEG; x = xPlanar*cos(theta); y = xPlanar*sin(theta)`，
b = 90° 时朝 +x、b < 90° 时转向 +y，所以两套坐标只差 **z 的原点**：

    z_内部 = z_地面 − WEARM_SHOULDER_HEIGHT

`WEARM_SHOULDER_HEIGHT` 新增在 `constant_and_positions.h`，默认 **20.0**。
20 不是拍脑袋来的：内部 z 的下限原本就是 `limit.minZ = −20`，把地面定在 −20，
可达范围正好变成 **z ∈ [0, 60]，且反解不会算到地面以下**。真机肩高不同就改这一个常量。

语法没变（`x20,y0,z40`，也接受 `x=20` 和只给一部分轴），但含义彻底变了：

- 旧：`x10` = 基座关节转到 10°
- 新：`x10` = 末端水平位置 x = 10，再由 `getAngleEx()` **反解**成四个关节角

因此**不可达的点会回 `REJECTED`**（旧实现是照写关节角，"写不进去"也不吭声）；
只给 z 轴时另外两个轴沿用当前末端位置，等价于"竖直平移"。

### 2) 串口回复分级（不再只有 OK / REJECTED）

| 回复 | 含义 |
|---|---|
| `OK` / `OK #` | 已执行（`O`/`S` 会带上夹爪当前角度；`F` 换任务回 `OK F=<tag>`） |
| `BUSY` | 命令认识，但取放/录制/播放/绘图正在跑，先让位 |
| `OFF` | 该模块**编进了固件**，但被 `!P` / `!B` / `!D` 在运行时关掉了 |
| `DISCARD` | `R` 结束录制，但这段录制不合格（太短/没有位移/溢出），已丢弃 |
| `EMPTY` | `P` 想回放，但根本没有录制数据 |
| `ERR` | 语法错（例如 `!` 后面跟了不认识的功能字母） |
| `REJECTED` | 固件里**没有**这个模块，或（关闭的模块收到绘图/取放命令）轨迹校验不过 |

`R` 之前"一输入就 REJECTED"是两层原因叠出来的：v1.1.0 出厂配置把四按键
（`WEARM_ENABLE_BUTTONS`）关掉了，按键命令在门控处直接回 `REJECTED`；
而录制"太短/没位移"也回同一个 `REJECTED`。现在默认全功能，且原因分开报。
记住 `R` 是**两段式**：第一次 R 开始录制（回 `OK`），第二次 R 结束并校验
（回 `OK`，或 `DISCARD` 表示这段不要了）。`P` 没有数据时回 `EMPTY`。

### 3) 运行时功能开关 `!`

- `!` 查询当前状态，回一行 `P=1 B=1 D=1`（1 = 启用，0 = 已关闭）
- `!P` / `!B` / `!D` 切换取放 / 按键 / 绘图；未编进固件的模块回 `REJECTED`

语义边界（别误解）：

- 只影响**串口分发**。关掉 `B` 之后（在 `WEARM_BUTTON_PINS=1` 接了实体按键的
  机器上）实体按键照样能用，正在跑的任务也不会被中止
  （本机默认 `WEARM_BUTTON_PINS=0`、没有实体按键，所以关掉 `B` 就是这四条命令
  `N/R/P/M/0` 全部回 `REJECTED`，见"本轮改动"第 7 节）
- 只能关掉"已经编进固件"的模块；编译期裁掉的功能永远回 `REJECTED`
- 上电时运行时状态 = 编译期状态（`serialProtocolBegin()` 里重置）

### 4) 裸 UART 后端：省下 852 B flash / 109 B SRAM

`serial_protocol.cpp` 新增 "serial backend" 一段，release 的 AVR 构建不再使用
Arduino 的 `HardwareSerial`：

- 发送：`while (!(UCSR0A & (1<<UDRE0))) {} UDR0 = c;`
- 接收：`ISR(USART_RX_vect) { protoRxStore(UDR0); }` 填 64 字节 2 的幂环形缓冲，
  主循环用 `protoRxTake()` 取字节（空返回 −1），`serialProtocolLoop()` 的读取循环
  改成 `while ((c = protoRxTake()) >= 0)`
- 初始化照抄 core 的算法：`UCSR0A = 1<<U2X0`、
  `UBRR = (F_CPU/4/PROTO_BAUD − 1)/2`（16 MHz + 115200 → 16）、
  `UCSR0C = 8N1`、`UCSR0B = RXEN0|TXEN0|RXCIE0`

**为什么必须整层换而不是逐个函数裁**：只要链接了 `Serial` 对象，它的 vtable 就会
把 `HardwareSerial::write/_tx_udr_empty_irq/flush/available/read/peek`、
`Print::write`、`__vector_18/19`、`serialEventRun` 甚至 157 B 的 `Serial` 对象
全部拖进镜像（实测清单见 git 历史里的 `avr-nm` 输出），逐函数裁剪做不到。

退路：`-DWEARM_SERIAL_ARDUINO=1` 强制用回官方串口库；`WEARM_DEBUG_SERIAL=1`
和 PC 端 mock 构建也自动走原来的 `Serial` 路径（调试日志与协议回复要共用一条
有序输出流，探针语义因此完全不变）。

**这一层是唯一没法在 PC 上验证的部分**（中断和寄存器只在 AVR 上存在）：
环形缓冲的推入/取出、`USART_RX_vect`、寄存器初值都不在 mock 的覆盖范围里，
PC 探针只能证明"改用 `protoRxTake()` 之后 mock 路径的行为没变"。
所以上机第一件事就是确认 115200 baud 下收发正常（见文末"上机才能确认"）。

### 5) 本轮容量矩阵（实测）

| 配置 | Program | 占 32768 | Data | 占 2048 |
|---|---|---|---|---|
| 取放 + 按键 + 绘图（**本轮默认**） | 31936 | 97.5% | 1015 | 49.6% |
| 取放 + 绘图（按键关） | 28534 | 87.1% | 490 | 23.9% |
| 取放 + 按键（绘图关） | 19226 | 58.7% | 807 | 39.4% |
| 绘图 + 按键（取放关） | 29184 | 89.1% | 981 | 47.9% |

Uno 实际可用 flash 是 32256 B（avr-size 按 32768 算百分比，512 B 留给 bootloader），
所以默认配置**还剩 320 B**。复现任意一行（注意 `-ExtraDefs` 收的是数组）：

    powershell -NoProfile -ExecutionPolicy Bypass -File .selfcheck\avr_build.ps1 `
        -ExtraDefs @('-DWEARM_ENABLE_BUTTONS=0')

`avr_build.ps1` 已不再编译 Servo 库（换成自研 `servo_drive.cpp`），
mock 侧的 `mock/Servo.cpp`、`mock/Servo.h` 也已删除。

### 6) 新增/改动的探针

`probe_protocol` 的"串口应答与运行时功能开关"一段（12 段）**移到了压力测试之前**：

> 压力测试会随机发单字符 `'A'..'Z'`，其中 `A/B/C` 会启动取放序列，
> 而 `pickPlaceIsBusy()` 是 `s_obj >= 0`，一旦启动就再也不会回到空闲 ——
> 后面的 `R` 只能回 `BUSY`。所以应答测试必须先跑，并以"结束录制"收尾。

新增断言：`!` 回 `P=1 B=1 D=1`；`!P`/`!B`/`!D` 往返切换；
`!B` 关掉后 `N` 回 `OFF`（且输出里不能出现 `REJECTED`）；
录制中发 `O` 回 `BUSY`；立刻结束录制回 `DISCARD`；没有数据时 `P` 回 `EMPTY`。

**教训**：探针用 `-DWEARM_DEBUG_SERIAL=1` 编译，mock 的输出流里既有中文调试日志
又有协议回复，断言只能查"回复这一行在不在"
（`out.find("OK\n") != std::string::npos`），**不能整串相等**。

## 本轮改动 —— 四个实机问题的修复（方向 / 无故乱动 / 录完按 P 报 busy / 注释）+ 物理按键停用

现场反馈四条：①左右旋转的舵机转向反了、抓取时 `O`/`S` 反了；②机械臂经常无故乱动；
③录完动作再输入 `P` 触发 `BUSY`、录的动作执行不了；④注释与实现不符。
之后又追加一条：⑤右摇杆向前本该转下臂，却触发了自动取放 —— 见第 7 节。

### 1) 基座与夹爪的方向镜像（问题 ①）

根因是**装配**：这台机器的基座回转（通道 0 / b）与末端夹爪（通道 3 / f）的舵机是
反向装上的，逻辑角增大时它们物理上朝反方向走。`O` 走 `maxF` 本该张开、实际夹紧，
就是同一个原因（不是 `O`/`S` 写反了）。

修法**不动 0~180 映射、也不动任何逻辑角**，只在唯一写出口 `meArm.ino` 的
`writeServo()` 里对这两个通道做一次"在自身行程窗口内镜像"：

    physical = (min + max) - logical      /* ch0 用 [minB,maxB]=[0,180]
                                             ch3 用 [minF,maxF]=[60,150] */

限位、反解、录制回放、绘图示教全都继续用逻辑角（唯一真值），变的只是最后送到舵机的
那个数；`f` 的窗口对 210 对称，镜像后不可能被推出机械安全区。开关在
`weArm_config.h`：`WEARM_MIRROR_BASE` / `WEARM_MIRROR_TOOL`（换回正装装配就置 0）。

> **注意副作用**：基座镜像之后，所有含 `±y` 的笛卡尔目标点都会落到**镜像侧**
> ——`pick_place.cpp` 顶部的 `PICK_SRC`/`PICK_DST` 正是这种点。若上机发现 A/B/C 去
> 了反方向，那说明这些常量是按"反装基座"标定的，把它们的 `y` 取反即可
> （或直接把物体摆到镜像侧）。这一条列进了文末"上机才能确认"。

### 2) 摇杆中位自标定（问题 ②）

`JOY_CENTER` 是硬编码 512、死区只有 15 个计数，而真实双轴手柄的机械中位常见偏
20~60 个计数。偏 20 就已经越过死区 ⇒ 手不碰摇杆时每一路都被当成"轻微推杆"，
每过一个时间门就步进一次 —— 机械臂持续缓慢地自己乱走。这是"无故乱动"最可能的
软件侧原因。

修法：`joystickSetup()` 里四路各平均 `JOY_CAL_SAMPLES`（8）次，把相对 512 的静态
偏差存进 `s_centerOff[]`，`readAxisAmp()` 读到的值先扣偏差再算死区与方向
（下游所有 `raw > JOY_CENTER` 判断因此一行都不用改）。偏差超过
`JOY_CAL_MAX_OFF`（64）判为"标定时手正压着摇杆"，退回 0（宁可回到老行为，也不把
一路轴标歪）。`probe_joystick` 新增 [9] 段：偏 +40 静止 30 轮必须一动不动、
偏置之上推杆方向仍然正确、偏 +100 不采纳、标准 512 与历史行为一致。

### 3) 录制中直接按 `P` / 按键3：先收尾再播放（问题 ③）

旧 `btnActionPlay()` 第一句就是"录制中 → `BUSY`"，而录制只能由"结束录制"
（按键2 / 串口 `R`）停掉；用户按播放时心里已经是"我录完了"，于是永远收到 `BUSY`。

现在改成：录制中按 `P` 先调用一次 `btnStopRecording()` 收尾 —— 合格（末端有明显位移）
就紧接着播放，不合格（没动 / 缓冲溢出）就如实回 `DISCARD` 让他重录，
不再是含糊的 `BUSY`。`probe_button` 新增 [11] 段覆盖这两条路径，并断言回放终态
等于"按 P 那一刻"的位姿。

> 顺带确认两件事：①缓冲是 **192 条 × 200 ms = 38.4 s**（4 字节/条），再长的录像会写满
> 溢出（回 `DISCARD`）；②**"录制时长必须 >10 s"这条最下限于本轮删除**（见 `button_control.h`），
> 所以现在 1 秒的动作只要走够了 10 个坐标单位位移就照样保存，可用的录制窗口从
> 原来的 10.0~12.8 s 变成 0~38.4 s。`probe_button` [3] 段新增了一条
> "8.2 秒短录像只要位移够就回 `REC_SAVED`"的回归。

### 4) `servo_drive` 的注释与帧尾写法（**没有修 bug，只是把话说清楚**）

审读时一度怀疑"帧尾现算剩余量"会 uint16 下溢、把帧长变成 ~52.8 ms。**核对后确认
v1.3.0 的实现本来就是对的**：帧尾比较值是在"4 路都发完"那次中断里算的，那时
`nowTicks` 只有四路脉宽之和（默认 12000，最宽 <19184），`40000-12000` 不会下溢。
本轮只做两件事：把帧尾写成绝对常量 `*nextDelayTicks = SERVO_FRAME_TICKS;`
（与旧的 `nowTicks + remain` **逐位等价**，删掉从未触发的 40 tick 保护与 `s_phase`），
并把"为什么不能在帧尾中断里现算"这个**危险点**写进注释（将来真有人把这段挪到
帧边界分支里就会踩到）。

`probe_servo_drive` 新增带**中断延迟**的时序模型 `framePeriodTicks(latency)`：
旧模型的 `nowTicks` 恰好等于上一次排定的比较值（零延迟），验证不了真实帧长。
新用例断言延迟 2/6/30 tick 时帧间隔 ∈ [40000, 40000+8·延迟]（实测 40002/40006/40030）
且绝不接近 ~52800。

### 5) 注释修正（问题 ④）

- `meArm.ino` 头注释（当时还叫 `wearm.ino`）：`x/y/z` 明确写成**末端空间直角坐标**（旧的"三个关节角"
  说法是 v1.0.0 的语义，已标注【破坏性变更】）；补 `!` / `!P` / `!B` / `!D`、
  补"命令都有短回复"、补摇杆中位自标定与方向镜像两段；按键3/`P` 的
  "先收尾再播放"也写进命令表。
- `weArm_config.h`：容量表更新为本轮实测（见下），并注明只剩 652 B 余量。
- `servo_drive.h/.cpp`、`joystick_control.cpp`、`button_control.cpp`：见上面各节。
- **新增 `WEARM_BUTTON_PINS`（默认 0）**：见下一节（物理按键默认不接、也不读）。

### 6) 本轮容量矩阵（实测）

| 配置 | Program | 占 32768 | Data | 占 2048 |
|---|---|---|---|---|
| 取放 + 按键 + 绘图（**默认**） | 31604 | 96.4% | 994 | 48.5% |
| 取放 + 绘图（按键关） | 28756 | 87.8% | 497 | 24.3% |
| 取放 + 按键（绘图关） | 18884 | 57.6% | 786 | 38.4% |
| 绘图 + 按键（取放关） | 28848 | 88.0% | 960 | 46.9% |

比 v1.3.0 各大了 200~240 B（中位自标定 + 方向镜像 + 录制中按 P 收尾），
但本轮把 `WEARM_BUTTON_PINS` 默认改成 0、不再读 D2~D5 又省回 **510 B flash /
28 B SRAM**，删掉"录制时长必须 >10 秒"的判定再省 **58 B**（含按键模块的三行各减
58 B，`BUTTONS=0` 那行不受影响），最终默认配置比 v1.3.0 净省 **332 B**。
默认配置相对 32256 B 可用 flash **只剩 652 B**，下一次改动前务必先复测。

### 7) 物理按键停用：右摇杆推到最前会假触发"循环取放"（问题 ⑤）

**现象**：右摇杆向前（本应让下臂向前转）推到底，机械臂却开始自动取放。

**根因（代码侧证据）**：`joystickLoop()` 里没有任何取放/按键调用；`pickPlaceStart()`
全工程只有两个调用点 —— 串口 `A/B/C` 与 `button_control.cpp` 的 `btnActionCycle()`
（物理按键1）。所以推杆本身不可能启动取放，一定是 **D2 被拉低**。本机 D2~D5 上
没有独立按键，只把摇杆自带的按压开关（KY-023 的 SW 脚）接到了 D2 = 按键1；
推到最前时机械上会压合那颗轻触开关 → 一次假"按下沿" → `pickPlaceStart()` 抢走
正在手动推杆的操作，摇杆随即被 `joystick_control.cpp` 的 `locked`
（`pickPlaceIsBusy() | buttonControlLocked() | drawControlLocked()`）锁住 ——
现象正好是"下臂动一点就停、然后开始取放"。

**改法（固件侧，不依赖改线）**：`weArm_config.h` 新增第 4 节开关

    WEARM_BUTTON_PINS   0（默认）= 完全不读 D2~D5：buttonSetup() 不做 pinMode、
                        buttonLoop() 不扫描、btnEdge()/BTN_PIN[]/三个消抖数组
                        整段被 `#if` 裁掉（省 510 B flash / 28 B SRAM）
                        1 = 恢复四个独立按键接 D2~D5 的老接线

按键的四个功能因此全部由串口字符触发（本来就有等价命令）：

| 功能 | 串口 | 物理按键（改成 1 才有） |
|---|---|---|
| 循环执行 A→B→C | `N` | 按键1 / D2 |
| 录制 开/关 | `R` | 按键2 / D3 |
| 播放上一次录制 | `P` | 按键3 / D4 |
| 回中（POS_HOME） | `M` 或 `0` | 按键4 / D5 |

**注意**：`WEARM_ENABLE_BUTTONS` 仍然保持 1 —— 串口 `N/R/P/M/0` 走的就是这个模块，
关掉它这四条命令会一起消失。`WEARM_BUTTON_PINS` 只裁剪"读引脚"那一段。
绘图示教/绘制期间的按键语义（记录/撤销/取消/开始、暂停/继续/取消）是同一套按键编号
（`BTN_KEY_*` = `DRAW_KEY_*`），所以同样能用 `N/R/P/M/0` 触发，另有
`G/E/W/Q/U/D` 等专用命令。忙守卫对 `N/R/P/M` 与绘图命令的豁免不变。

**探针**：`probe_button` / `probe_draw` 靠模拟 D2~D5 电平测按键逻辑，所以
`run_all.ps1` 给**探针**单独加了 `-DWEARM_BUTTON_PINS=1`（`$probeCfg`），
第 1 步编译固件 TU 时仍用默认 0 —— 两条路径都会被严格编译一遍；AVR 实编走默认 0。
新增的 `probe_pins_off` 反过来，用 `-DWEARM_BUTTON_PINS=0` 编译（`run_all.ps1`
里对这一个探针单独换成 `$cfg + '-DWEARM_BUTTON_PINS=0'`），它测的就是"按住
D2~D5 也什么都不发生 + 四个功能全走串口"。**注意这四条命令 `N/R/P/M/0` 都不在
固件的单字符快速派发表里**（表里只有 `O`/`S`、`A~C`、`H`/`L`、`F`/`D`/`G`/`E`/`Q`/`U`/`W` 这些单个大写字母），
探针喂命令必须带 `\n`，否则会一直等在行缓冲里（`probe_pins_off` 的 `feed()` 已经
自动补换行，这个坑就是这么踩出来的）。

## 本轮改动 —— 录制深度改造（录得更久、采样更稀、回放插值）

要求是"**增大录制的存储空间，降低采样率**"。改动集中在 `button_control.cpp`／
`button_control.h`／`weArm_config.h`，加上 `probe_button` 的新回归：

| | 改前（v1.4.0） | 改后 |
|---|---|---|
| 采样周期 `WEARM_REC_TICK_MS` | 100 ms | **200 ms** |
| 每条记录 `BTN_REC_BYTES` | 3 字节（四关节各 6 位有符号） | **4 字节（各 8 位有符号）** |
| 缓冲条数 `WEARM_REC_ENTRIES` | 128 | **192** |
| 缓冲 SRAM | 384 B | **768 B** |
| 单次录制上限 | 12.8 s | **38.4 s** |
| 每周期最大增量 | ±16°（= ±80°/s） | **±63.5°（= ±317°/s）** |

**为什么"降采样率"不能只改一个数字**：只把 100 ms 改成 200 ms，6 位字段就顶不住了 ——
正常档（`setSpeed(1.0, 10, 40)` = 100°/s）每周期走 20°，超过 ±16° 的部分被夹紧、靠
`s_snap[]` 顺延成积压；而 `btnStopRecording()` 收尾只补写**一条**记录，积压的尾巴
（实测 20°）被直接截掉 ⇒ 回放终点比录制末态短 10~13.5°（`probe_button` [9]/[11] 的
FAIL 就是这个）。所以本轮**同时**做了两件事：

1. 字段放宽到 8 位（±127 单位 = ±63.5°/条 = ±317°/s @200 ms），正常档/中速档不再削顶；
2. 收尾从"补一条"改成**排空循环**（最多 8 次 `btnRecCollect()/btnRecPut()`，直到没有
   新增量或缓冲写满），积压多少就吐多少。

**回放插值**：200 ms 一格的回放会很顿，于是每条记录在回放时被拆成 `BTN_PLAY_SUBSTEPS`
= 4 个 50 ms 子步线性展开（`btnPlayLoad()` 幂等地装载一条、`btnPlaySub()` 贴第 k 个子步、
`btnPlayTick()` 用 `subMs = BTN_TICK_MS / BTN_PLAY_SUBSTEPS` 做**均匀**时间基准）。
总时长仍严格等于 `s_recLen × 200 ms`（探针 [5] 实测 13.02 s = 11.6 s + 1.5 s）。
设 `BTN_PLAY_SUBSTEPS = 1` 就退回"整条一次跳完"的老行为。

**探针**：`probe_button` 新增 **[12] 缓冲写满**（连续推杆录到 38.2 s 仍在录制、
条目 190/192 证明 `uint16` 计数不回绕；38.8 s 写满后自动收尾并判废、事后按 `P` 回
`EMPTY`）；[9]/[11] 的回放末态差从 6~13.5° 变成 **0.00°**。

### 录制深度改造后的容量（`avr_build.ps1` 实编）

| 配置 | Program | 占 32768 | Data | 占 2048 |
|---|---|---|---|---|
| 取放 + 按键 + 绘图（**默认**） | 31938 | 97.5% | 1414 | 69.0% |
| 取放 + 绘图（按键关） | 28756 | 87.8% | 497 | 24.3% |
| 取放 + 按键（绘图关） | 19170 | 58.5% | 1206 | 58.9% |
| 绘图 + 按键（取放关） | 29180 | 89.1% | 1380 | 67.4% |

比上一轮各 **+286~334 B flash、+420 B SRAM**（缓冲 +384 B、回放子步状态 8 个
`double` 再 +64 B，另有零头被优化掉）；**"取放 + 绘图（按键关）"一行完全不变**，
因为 `button_control.cpp` 根本没参与编译。默认配置相对 32256 B 可用 flash
**只剩 318 B**（下一轮把"移动到指定 x,y,z"合并成 `moveToPoint()` 后同一默认配置降到
**31770 B**、余量 486 B，见下一章）。想再改采样率/条数只动 `weArm_config.h` 第 5 节那两个数即可：
96 条 = 19.2 s（384 B）、256 条 = 51.2 s（1024 B，Data 81.5%、栈只剩 378 B，不建议）。

## 本轮改动 —— 绘图改调公共的「移动到指定 x,y,z」核心

要求是"**调用实现移动到指定 x,y,z 坐标的函数，重构绘图功能**"。做法：让"移动到指定
坐标"在本工程**只有一份实现**，绘图与串口都调它。

### 之前是三份

| 位置 | 函数 | 语义 |
|---|---|---|
| `draw_control.cpp`（已删） | `solveStep()` + `tryApplyPoint()` | 反解后逐轴比较，超速**整点拒绝**（轨迹跟随） |
| `draw_control.cpp`（已删） | `applyPointClamped()` | 反解后超速部分**夹到上限**（示教点动） |
| `serial_protocol.cpp`（已删） | `protoMoveToCoords()` | 反解后**一次到位**，解不出来整条拒绝（串口 x/y/z） |

三份都写着同一段"构造 `pos target = Pos` → 按 `seen` 覆盖坐标 → `getAngleEx()` →
写 `Pos` + `recFromServo()`"，只是"超速怎么办"不同。

### 现在是一份，三种策略

新的公共函数在 `move.h` / `move.cpp`：

```c
int moveToPoint(const double *goal, uint8_t seen, double maxDps, double dtSec, int mode);
```

- `goal[3]` 目标点（**内部坐标系**，与 `Pos.rec` 同一套；调用方是绘图的轨迹跟随与
  `pick_place`。串口 `x/y/z` **不经过这里**：它直接写 `Pos.ser.angle1..3`，
  再由 `recFromServo()` 算出 `Pos.rec`）；
- `seen` 位掩码（`1<<0`/`1<<1`/`1<<2`），**没提及的轴沿用 `Pos.rec` 当前值** ——
  这就是"`x10` 这种单轴命令"能工作的原因；
- `maxDps × dtSec` = 本步允许的最大关节变化（下限 0.2°）；
- `mode` 三选一：`MOVE_XYZ_TRACK` 超速整点拒绝（绘图轨迹跟随）、`MOVE_XYZ_JOG`
  超速夹取（示教点动）、`MOVE_XYZ_NOW` 不限速一次到位（串口）。
- 返回 `MOVE_XYZ_OK` 才写 `Pos`，其余情况 `Pos` **逐字节不变**（探针 [7a]/[7b]/[7g]
  用 `memcmp(&Pos, ...)` 直接守这条不变量）。

### 为什么能保证"逐位相同"

- 反解的输入一样：旧 `pathCoreSolveJoint()` 是 `pos p; p.rec.x/y/z=…; p.ser=Pos.ser`，
  新代码是 `pos target = Pos;` 再覆盖 `rec` 三个轴 —— 传给 `getAngleEx()` 的 `rec` 与
  `ser` 逐位相同。失败/被吸附的判据也照抄（`clamped` 只被 `TRACK`/`JOG` 用来拒绝，
  `NOW` 与旧的 `protoMoveToCoords()` 一样忽略它）。
- 写回去的角度一样：**旧 `tryApplyPoint()` 写的是反解结果 `abc[]`，所以新的 `TRACK`
  分支也必须写反解结果 `tgt[]`**，不能写 `cur + (tgt - cur)`（浮点上不保证逐位相等）。
  `JOG` 分支反而要用 `cur + 夹取后的增量`，与旧 `applyPointClamped()` 一致。
- `s_applyMs = millis()` 仍然只在**成功之后**才前移，调用方一行没改。
- 串口侧唯一丢掉的东西：旧 `protoMoveToCoords()` 在 `recFromServo()` 失败时打的一句
  debug 警告（那条路径本来就不可达，且只在 `WEARM_DEBUG_SERIAL=1` 时存在）。

### 探针

`probe_move` 新增 **[7] `moveToPoint()`** 共 7 条：不可达/`NULL`/未知模式 → `REJECTED`
且 `Pos` 逐字节不变；`TRACK` 超速拒绝、限内接受且**写进去的角度与独立反解结果逐位相同**
（实测需动 16.335°、上限 32.670°）；`JOG` 每步 0.200°（= 10°/s × 0.02 s）不超上限、
48 步收敛到反解结果；`NOW` 一次跳变 4.57° 到位且坐标自洽；部分 `seen` 只动被提及的轴
（y/z 偏差 0 与 3.6e-15）。其余 10 个探针（尤其 `probe_draw` 的轨迹精度/示教点动/
`probe_protocol` 的 x/y/z 拒绝语义）**一个数字都没变**，这就是"等价重构"的证据。

### 容量：反而省了 flash

| 配置 | Program | 占 32768 | Data | 占 2048 |
|---|---|---|---|---|
| 取放 + 按键 + 绘图（**默认**） | **31770** | 97.0% | 1414 | 69.0% |
| 取放 + 绘图（按键关） | **28586** | 87.2% | 497 | 24.3% |
| 取放 + 按键（绘图关） | 19198 | 58.6% | 1206 | 58.9% |
| 绘图 + 按键（取放关） | **28956** | 88.4% | 1380 | 67.4% |

相对上一轮（31938 / 28756 / 19170 / 29180）：默认 **−168 B**、按键关 **−170 B**、
取放关 **−224 B**（这行是"绘图 + 按键"配置），**Data 四行全部不变**（`moveToPoint()`
只用栈）。唯一变大的是"取放 + 按键（绘图关）"**+28 B** —— 那个配置里绘图模块本来就
没编译进去，没有重复代码可省，而 `moveToPoint()` 无论如何都要编译一份。默认配置相
对 32256 B 可用 flash 的余量从 318 B 变成 **486 B**。

### 顺带修订 `meArm.ino`（改名前的 `wearm.ino`）的头部注释

重构后 .ino 顶上那段大注释有几处已经说反了，一并改掉：`setup()`/`loop()` 的结构清单
补上绘图模块与 `moveToPoint()`；"【控制方式：直接控制关节角】……不再通过末端坐标反解"
改成"关节角是唯一被控量，坐标输入只有串口 x/y/z 与绘图两个入口，都走 `moveToPoint()`"；
x/y/z 指令那几条改成"反解出 b/r/c 三个关节角、夹爪 f 不变、解不出来整条拒绝"；
安全边界里补上"坐标入口靠 `getAngleEx()` 反解，被限位吸附的点绘图一律拒绝、
串口 NOW 策略允许吸附后到位"。另外 `.ino` 里没有任何 `move.h` 的符号，
把那个用不到的 `#include "move.h"` 换成显式的 `#include "constant_and_positions.h"`
（`Pos` / `servoLimit` 本来就是他间接带进来的，现在写明）。改完 AVR 实编仍是
**31770 B / 1414 B**，11 个探针依旧 ALL PASS。

## 工作区改名为 meArm（主 sketch 跟着改名 wearm.ino → meArm.ino）

工作区目录 `D:\dsh1\wearm` 改成了 **`D:\dsh1\meArm`**。Arduino IDE 与 `arduino-cli`
都要求**主 `.ino` 的文件名与所在目录同名**，否则那个目录不再被当成一个 sketch，
所以主程序文件同步改名：

| 项目 | 之前 | 现在 |
|---|---|---|
| 工作区目录 | `D:\dsh1\wearm` | `D:\dsh1\meArm` |
| 主 sketch | `wearm.ino` | `meArm.ino` |
| 自检探针文件名 | `wearm_ino_test.cpp` | **不变**（它测的是"主 sketch 本体"，名字里的 wearm 是历史） |

- **内容零改动**：改名前后的 `.ino` 逐字节相同（`git rev-parse HEAD:wearm.ino`
  与 `git hash-object meArm.ino` 都是 `1608d1ff1c3c22b6e69821c686c3c5c1d1bb8d06`，
  16732 字节）。只改了文件里的第 2 行注释 `// wearm.ino` → `// meArm.ino`。
- **改名踩到的锁**：`Move-Item` 先报"另一个进程正在使用此文件"，子目录能改、根目录不能
  → 锁在根目录，持有者是开着的 **Arduino IDE**（`Get-CimInstance Win32_Process` 能看到
  命令行里就是那个 `.ino`）。关掉 IDE 后立刻改名成功。
- **跟着改的引用**（不改就会指向不存在的路径）：`.selfcheck\avr_build.ps1` 的默认
  `$SketchDir` / `$BuildRoot`（脚本本身按 `*.ino` 通配找文件，与文件名无关，只是默认路径
  写死了旧目录）、`.selfcheck\run_all.ps1` 头部用法注释、`.selfcheck\wearm_ino_test.cpp`
  的 `#include "../meArm.ino"` 与横幅文字、`weArm_config.h` 顶部调用方清单、
  `servo_drive.h` 的脉宽映射说明、本文件里的路径与文件名。
- **验证**：`.selfcheck\run_all.cmd` → 9 个固件 TU 零警告 + **11 个探针 ALL PASS**；
  `.selfcheck\avr_build.ps1` 默认配置实编 **31770 B / 1414 B**（与改名前一模一样 ——
  改的都是注释与路径，没有一行逻辑）。
- **顺带踩中的老坑**：用编辑工具改 `.selfcheck\run_all.ps1` / `avr_build.ps1` 会把
  **UTF-8 BOM 丢掉**（见下面第 2 条），PowerShell 5.1 立刻按 ANSI 解码中文注释并整篇
  语法报错。改完跑一次 `& .\.selfcheck\ensure_bom.ps1`（`-Check` 只检查）：含中文的
  `.ps1`（`run_all.ps1`/`avr_build.ps1`）必须带 BOM，纯 ASCII 的
  （`gh_release.ps1`/`progress.ps1`/`make_single.ps1`/`ensure_bom.ps1`）不需要 ——
  检查脚本对前者报 `has BOM`、对后者报 `ASCII-only, BOM not required`。

## 分支 draw_control —— 绘图功能裁剪与减速

新分支 `draw_control`（从 `436d3eb` 切出），只做两件事：**把绘图功能收敛到用户点名的 5 项**、
**把绘制运动放慢并做精细化插值**。行为改动都在 `draw_control.cpp` / `draw_control.h` 里，
其它模块只动了注释。

### 1) 任务表：7 项 → 4 项

> **⚠ 本节已作废**（v1.6.4 起）：题目要求"内置图形至少 4 个、同组不得完全相同"，
> N / 三角形 / Z 已全部恢复，任务表回到 7 项（`LINE 0 / N 1 / TRIANGLE 2 / Z 3 /
> V 4 / POLYLINE 5 / CURVE 6`），并新增 `drawTaskTag()` 与 `OK F=<tag>` 回执。
> 下表只作为历史记录。

| 任务号 | 分支前 | 分支后 |
| --- | --- | --- |
| 0 | 直线 | **直线（默认任务）** |
| 1 | 字母N | **字母V** |
| 2 | 三角形 | 五点折线 |
| 3 | 字母Z | 五点曲线 |
| 4 | 字母V | — |
| 5 | 五点折线 | — |
| 6 | 五点曲线 | — |

- 删除的**字母N / 三角形 / 字母Z**：连三张 `PROGMEM` 顶点表（`SHAPE_N` / `SHAPE_TRIANGLE` /
  `SHAPE_Z`）、`DRAW_TASK_NAME` 里的名字、`shapeTable()` 的 case、探针 `probe_draw.cpp`
  里对应的几何用例与期望顶点表一起删掉（留着会触发 `-Wall` 的未使用告警）。
- 保留的 5 项能力与用户点名的一致：**直线绘制、字母V绘制、绘图过程控制（暂停/继续/取消）、
  五点示教折线、五点示教平滑曲线**，外加既有的纸面标定（`p`/`n`/`o`）。
- 编号顺次前移，`F` 循环顺序变成 `直线 -> 字母V -> 五点折线 -> 五点曲线 -> 直线`；
  默认任务从三角形改成**直线**（`drawSetup()` 与 `s_task` 初值）。
- 跟着改的注释：`meArm.ino`（F 命令说明）、`protocol_constants.h:62`（`F` 的含义）、
  `serial_protocol.h:103`（返回值 18 的含义）、`draw_control.h` 头部与函数注释。

### 2) 放慢 + 精细化插值

| 参数 | 分支前 | 分支后 | 作用 |
| --- | --- | --- | --- |
| `DRAW_V_MAX` | 8.0 | **3.0** | 笔尖巡航线速度（单位/秒） |
| `DRAW_ACCEL` | 12.0 | **6.0** | 加减速度（单位/秒²） |
| `DRAW_MAX_DPS` | 110.0 | **70.0** | 关节角速度硬上限（度/秒） |
| `DRAW_PATH_SAMPLE_STEP` | 0.5 | **0.25** | 轨迹校验采样步长（更细） |
| `DRAW_STEP_MAX` | — | **0.02** | 单次写入的最大位移（新宏） |

`pathTick()` 在把"这一轮该走的距离"送进 `pathAdvance()` 之前加了一道上限：

```c
if (step > DRAW_STEP_MAX) step = DRAW_STEP_MAX;
(void) pathAdvance(step);
```

- **正常 loop 周期（1~5 ms）、巡航 3 单位/秒** 下算出来的 `step` 只有 0.003~0.015 单位，
  这个上限**根本不生效**，速度完全按梯形规划走（probe_draw 实测相邻两步最大 0.015 单位，
  旧版是 0.040）。
- 只有某一轮 loop 被拖长（串口打印、别的模块占时间）时才限住：那一轮少走一点，
  剩下的下一轮补上 —— 宁可慢，也不让舵机一次跳一大步。*0.02 / 5 ms = 4 单位/秒 >
  `DRAW_V_MAX`，所以巡航速度不受影响。*
- 结果：一条 12 单位的直线由 **几百个密排点**组成，舵机每步只动零点几度。

> **为什么不是"一轮里拆成多个小步循环送出"**：本工程用 `-flto -Os`，
> 把 `pathAdvance()` 放进循环里会让它无法被内联，实测**同样功能要多花 662 B flash**
> （默认配置 32336 B 已经超过 Uno 可用的 32256 B，装不进去）。
> 限一步的写法只多 32 B，效果一样：**任何一次写入的位移都不超过 0.02 单位**。
> 这一步是拿真实 AVR 构建量出来的（`.selfcheck\avr_build.ps1`），不是猜的：
> 无循环但无上限 31674 B → 加循环 32336 B（+662）→ 改成上限 31706 B（+32）。
> （后来"示教点动修复"又把这个数字降到 31656 B，见 §5。）

### 3) 探针与实测（probe_draw 8 段，全部 PASS）

- [1] 默认任务 = 直线；`DRAW_TASK_COUNT == 4`；4 个任务名齐全；
  循环顺序 `直线→字母V→五点折线→五点曲线→直线`；非法任务回 -1；标定越界被拒。
- [2] 直线全流程：阶段顺序不变，`z` 恒 12.0000、`x` 14.00→26.00、`y` = 0、
  **相邻步最大 0.015**、离理想直线最远 0.0000、**用时 4485 ms**（旧版 2150 ms）——
  慢了一半多，正是这次减速的直接证据。
- [3] 只剩字母V：顶点最差 0.001、离线最远 0.000。
- [6] 五点折线：5 个示教点最近距离最大 0.005、采样点离线 0.000、过点 5/5、相邻步最大 0.015。
  同一段开头还加了 7 条**示教点动逐轴断言**：A0/A1/A3 单轴满偏只让对应坐标变化
  （串扰 <0.02 单位）、每格位移 ≤0.26 单位、轻推步长小于满偏的一半、A2 整路不响应。
- [7] 五点曲线：过点 5/5、离线最远 0.689（仍是曲线）、相邻采样最大间距 0.015、
  **每 5 ms 最大转角 0.38°**（旧版 1.01°）、用时 9155 ms（旧版 3900 ms）。
- [4]/[5]/[8]（暂停继续/取消/串口）行为不变，数值判据原样通过。

### 4) 这一节的注意事项

- 减速只改了"画的时候走多快"，**没有改几何、没有改校验门限**（采样步长反而更细），
  所以"顶点经过、离线距离、过点数"这些精度指标是变好而不是变松。
- 放慢的代价是耗时：默认直线 2.15 s → 4.49 s，五点曲线 3.9 s → 9.16 s。
  若要更快，只改 `DRAW_V_MAX` / `DRAW_ACCEL`（一次一处），
  但别把 `DRAW_STEP_MAX` 调大 —— 它就是"任何一次写入的位移上限"，
  调大等于放宽单次跳步，"精细化插值"这条要求就落空了。
- 上机确认项：慢速下舵机是否有明显抖动/异响（尤其加减速段与顶点处）；
  抬笔/落笔的 4 单位垂直行程现在也慢了，视觉上应更稳。

### 5) 实编容量（`.selfcheck\avr_build.ps1`，AVR 真实构建）

| 配置 | Program | 占比 | Data | 占比 | 相比分支前 |
| --- | --- | --- | --- | --- | --- |
| 取放 + 按键 + 绘图（**默认**） | **31656** | 96.6% | 1415 | 69.1% | −114 |
| 取放 + 绘图（按键关） | **28478** | 86.9% | 498 | 24.3% | −108 |
| 取放 + 按键（绘图关） | 19198 | 58.6% | 1206 | 58.9% | 0 |
| 绘图 + 按键（取放关） | **28818** | 87.9% | 1381 | 67.4% | −138 |

- 默认配置相对 Uno 可用 flash（32256 B）还剩 **600 B** 余量（分支前是 486 B）。
- **拆开看这次怎么变的**：删三个内置图形 + 减速 + 采样步长 0.5→0.25 一共省 96 B
  （实测无循环写法 31674 B），新增的"单次位移 ≤0.02 单位"上限花掉 32 B，得到 31706 B；
  后面的**示教点动修复**（把"角度步长当位移"的旧逻辑换成按偏转缩放的坐标步长 +
  A2 走编译期开关）又让默认配置省了 50 B（`31656`），Data 四行不变。
  "绘图关"那一行完全不变 —— 那个配置里绘图模块根本没参与编译。
- 为什么位移上限不做成"一轮拆多个小步"：那样 `pathAdvance()` 无法被内联，
  实测多花 **662 B**（32336 B > Uno 可用的 32256 B，装不进去），详见上面 §2 的引用块。


## 修复：五点示教时摇杆控制错乱（示教点动的步长单位与方向）

**现场反馈**：五点示教状态下摇杆控制错乱 —— 推杆以后笔尖不是"一点一点挪"，而是
一推就窜、推得越狠窜得越快，斜着推还会把夹爪带开、把夹着的笔顶歪。

**先排除的三件事**（都不是原因，别再往这儿查）：
- **不是"两个控制器抢同一个关节"**：示教期间摇杆模块整段让位 ——
  `joystick_control.cpp:385` 的 `locked = pickPlaceIsBusy() | buttonControlLocked() | drawControlLocked()`，
  而 `drawControlLocked()` 在 TEACH 阶段为真，`if (!locked)` 把整个步进循环包住了。
- **不是轴向映射串了**：`teachJogTick()` 的 `amp[4]={st.base,st.shoulder,st.elbow,st.tool}` 与
  `raw[4]={st.sx,st.sy,st.ty,st.tx}` 和 `joyState` 的字段顺序（`joystick_control.h:85-94`）逐项对齐，
  A0→x、A1→y、A3→z、A2→f 没有错位。
- **不是反解/限位**：`moveToPoint()` 的 JOG 分支对超速部分夹取，不拒绝，不会卡死。

**真正的三个毛病**（都在 `draw_control.cpp` 的 `teachJogTick()` / `jogIntervalMs()` 里）：

1. **把"关节角度步长"当成了"工作区位移"**。旧代码
   `double step = speed.stepSize * DRAW_JOG_SCALE;` —— `speed.stepSize` 在手动模式里的含义是
   **每个控制周期转过的角度（度）**（`joystick_control.h:64`），默认 1.0；乘 0.5 之后
   在示教里却当**工作区单位**用，于是每格就是 0.5 单位（纸面半宽才 6，等于一格跳 1/12 个纸面）。
2. **步进间隔的方向写反了**。旧 `jogIntervalMs()`：`ms = slow - span*amp/512` ——
   满偏用**最短**间隔（10 ms），轻推用最长（40 ms）。这与同工程
   `joystick_control.cpp:272` 的 `speedIntervalMs()`（满偏用**最长**间隔，"慢而稳、最安全"）
   以及它自己的注释"偏转越大步越慢"**正好相反**。两条叠起来：轻推 0.5/0.04 = **12.5 单位/秒**，
   满偏 0.5/0.01 = **50 单位/秒** —— 而自动绘制才 `DRAW_V_MAX 3` 单位/秒。
3. **示教期间夹爪轴还活着**。A2 与 A3 是同一根右摇杆的两路，想压 Z 时手一歪就同时开合夹爪；
   夹爪里夹着笔（或笔夹），一动就把笔顶歪甚至掉笔，而"点动对点"根本不需要它。

**改法**：

| 项 | 旧 | 新 |
| --- | --- | --- |
| x/y/z 每格位移 | `speed.stepSize × 0.5` = 0.5 单位（还跟调速档位走） | `DRAW_JOG_STEP_MAX 0.25 × 偏转/512`，下限 `DRAW_JOG_STEP_MIN 0.02` 单位 |
| 步进间隔 | 满偏 10 ms、轻推 40 ms（推得越狠越快） | 轻推 `minDelayMs`、满偏 `fullDelayMs`（与手动模式同向） |
| 满偏笔尖速度（默认档） | ≈50 单位/秒 | ≈6 单位/秒 |
| 轻推笔尖速度 | ≈12.5 单位/秒 | ≈1.6 单位/秒 |
| 末端 A2 | 跟手开合 | `DRAW_JOG_TOOL_ENABLE 0`：示教期整路不响应 |

- 满偏 0.25 单位/格 ÷ 40 ms ≈ 6 单位/秒，是自动绘制速度的两倍 —— 手动对点够灵敏，
  又不会"一推就飞"；轻推落到 0.02 单位/格（≈1.8 单位/秒）方便对准。
- 抓取/拒绝策略没动：仍是 `DRAW_JOG_MAX_DPS 200` + `moveToPoint(MOVE_XYZ_JOG)` 的夹取版，
  每格 0.25 单位远小于夹取上限，正常操作下不会触发夹取。
- 想要旧行为：把 `DRAW_JOG_TOOL_ENABLE` 改成 1；某一路方向反了就改 `DRAW_JOG_INVERT_X/Y/Z`。

**探针新增 7 条断言**（`probe_draw.cpp` 的 [6] 段开头，专治这四件事）：
单轴满偏只让对应坐标动（|串扰| < 0.02 单位）、每格位移 ≤0.26 单位、轻推步长小于满偏的一半、
A2 整路不响应（笔尖与 `angle4` 都不变）。**实测（probe_draw [6] 段，全部 PASS）**：

```
示教点动 A0：只让 x 增大（方向对、无串扰） PASS  dx=+0.182 dy=+0.000 dz=-0.000
示教点动 A1：只让 y 增大（方向对、无串扰） PASS  dx=+0.000 dy=+0.182 dz=+0.000
示教点动 A3：只让 z 减小（前推=下压）      PASS  dx=+0.000 dy=+0.000 dz=-0.182
示教点动：轻推走小步（比满偏小很多）       PASS  轻推 dx=+0.020（满偏 0.182）
示教点动 A2（夹爪）：默认整路不响应        PASS  笔尖 (20.20,0.18,19.82) angle4=105.000 不动
```

满偏一格 0.182 单位、轻推 0.020 单位（旧版推到底 0.5 单位、轻推也是 0.5 单位），
串扰 `dy`/`dz` 实测 0.000 单位。探针在 [6] 段用的是 `setSpeed(0.5, 20, 60)`：
推到底（A0=900，对中心 512 的偏转是 388/512）间隔 `20+40×388/512 = 50 ms`
⇒ 笔尖约 **3.6 单位/秒**；出厂默认调速档（`stepSize 1.0 / 10 ms / 40 ms`）同一偏转
间隔 33 ms ⇒ 约 **5.6 单位/秒** —— 和自动绘制 `DRAW_V_MAX 3` 同一量级，
而旧版是 **12.5 ~ 50 单位/秒**（而且推得越狠越快）。真正推到底（A0=1023）时
每格 0.25 单位，就是宏 `DRAW_JOG_STEP_MAX` 的上限。

**体积**：这次修复让默认配置从 `31706 B` 降到 **`31656 B`**（Uno 余量 550 → 600 B，
见 §5 的容量表）—— 代码更短是因为旧写法要同时算"角度步长"和"坐标步长"两套，
新写法只有一套按偏转缩放的坐标步长，优化器清掉了多余的分支。


## PowerShell / 脚本的几个坑

1. **`& $gpp ... 2>&1` 赋给变量后 `$LASTEXITCODE` 仍是 0** —— g++ 的 warning 走
   stderr，只看退出码会漏掉警告（历史上就这样漏过两个 `-Wunused-*`）。
   判定失败要**同时看"输出行数 > 0"**。`run_all.ps1` 已经这么做了。
2. **`.ps1` 必须存成 UTF-8 带 BOM**。Windows PowerShell 5.1 读无 BOM 的 `.ps1`
   会按 ANSI(GBK) 解码：中文注释变乱码只是表面现象，真正的坑是**一个汉字吃掉
   后面的一个 ASCII 字节**——于是某个字符串的收尾引号被吞掉，报错却指在完全
   无关的行上（实测报 `run_all.ps1:46` 的 `"$_" }` 是"意外的标记"，而问题
   在第 36 行的中文行；还会把两行粘成一行，报的行号根本对不上）。
   本仓库的 `.ps1` 都带 BOM，**改完一定要确认 BOM 还在**（很多工具覆盖写入
   会丢掉它）。`.selfcheck\ensure_bom.ps1` 就是干这个的：
   `& .\.selfcheck\ensure_bom.ps1` 补齐 BOM，`-Check` 只检查不改。
3. **本机是 Windows PowerShell 5.1，没有 `pwsh` 7**。脚本里别用 7 才有的语法，
   命令行也不要写 `pwsh -Command ...`（会报"无法将 pwsh 项识别为..."）。
4. **执行策略**：直接 `& .\.selfcheck\avr_build.ps1` 可能报
   `AuthorizationManager 检查失败...UnauthorizedAccess`。
   在每个新 shell 里先跑
   `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force`。

## 已知的"上机才能确认"项

代码层面无法验证、需要接上真机试的：

1. **哪根摇杆轴接在 A0/A1 与 A2/A3**：若左右手反了，把
   `joystick_control.cpp` 里 `JOY_L*` / `JOY_R*` 两组引脚对调。
2. **末端开合方向**：现按旧手柄版约定「A2 **右推 = 收回**、左推 = 张开」
   （`joystick_control.cpp` 里 `(raw > JOY_CENTER) ? -1 : 1`）。
   若手感相反，把那个三元式对调即可。
3. **`c` 接近 180° 的机械干涉**：`servoLimit.maxC` 已放开到 180（理论行程），
   但下臂在接近 180° 时会往后折回，代码注释已警告这是"理论行程上限、
   不保证不撞"。**请先在慢速档、空载、抬离台面的情况下单步试。**
4. **`limit` 现在是软护栏**：基座可摆到 x<0 后方、末端最低到 z≈-20.0，
   同样建议先慢速空载试。

5. **`r` 走到 0° / 180° 的机械干涉**：`servoLimit` 已把上臂 r 放开到 0~180
   （r=0 上臂水平朝前、r=180 上臂水平朝后）。与 c 组合后末端最低可到肩关节
   以下约 20，可能撞台面或底座。**请先在慢速档、空载、抬离台面的情况下
   单步试**，确认行程两端不会撞到东西再放开跑。

6. **A/B/C 三个物体的实际摆放位置**：`pick_place.cpp` 顶部的 `PICK_SRC` 与
   `PICK_DST` 只是"设计值"，真机上是把物体摆在哪儿就改哪一行（单位与坐标
   模型一致，`x/y` 是水平面、`z` 是高度）。第一次跑取放序列请务必：
   先进慢速档（串口发 `L` 或 `1`），**卸掉夹爪里的物体**，用 `A` 试跑一遍，
   观察夹爪是否真的夹到物体中段高度（`PICK_GRASP_Z` / `PICK_APPROACH_DZ`
   也在同一个文件顶部）。序列速度 = 当前档位（慢 25 / 中 50 / 快 90 度每秒），
   夹爪段固定 60 度每秒。

7. **物理按键默认不接、也默认不读**（本轮变更）：固件从本轮起默认
   `WEARM_BUTTON_PINS = 0`（`weArm_config.h` 第 4 节），**完全不读 D2~D5**
   （连 `pinMode` 都不做），四个按键的功能全部改由串口字符触发：
   `N` 循环执行 / `R` 录制开关 / `P` 播放 / `M`（或 `0`）回中。
   起因：本机 D2~D5 上没有独立按键，只把摇杆自带的 SW 脚接到了 D2（= 按键1
   循环取放），而**右摇杆推到最前时机械上会压合那颗轻触开关**，于是手动推杆
   推到极限就假触发一次取放、摇杆随即被 `locked` 锁住（现象：右摇杆向前本该
   转下臂，结果触发了自动取放）。要恢复物理按键接线：把 `WEARM_BUTTON_PINS`
   改成 1 即可（D2~D5、一端接按键、另一端接 GND、按下为低电平；固件用
   `INPUT_PULLUP`，接反或悬空会一直读到"按下"）。改回 1 后上机逐个试：
   按一下 D2 是否开始夹 A、再按是否换 B；D3 是否进入「录制中」、再按是否
   报保存成功或"太短/没有位移"；D4 是否复现；D5 是否回到 `POS_HOME` 姿态。
   注意**回放按录制时的时间轴走**，与当前调速档位无关，所以第一次录制建议
   用慢速档录一小段、观察回放是否与手动操作一致。
   （PC 探针 `probe_button` / `probe_draw` 靠模拟 D2~D5 电平测按键逻辑，
   `run_all.ps1` 给**探针**额外加了 `-DWEARM_BUTTON_PINS=1`，固件 TU 仍按默认
   0 编译，两条路径都会被严格编译一遍。）

8. **纸面高度 `z` 与铅笔的固定**：`draw_control.cpp` 的 `DRAW_PEN_Z_DEFAULT 12.0`
   只是"和取放台面同高"的估计值。上机第一步必须是**标定**：用手动方式把笔尖
   移到纸面、读串口角度或用 `x/y/z` 指令把笔尖压到纸上，然后用
   `p<数值>` 把这个高度告诉固件（`drawGetPaperZ()` 会打印）。铅笔要夹紧、
   笔尖比夹爪低出来的长度一旦变了就要重标，否则要么画不上、要么把纸戳破。
   抬笔高度 `DRAW_LIFT_DZ 4.0` 若发现抬起来还是蹭到纸，把它调大。
9. **五点示教时 A0/A1/A3 的轴向与手感**：示教点动用的是笛卡尔点动
   （A0→x、A1→y、**A3 前推→z 下降**）。若发现推杆方向与预期相反，
   改 `draw_control.cpp` 顶部的 `DRAW_JOG_INVERT_X/Y/Z`（0/1 翻转），
   **不要动摇杆模块本身** —— 那里的方向约定是给手动关节控制用的。
   手感按"每格 ≤0.25 单位、轻推 0.02 单位"调：嫌太慢就加大 `DRAW_JOG_STEP_MAX`
   （但它同时是"一格最多跳多远"的上限，别再加回 0.5），嫌太快就调小或把
   `DRAW_JOG_STEP_MIN` 调小。**示教时不响应 A2（夹爪）**：要让右摇杆左右推也能开合夹爪，
   把 `DRAW_JOG_TOOL_ENABLE` 改成 1（默认 0，因为夹爪里夹着笔）。
10. **示教点的有效范围**：`DRAW_POINT_TOL 0.8`（评分要求"进入有效范围即算过点"）
    要与卷面给的有效范围核对；评分还看线段直线度、连续性、平稳性与用时，
    所以上机试画时应记录 `drawLastRunMs()` 与 `drawLastPointsHit()`。
11. **绘图与取放/录制的互斥**：绘图期间摇杆整段让位（示教例外，由绘图模块自己读），
    所以若发现"示教时推杆没反应"，先确认按键/串口是不是处于录制或播放状态。
12. **裸 UART 后端（本轮新增，风险最高的一项）**：release 构建不再用
    Arduino `Serial`，直接操作 `UDR0`/`UCSR0A`/`UBRR0`，接收走 `USART_RX_vect`
    中断。上机第一步就要确认串口助手 115200-8N1 下能收发：发 `!` 应回
    `P=1 B=1 D=1`，发 `O`/`S` 应回 `OK #`。若**完全没反应或全是乱码**，
    依次排查：(a) 串口助手波特率/换行符；(b) 烧录是否真的成功；
    (c) 用 `-DWEARM_SERIAL_ARDUINO=1` 重新编译烧录，退回官方串口库对照 ——
    如果退回后就正常，说明是这段裸寄存器代码的问题，把现象贴回来。
    另外长连发时环形缓冲只有 64 字节、行缓冲只有 40 字节，超了会丢字节。
13. ~~**地面坐标系的 `z` 与肩高**~~（**已作废**：串口 `x/y/z` 自 v1.6.4 起直接写
     三个舵机的角度，不再有地面坐标系与肩高常量，本节随
     `WEARM_SHOULDER_HEIGHT` 一起删除；坐标版备份见分支 `backup/xyz-cartesian`）。
14. **`R` / `P` 的新回复语义**：第一次 `R` 回 `OK` 表示开始录制（最长 38.4 s），
    第二次 `R` 若回 `DISCARD` 表示"没有位移/溢出，这段丢弃了"——不是故障。
    `P` 回 `EMPTY` 同理表示没有可回放的数据。真机上先录一段有位姿变化的动作
    （现在多短都行，只要末端走出 10 个坐标单位）再验证 `OK`。
15. **方向镜像对不对**（本轮新增）：基座与夹爪按"反向装配"处理了
    （`WEARM_MIRROR_BASE` / `WEARM_MIRROR_TOOL`，见上一节）。上机验证三件事：
    (a) 发 `O` 爪子**张开**、发 `S` **夹紧**（这一条错了就把 `WEARM_MIRROR_TOOL` 改 0）；
    (b) 左手柄左右推 / 串口给带 `x` 或 `y` 的坐标时，基座转的方向与机械现实一致
    （错了就把 `WEARM_MIRROR_BASE` 改 0）；
    (c) **A/B/C 取放是否去对了方向** —— 基座镜像会让 `PICK_SRC`/`PICK_DST` 里的 `±y`
    落到镜像侧，若发现取放跑反了，把 `pick_place.cpp` 顶部这些点的 `y` 取反
    （它们本就是"按现场摆放标定"的设计值）。
16. **摇杆中位自标定**（本轮新增）：`joystickSetup()` 里取了 8 次平均，所以
    **上电/复位时不要碰摇杆**（碰了且偏差 >64 会退回 512 老行为，属于保守兜底，
    不是故障）。上机验证：手完全松开，观察 30 秒机械臂是否**完全不动**
    （旧版偏 20 以上就会持续爬）；再分别推四路轴确认方向与手感没变。
    若某路仍然自己走，说明那路的静态偏差超过 64 或噪声峰峰 > 死区，
    把 `joystick_control.cpp` 的 `JOY_CAL_MAX_OFF` / `JOY_DEADZONE` 调大后再试。
17. **录制中直接按 `P` / 按键3**（本轮新增）：应当在**同一次**操作里"结束录制并开始
    播放"（回 `OK`）。若回 `DISCARD`，说明这段录制太短 / 没位移 / 超过 38.4 s
    溢出——按提示重录即可。
18. **录制深度改造后要上机确认的三件事**（本轮新增）：
    (a) **回放是否顺畅** —— 采样降到 200 ms 后靠 4 个 50 ms 子步插值展开，
    肉眼看应当与旧版（100 ms 采样）差不多；若明显一格格跳，把 `weArm_config.h`
    第 5 节的 `WEARM_REC_TICK_MS` 调回 100 或把 `BTN_PLAY_SUBSTEPS` 调大（改完
    复测容量；默认配置当前还剩 486 B flash，见
    `## 本轮改动 —— 绘图改调公共的「移动到指定 x,y,z」核心` 一节的容量表）；
    (b) **长时间录制** —— 连续录 30 秒以上，看是否在 38.4 s 附近自动收尾并回
    `DISCARD`（写满判废，不留半段数据）；若需要更长就按第 5 节的账加条数
    （256 条 = 51.2 s，Data 81.5%，栈只剩约 378 B，风险自负）；
    (c) **SRAM 余量** —— Data 段已到 1414 B（69.0%），若出现莫名的随机复位/串口
    乱码（栈溢出典型症状），先把 `WEARM_REC_ENTRIES` 降回 96~128 再看是不是它。

## 单文件整合 —— `.selfcheck/make_single.ps1` 与 `single/meArm/meArm.ino`

需求是"把全部代码放进一个 .ino"。`.selfcheck/make_single.ps1` 把 11 个头文件
（先声明）、9 个实现文件（后定义）、最后根目录 `meArm.ino` 依次拼接，生成自包含的
`single/meArm/meArm.ino`（332015 B / 7310 行，带
`// Generated by .selfcheck/make_single.ps1. Do not edit this file directly.` 头）。

**模块化版本仍是唯一手写源，单文件是生成物，不要直接编辑**——改完源码重跑：

    powershell -NoProfile -ExecutionPolicy Bypass -File .selfcheck\make_single.ps1

拼接规则：

- 只在本文件内去掉 `#include "..."` 与 `#include <Arduino.h>`；每个系统头
  （`math.h`/`string.h`/`avr/io.h` …）只在**首次**出现处保留，文件开头统一补一次
  `#include <Arduino.h>`
- 每段前加 `// ===== <文件名> =====` 分隔注释，便于与模块化版逐段对照
- 顺序固定：头文件族 → 实现 → sketch。`avr_build.ps1` **不生成** Arduino 函数原型
  （ar2cpp 那一步的自动原型插入我们没有用），所以必须"先声明后使用"

**唯一的真冲突及处理**：`static double clampDouble(double,double,double)` 在
`constant_and_positions.cpp:192` 附近（带 `__attribute__((noinline))`）与
`draw_control.cpp:243` 附近各有一份。分 TU 编译合法，合进同一个 TU 就是 redefinition，
所以生成器把 `draw_control.cpp` 里的这份**逐行重命名为 `drawClampDouble`**
（脚本里的 `-replace '\bclampDouble\b'` 规则）。另一对同名函数 `beginMove`
（`pick_place.cpp` 与 `draw_control.cpp`）**不用改**：两边签名不同
（`(int,const double*,int)` 与 `(int,double,double,double)`），本身就是合法重载。
根目录 `*.cpp/*.h` 里 238 个 `static` 名字逐个查过，只有这两处重名。

**同一个 TU 里的宏重定义（独立复核发现，已修）**：`BTN_DEBOUNCE_MS` 原本在
`joystick_control.cpp:74`（30 ms）与 `button_control.cpp:84`（25UL）各定义一次。
分 TU 编译互不相干，合并成一个 TU 后严格编译会报
`warning: 'BTN_DEBOUNCE_MS' redefined`（`avr_build.ps1` 带 `-w` 不显示，
Arduino IDE 用户会看到）。两处的使用点都在各自定义之后，当前语义没受影响，
但这正是"合并才暴露出来的隐藏坑"，所以把摇杆模块那份改名为
`JOY_BTN_DEBOUNCE_MS`（定义 + 2 处注释 + `buttonDown()` 里的使用，共 4 处）。
现在单文件在 `-std=gnu++17 -Wall -Wextra -Wshadow -Wconversion` 下同样零警告。

**实测（16 MHz Uno / avr-gcc 7.3.0 + core 1.8.8）**：

| 构建 | Program | Data |
|---|---|---|
| 模块化（`-SketchDir D:\dsh1\meArm`） | 31656 B | 1415 B |
| 单文件（`-SketchDir D:\dsh1\meArm\single\meArm`） | 31676 B | 1415 B |

差 +20 B（同一份源码，LTO 链接顺序不同），两边都零警告。生成器**幂等**：重跑到临时
目录得到的文件与 `single/meArm/meArm.ino` 的 SHA256 相同（`EA1C32C1…`，332015 B）。
它逐字节复制源文件，所以**只看 HEAD 就能复现**——生成并提交产物前先确认
`git status` 干净：工作区里任何未提交改动都会被原样抄进单文件，产物就与 HEAD 对不上了。

换行符也是这条"可复现"的一部分：脚本**固定写 LF**（`[string]::Join("`n", …)` +
`WriteAllText`）。`.gitattributes` 已声明 `* text=auto eol=lf`，而 `WriteAllLines` 在
Windows 上写的是 CRLF，于是工作区文件（339304 B）与入库 blob（332015 B）字节不同、
每次 `git add` 都冒一条 CRLF→LF 警告。改成 LF 之后工作区文件 = 检出文件 = blob，
三者逐字节相同。
自包含性（只留 `meArm.ino` 也能编）、函数完整性、`#if WEARM_ENABLE_*` 门控一致性与
模块化回归由独立复核流程复跑确认，记录见 `.selfcheck/out/single_ino_verify.md`
（该目录不入库）。单文件版的上机确认项与模块化版完全相同，见上一节。

### 附：`.selfcheck/gh_release.ps1` —— 版本说明发布

每个 tag 都有一份中文说明（正文存在 `.selfcheck/out/rel_<tag>.md`，不入库）并发布成
GitHub Release：

    powershell -NoProfile -ExecutionPolicy Bypass -File .selfcheck\gh_release.ps1 -Tag v1.6.2 `
        -BodyFile .selfcheck\out\rel_v1.6.2.md [-Force] [-MakeLatest] [-CheckOnly]

- token 用 `git credential fill` 现取，不落盘
- Release 标题取正文首行 `# vX.Y.Z — …`
- 正文用 `[System.IO.File]::ReadAllText(..., UTF8Encoding($false))` 读取，
  payload 经 `ConvertTo-Json` + `Encoding.UTF8.GetBytes` 发送
  （PS 5.1 直接传字符串会按 ISO-8859-1 发，中文变乱码）
- 已存在同名 release 时必须 `-Force` 才 PATCH 更新；默认 `make_latest=false`
- `-CheckOnly` 只比对本地与线上的 body 字符数，不发请求体

### 附：`.selfcheck/progress.ps1` —— 并行作业的进度轮询

本次多智能体并行写版本说明时用的查看脚本：读 DSH 会话库里的团队任务板（成员 / 任务 /
owner）+ GitHub Release 列表 + 本地交付物（`rel_*.md`、`single/meArm/meArm.ino`、
`make_single.ps1`）+ `git status`。`-Watch -IntervalSec 60` 每 60 秒刷一次。
