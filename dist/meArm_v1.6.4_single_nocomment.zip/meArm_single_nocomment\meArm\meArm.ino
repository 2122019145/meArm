#include <Arduino.h>

#ifndef WEARM_CONFIG_H
#define WEARM_CONFIG_H

#ifndef WEARM_DEBUG_SERIAL
#  define WEARM_DEBUG_SERIAL 0
#endif

#ifndef WEARM_ENABLE_PICK_PLACE
#  define WEARM_ENABLE_PICK_PLACE 1
#endif

#ifndef WEARM_ENABLE_BUTTONS
#  define WEARM_ENABLE_BUTTONS 1
#endif

#ifndef WEARM_ENABLE_DRAW
#  define WEARM_ENABLE_DRAW 1
#endif

#ifndef WEARM_MIRROR_BASE
#  define WEARM_MIRROR_BASE 1
#endif
#ifndef WEARM_MIRROR_TOOL
#  define WEARM_MIRROR_TOOL 1
#endif

#ifndef WEARM_BUTTON_PINS
#  define WEARM_BUTTON_PINS 0
#endif

#ifndef WEARM_REC_TICK_MS
#  define WEARM_REC_TICK_MS 200
#endif
#ifndef WEARM_REC_ENTRIES
#  define WEARM_REC_ENTRIES 192
#endif

#endif

#ifndef WEARM_CONSTANT_AND_POSITIONS_H
#define WEARM_CONSTANT_AND_POSITIONS_H

#include <math.h>
#include <stdbool.h>

#define RADtoDEG (180 / 3.1415926535)
#ifndef PI
#define PI 3.1415926535
#endif
#define ANGLE_EPS 1e-6

struct arm {
  double armLength1;
  double armLength2;
  double armheight;
};

typedef struct servoAngle {
  double angle1;
  double angle2;
  double angle3;
  double angle4;
} SER;

typedef struct rectangularCoordinate {
  double x;
  double y;
  double z;
} REC;

typedef struct position {
  SER ser;
  REC rec;
} pos;

extern pos Pos;
extern struct arm arm1;

#define SERVO_LIMIT_CLAMP  0
#define SERVO_LIMIT_REJECT 1
extern int servoLimitMode;

struct speedCfg {
  double stepSize;
  int    stepDelayMs;
};
extern struct speedCfg speed;

bool isReachable(const REC *rec);

bool getAngle(pos *pos1);

bool getAngleEx(pos *pos1, bool *clamped);

bool recFromServo(REC *rec, const SER *ser);

void posInit(void);

bool posGetHomeAngles(SER *ser);

bool posSetAngle4(double angleDeg);

void setSpeed(double stepSize, int stepDelayMs);

#define SPEED_SLOW   0
#define SPEED_NORMAL 1
#define SPEED_FAST   2
int  adjustSpeed(int level);
int  speedGetLevel(void);
const char *speedLevelName(int level);
int  speedStepDown(void);

#endif

#ifndef WEARM_PROTOCOL_CONSTANTS_H
#define WEARM_PROTOCOL_CONSTANTS_H

#define PROTO_CMD_GRIPPER_OPEN   'O'
#define PROTO_CMD_GRIPPER_CLOSE  'S'
#define PROTO_CMD_SPEED_UP       'H'
#define PROTO_CMD_SPEED_DOWN     'L'

#define PROTO_CMD_PICK_A    'A'
#define PROTO_CMD_PICK_B    'B'
#define PROTO_CMD_PICK_C    'C'

#define PROTO_CMD_BTN_CYCLE    'N'
#define PROTO_CMD_BTN_RECORD   'R'
#define PROTO_CMD_BTN_PLAY     'P'
#define PROTO_CMD_BTN_HOME     'M'
#define PROTO_CMD_BTN_HOME_ALT '0'

#define PROTO_CMD_DRAW_TASK    'F'
#define PROTO_CMD_DRAW_START   'D'
#define PROTO_CMD_DRAW_RECORD  'G'
#define PROTO_CMD_DRAW_UNDO    'E'
#define PROTO_CMD_DRAW_PAUSE   'Q'
#define PROTO_CMD_DRAW_RESUME  'U'
#define PROTO_CMD_DRAW_CANCEL  'W'

#define PROTO_CMD_DRAW_PAPER_Z 'p'
#define PROTO_CMD_DRAW_HALF    'n'
#define PROTO_CMD_DRAW_CENTER  'o'

#define PROTO_AXIS_COUNT 3
extern const char protoAxisChar[PROTO_AXIS_COUNT];
extern const char protoAxisJoint[PROTO_AXIS_COUNT];

#define PROTO_LINE_BUF_SIZE 40
#define PROTO_BAUD          115200
#define PROTO_LINE_TIMEOUT_MS 300

#define PROTO_SPEED_LEVEL_MIN SPEED_SLOW
#define PROTO_SPEED_LEVEL_MAX SPEED_FAST
#define PROTO_SPEED_LEVEL_DEF SPEED_NORMAL

int protoAxisIndexFromChar(int c);

bool protoAxisGetLimit(int axis, double *minAngle, double *maxAngle);

#endif

#ifndef SERVO_DRIVE_H
#define SERVO_DRIVE_H

#define SERVO_CH_COUNT 4u

void servoDriveBegin(void);

void servoDriveAttach(uint8_t ch, uint8_t pin);

void servoDriveWrite(uint8_t ch, double deg);

uint16_t servoDriveTicksForDeg(double deg);

uint8_t servoDriveStep(uint16_t nowTicks, uint16_t *nextDelayTicks);

#endif

#ifndef WEARM_MOVE_H
#define WEARM_MOVE_H

void moveup(void);
void movedown(void);
void moveleft(void);
void moveright(void);
void moveforward(void);
void movebackward(void);

enum MoveDir {
  DIR_UP = 1, DIR_DOWN,
  DIR_LEFT, DIR_RIGHT,
  DIR_FWD, DIR_BWD
};

enum JointDir {
  JOINT_C_UP    = DIR_UP,
  JOINT_C_DOWN  = DIR_DOWN,
  JOINT_B_LEFT  = DIR_LEFT,
  JOINT_B_RIGHT = DIR_RIGHT,
  JOINT_R_FWD   = DIR_FWD,
  JOINT_R_BWD   = DIR_BWD
};

enum MoveResult {
  MOVE_NONE        = 0,
  MOVE_OK          = 1,
  MOVE_AT_LIMIT    = 2,
  MOVE_UNREACHABLE = 3
};

int moveJointStep(int dir, double stepSize);

enum MoveXyzResult {
  MOVE_XYZ_REJECTED = 0,
  MOVE_XYZ_OK       = 1
};

#define MOVE_XYZ_TRACK 0
#define MOVE_XYZ_JOG   1
#define MOVE_XYZ_NOW   2

int moveToPoint(const double *goal, uint8_t seen, double maxDps, double dtSec, int mode);

#endif

#ifndef WEARM_SERIAL_PROTOCOL_H
#define WEARM_SERIAL_PROTOCOL_H

#ifndef WEARM_SERIAL_RESPONSES
#define WEARM_SERIAL_RESPONSES 1
#endif

#define PROTO_RES_NONE          0
#define PROTO_RES_GRIPPER_OPEN  1
#define PROTO_RES_GRIPPER_CLOSE 2
#define PROTO_RES_SPEED_UP      3
#define PROTO_RES_SPEED_DOWN    4
#define PROTO_RES_SPEED_LEVEL   5
#define PROTO_RES_FEATURE       6
#define PROTO_RES_ANGLES_SET    7
#define PROTO_RES_UNKNOWN       8
#define PROTO_RES_BAD_SYNTAX    9
#define PROTO_RES_PICK_STARTED 10
#define PROTO_RES_BUSY         11

#define PROTO_RES_REC_STARTED    12
#define PROTO_RES_REC_SAVED      13
#define PROTO_RES_REC_REJECTED   14
#define PROTO_RES_PLAY_STARTED   15
#define PROTO_RES_PLAY_NO_RECORD 16
#define PROTO_RES_HOME_STARTED   17

#define PROTO_RES_DRAW_TASK_SELECTED 18
#define PROTO_RES_DRAW_STARTED       19
#define PROTO_RES_DRAW_PAUSED        20
#define PROTO_RES_DRAW_RESUMED       21
#define PROTO_RES_DRAW_CANCELED      22
#define PROTO_RES_DRAW_TEACH_POINT   23
#define PROTO_RES_DRAW_TEACH_UNDO    24
#define PROTO_RES_DRAW_REJECTED      25
#define PROTO_RES_DRAW_CALIBRATED    26

void serialProtocolBegin(void);

void serialProtocolLoop(void);

int protoHandleLine(const char *line);

#endif

#ifndef PICK_PLACE_H
#define PICK_PLACE_H

#define PICK_OBJECT_A 0
#define PICK_OBJECT_B 1
#define PICK_OBJECT_C 2
#define PICK_OBJECT_COUNT 3

#if WEARM_ENABLE_PICK_PLACE
int pickPlaceStart(int object);

void pickPlaceLoop(void);

bool pickPlaceIsBusy(void);

int pickPlaceCurrentObject(void);

const char *pickPlaceStageName(void);

bool pickPlaceGetSource(int object, double *x, double *y, double *z);
bool pickPlaceGetTarget(int object, double *x, double *y, double *z);

double pickPlaceApproachDz(void);
#else
static inline int  pickPlaceStart(int object)   { (void)object; return -1; }
static inline void pickPlaceLoop(void)          { }
static inline bool pickPlaceIsBusy(void)        { return false; }
static inline int  pickPlaceCurrentObject(void) { return -1; }
static inline const char *pickPlaceStageName(void) { return ""; }
static inline bool pickPlaceGetSource(int object, double *x, double *y, double *z)
    { (void)object; (void)x; (void)y; (void)z; return false; }
static inline bool pickPlaceGetTarget(int object, double *x, double *y, double *z)
    { (void)object; (void)x; (void)y; (void)z; return false; }
static inline double pickPlaceApproachDz(void)  { return 0.0; }
#endif

#endif

#ifndef BUTTON_CONTROL_H
#define BUTTON_CONTROL_H

#define BTN_COUNT      4
#define BTN_KEY_CYCLE  0
#define BTN_KEY_RECORD 1
#define BTN_KEY_PLAY   2
#define BTN_KEY_HOME   3

#if WEARM_ENABLE_BUTTONS
void buttonSetup(void);

void buttonLoop(void);

int buttonHandleCommand(char c);

bool buttonIsCommandChar(char c);

int buttonPickNext(void);

bool buttonIsRecording(void);
bool buttonPlaybackActive(void);

int buttonRecordingEntries(void);

unsigned long buttonRecordingMs(void);
double buttonRecordingTravel(void);

bool buttonHasRecording(void);

bool buttonControlBusy(void);

bool buttonControlLocked(void);

const char *buttonName(int key);
const char *buttonStateName(void);
#else
static inline void buttonSetup(void)                 {}
static inline void buttonLoop(void)                  {}
static inline int  buttonHandleCommand(char c)       { (void)c; return -1; }
static inline bool buttonIsCommandChar(char c)       { (void)c; return false; }
static inline int  buttonPickNext(void)              { return -1; }
static inline bool buttonIsRecording(void)           { return false; }
static inline bool buttonPlaybackActive(void)        { return false; }
static inline int  buttonRecordingEntries(void)      { return 0; }
static inline unsigned long buttonRecordingMs(void)  { return 0UL; }
static inline double buttonRecordingTravel(void)     { return 0.0; }
static inline bool buttonHasRecording(void)          { return false; }
static inline bool buttonControlBusy(void)           { return false; }
static inline bool buttonControlLocked(void)         { return false; }
static inline const char *buttonName(int key)       { (void)key; return ""; }
static inline const char *buttonStateName(void)     { return ""; }
#endif

#endif

#ifndef DRAW_CONTROL_H
#define DRAW_CONTROL_H

#define DRAW_TASK_LINE      0
#define DRAW_TASK_N         1
#define DRAW_TASK_TRIANGLE  2
#define DRAW_TASK_Z         3
#define DRAW_TASK_V         4
#define DRAW_TASK_POLYLINE  5
#define DRAW_TASK_CURVE     6
#define DRAW_TASK_COUNT     7

#define DRAW_TEACH_MAX_POINTS 5

#define DRAW_KEY_1 0
#define DRAW_KEY_2 1
#define DRAW_KEY_3 2
#define DRAW_KEY_4 3

#define DRAW_PHASE_IDLE      0
#define DRAW_PHASE_HOME      1
#define DRAW_PHASE_TRAVEL    2
#define DRAW_PHASE_PLUNGE    3
#define DRAW_PHASE_PATH      4
#define DRAW_PHASE_LIFT      5
#define DRAW_PHASE_TEACH     6
#define DRAW_PHASE_TEACH_WAIT 7
#define DRAW_PHASE_RETURN    8

#if WEARM_ENABLE_DRAW
void drawSetup(void);

void drawLoop(void);

int drawSelectTask(int task);
int drawTaskCycle(void);
int drawGetTask(void);
const char *drawTaskName(int task);
const char *drawTaskTag(int task);

int drawStartTask(void);

int drawHandleCommand(char c);
bool drawIsCommandChar(char c);

bool drawSetPaperZ(double z);
double drawGetPaperZ(void);
bool drawSetHalfSize(double half);
double drawGetHalfSize(void);
bool drawSetCenter(double x, double y);
double drawGetCenterX(void);
double drawGetCenterY(void);

int drawTeachRecord(void);
int drawTeachUndo(void);
int drawTeachFinish(void);
int drawTeachCount(void);

int drawPause(void);
int drawResume(void);
int drawCancel(void);

int drawHandleButton(int key);
bool drawAcceptButton(int key);

bool drawControlBusy(void);
bool drawControlLocked(void);
int drawGetPhase(void);
const char *drawPhaseName(void);
const char *drawStateName(void);
bool drawIsPaused(void);

unsigned long drawLastRunMs(void);
int drawLastPointsHit(void);
int drawLastPointsTotal(void);
int drawLastResult(void);
#else
static inline void drawSetup(void) { }
static inline void drawLoop(void) { }

static inline int drawSelectTask(int task) { (void)task; return -1; }
static inline int drawTaskCycle(void) { return -1; }
static inline int drawGetTask(void) { return -1; }
static inline const char *drawTaskName(int task) { (void)task; return ""; }
static inline const char *drawTaskTag(int task) { (void)task; return ""; }
static inline int drawStartTask(void) { return -1; }

static inline int drawHandleCommand(char c) { (void)c; return -1; }
static inline bool drawIsCommandChar(char c) { (void)c; return false; }

static inline bool drawSetPaperZ(double z) { (void)z; return false; }
static inline double drawGetPaperZ(void) { return 0.0; }
static inline bool drawSetHalfSize(double half) { (void)half; return false; }
static inline double drawGetHalfSize(void) { return 0.0; }
static inline bool drawSetCenter(double x, double y) { (void)x; (void)y; return false; }
static inline double drawGetCenterX(void) { return 0.0; }
static inline double drawGetCenterY(void) { return 0.0; }

static inline int drawTeachRecord(void) { return -1; }
static inline int drawTeachUndo(void) { return -1; }
static inline int drawTeachFinish(void) { return -1; }
static inline int drawTeachCount(void) { return 0; }

static inline int drawPause(void) { return -1; }
static inline int drawResume(void) { return -1; }
static inline int drawCancel(void) { return -1; }

static inline int drawHandleButton(int key) { (void)key; return -1; }
static inline bool drawAcceptButton(int key) { (void)key; return false; }

static inline bool drawControlBusy(void) { return false; }
static inline bool drawControlLocked(void) { return false; }
static inline int drawGetPhase(void) { return -1; }
static inline const char *drawPhaseName(void) { return ""; }
static inline const char *drawStateName(void) { return ""; }
static inline bool drawIsPaused(void) { return false; }

static inline unsigned long drawLastRunMs(void) { return 0UL; }
static inline int drawLastPointsHit(void) { return 0; }
static inline int drawLastPointsTotal(void) { return 0; }
static inline int drawLastResult(void) { return -1; }
#endif

#endif

#ifndef WEARM_JOYSTICK_CONTROL_H
#define WEARM_JOYSTICK_CONTROL_H

struct joyState {
  int base;
  int shoulder;
  int elbow;
  int tool;

  int sx;
  int sy;
  int tx;
  int ty;

  int dir;
  int mag;
  int mask;
};

#define JOY_DIR_NONE   0
#define JOY_DIR_RIGHT  2
#define JOY_DIR_BWD    3
#define JOY_DIR_LEFT   4
#define JOY_DIR_FWD    5
#define JOY_DIR_UP     6
#define JOY_DIR_DOWN   7

#define JOY_ACT_BASE     0x01
#define JOY_ACT_SHOULDER 0x02
#define JOY_ACT_ELBOW    0x04
#define JOY_ACT_TOOL     0x08

void joystickSetup(void);

void joystickReadState(struct joyState *st);

int joystickRead(void);

void joystickLoop(void);

#endif

#ifndef PATH_CORE_H
#define PATH_CORE_H

inline bool pathCoreSolveJoint(double x, double y, double z,
                               double *b, double *r, double *c) {
  pos p;
  p.rec.x = x;
  p.rec.y = y;
  p.rec.z = z;
  p.ser = Pos.ser;
  bool clamped = false;
  if (!getAngleEx(&p, &clamped)) return false;
  if (clamped) return false;
  if (b) *b = p.ser.angle1;
  if (r) *r = p.ser.angle2;
  if (c) *c = p.ser.angle3;
  return true;
}

inline bool pathCorePointOk(double x, double y, double z,
                            double *b, double *r, double *c) {
  REC rec;
  rec.x = x;
  rec.y = y;
  rec.z = z;
  if (!isReachable(&rec)) return false;

  return pathCoreSolveJoint(x, y, z, b, r, c);
}

inline void pathCoreSetJoints(double b, double r, double c) {
  Pos.ser.angle1 = b;
  Pos.ser.angle2 = r;
  Pos.ser.angle3 = c;
  (void) recFromServo(&Pos.rec, &Pos.ser);
}

inline bool pathCoreSegmentOk(const double *p0, const double *p1,
                              double sampleStep, int sampleMax, double jumpDeg) {
  double x0 = p0[0], y0 = p0[1], z0 = p0[2];
  double dx = p1[0] - x0;
  double dy = p1[1] - y0;
  double dz = p1[2] - z0;
  double len = sqrt(dx * dx + dy * dy + dz * dz);

  int steps = (int)(len / sampleStep) + 1;
  if (steps < 2) steps = 2;
  if (steps > sampleMax) steps = sampleMax;

  double pb = 0.0, pr = 0.0, pc = 0.0;
  for (int i = 0; i <= steps; i++) {
    double t = (double)i / (double)steps;
    double b = 0.0, r = 0.0, c = 0.0;
    if (!pathCorePointOk(x0 + dx * t, y0 + dy * t, z0 + dz * t, &b, &r, &c)) {
      return false;
    }
    if (i > 0) {
      if (fabs(b - pb) > jumpDeg ||
          fabs(r - pr) > jumpDeg ||
          fabs(c - pc) > jumpDeg) {
        return false;
      }
    }
    pb = b;
    pr = r;
    pc = c;
  }
  return true;
}

#endif

#define SERVO_MIN_US      544
#define SERVO_MAX_US      2400
#define SERVO_TRIM_US     2
#define SERVO_TICKS_PER_US 2u
#define SERVO_FRAME_TICKS 40000u
#define SERVO_FIRST_TICKS 1000u
#define SERVO_DEFAULT_TICKS 3000u
#define SERVO_PIN_NONE    0xFFu

static uint8_t  s_pin[SERVO_CH_COUNT];
static volatile uint16_t s_ticks[SERVO_CH_COUNT];
static uint8_t  s_ch;

uint16_t servoDriveTicksForDeg(double deg) {
  int a = (int)deg;
  if (a < 0) { a = 0; } else if (a > 180) { a = 180; }
  uint16_t us = (uint16_t)(SERVO_MIN_US + (int)(((long)a * (SERVO_MAX_US - SERVO_MIN_US)) / 180L));
  us = (uint16_t)(us - SERVO_TRIM_US);
  return (uint16_t)(us * SERVO_TICKS_PER_US);
}

void servoDriveBegin(void) {
  for (uint8_t i = 0; i < SERVO_CH_COUNT; i++) {
    s_pin[i]   = SERVO_PIN_NONE;
    s_ticks[i] = SERVO_DEFAULT_TICKS;
  }
  s_ch    = SERVO_CH_COUNT;
#if defined(__AVR__)
  TCCR1A = 0;
  TCCR1B = _BV(CS11);
  TCNT1  = 0;
  TIFR1 |= _BV(OCF1A);
  OCR1A  = SERVO_FIRST_TICKS;
  TIMSK1 |= _BV(OCIE1A);
#endif
}

void servoDriveAttach(uint8_t ch, uint8_t pin) {
  if (ch >= SERVO_CH_COUNT) { return; }
  s_pin[ch] = pin;
  pinMode(pin, OUTPUT);
  digitalWrite(pin, LOW);
}

void servoDriveWrite(uint8_t ch, double deg) {
  if (ch >= SERVO_CH_COUNT) { return; }
  uint16_t t = servoDriveTicksForDeg(deg);
#if defined(__AVR__)
  uint8_t s = SREG;
  cli();
  s_ticks[ch] = t;
  SREG = s;
#else
  s_ticks[ch] = t;
#endif
}

uint8_t servoDriveStep(uint16_t nowTicks, uint16_t *nextDelayTicks) {
  if (s_ch >= SERVO_CH_COUNT) {
    s_ch = 0u;
    if (s_pin[0] != SERVO_PIN_NONE) { digitalWrite(s_pin[0], HIGH); }
    *nextDelayTicks = s_ticks[0];
    return 1u;
  }

  if (s_pin[s_ch] != SERVO_PIN_NONE) { digitalWrite(s_pin[s_ch], LOW); }
  s_ch++;
  if (s_ch < SERVO_CH_COUNT) {
    if (s_pin[s_ch] != SERVO_PIN_NONE) { digitalWrite(s_pin[s_ch], HIGH); }
    *nextDelayTicks = (uint16_t)(nowTicks + s_ticks[s_ch]);
    return 0u;
  }

  *nextDelayTicks = SERVO_FRAME_TICKS;
  return 0u;
}

#if defined(__AVR__)
ISR(TIMER1_COMPA_vect) {
  uint16_t next;
  if (servoDriveStep((uint16_t)TCNT1, &next) != 0u) {
    TCNT1 = 0;
  }
  OCR1A = next;
}
#endif

#if WEARM_DEBUG_SERIAL
  #define WEARM_LOG(msg)   Serial.println(F(msg))
#else
  #define WEARM_LOG(msg)   ((void)0)
#endif

static const REC POS_HOME = { 20, 0, 20 };

struct arm arm1 = { 20, 20, 0 };

pos Pos = { { 0, 0, 0, 0 }, { POS_HOME.x, POS_HOME.y, POS_HOME.z } };

struct speedCfg speed = {
  .stepSize    = 1.0,
  .stepDelayMs = 40
};

int servoLimitMode = SERVO_LIMIT_CLAMP;

static int speedLevel = SPEED_NORMAL;

static bool __attribute__((noinline)) isFiniteNum(double v) {
  return (v - v) == 0.0;
}

static double __attribute__((noinline)) clampDouble(double v, double lo, double hi) {
  if (lo > hi) { double t = lo; lo = hi; hi = t; }
  if (v < lo) return lo;
  if (v > hi) return hi;
  return v;
}

bool isReachable(const REC *rec) {
  if (rec == NULL) return false;
  if (!isFiniteNum(rec->x) || !isFiniteNum(rec->y) || !isFiniteNum(rec->z)) return false;

  double zv = rec->z - arm1.armheight;
  double R = sqrt(rec->x * rec->x + rec->y * rec->y + zv * zv);

  double L1 = arm1.armLength1;
  double L2 = arm1.armLength2;
  if (L1 <= 0 || L2 <= 0) return false;

  const double GEOM_EPS = 1e-9;
  if (R > L1 + L2 + GEOM_EPS || R < fabs(L1 - L2) - GEOM_EPS) return false;
  return true;
}

static void __attribute__((noinline)) fkPlanar(double alpha, double beta,
                                               double *outX, double *outZ) {
  const double L1 = arm1.armLength1;
  const double L2 = arm1.armLength2;
  *outX = L1 * cos(alpha) + L2 * cos(beta);
  *outZ = L1 * sin(alpha) + L2 * sin(beta);
}

bool recFromServo(REC *rec, const SER *ser) {
  if (rec == NULL || ser == NULL) return false;

  double b = ser->angle1;
  double r = ser->angle2;
  double c = ser->angle3;
  if (!isFiniteNum(b) || !isFiniteNum(r) || !isFiniteNum(c)) return false;

  double alpha = r / RADtoDEG;
  double beta  = (r - c) / RADtoDEG;
  double xPlanar;
  double z;
  fkPlanar(alpha, beta, &xPlanar, &z);
  z += arm1.armheight;

  double theta = (90.0 - b) / RADtoDEG;
  double x = xPlanar * cos(theta);
  double y = xPlanar * sin(theta);
  if (!isFiniteNum(x) || !isFiniteNum(y) || !isFiniteNum(z)) return false;

  rec->x = x;
  rec->y = y;
  rec->z = z;
  return true;
}

static void ikBranch(double rhoP, double zv, double delta, double L1, double L2,
                     double *beta, double *err) {
  double phiBase = atan2(zv, rhoP);
  double argW    = atan2(L2 * sin(delta), L1 + L2 * cos(delta));
  *beta = phiBase - argW;
  double alpha = *beta + delta;
  double fx, fz;
  fkPlanar(alpha, *beta, &fx, &fz);
  double dx = fx - rhoP, dz = fz - zv;
  *err = sqrt(dx * dx + dz * dz);
}

static double __attribute__((noinline)) normRevAngle(double b) {
  if (b < 0.0)    b += 360.0;
  if (b >= 360.0) b -= 360.0;
  if (b > 360.0 - 1e-6) b = 0.0;
  return b;
}

bool getAngle(pos *pos1) {
  return getAngleEx(pos1, NULL);
}

bool getAngleEx(pos *pos1, bool *clamped) {
  if (clamped != NULL) *clamped = false;
  if (pos1 == NULL) return false;

  if (!isReachable(&pos1->rec)) {
    WEARM_LOG("[kin] reject: target out of reachable workspace");
    return false;
  }

  const double L1 = arm1.armLength1;
  const double L2 = arm1.armLength2;

  double rho = sqrt(pos1->rec.x * pos1->rec.x + pos1->rec.y * pos1->rec.y);
  double zv  = pos1->rec.z - arm1.armheight;
  double R2  = rho * rho + zv * zv;

  double cosC = (R2 - L1 * L1 - L2 * L2) / (2.0 * L1 * L2);
  if (cosC >  1.0) cosC =  1.0;
  if (cosC < -1.0) cosC = -1.0;
  double cAbs = acos(cosC);

  const double EPS = 1e-9;

  const double minB = 0.0, maxB = 180.0;
  const double minR = 0.0, maxR = 180.0;
  const double minC = 0.0, maxC = 180.0;

  double bFwd = 90.0, bRev = 90.0;
  if (rho > 1e-9) {
    bFwd = 90.0 - RADtoDEG * atan2( pos1->rec.y,  pos1->rec.x);
    bRev = 90.0 - RADtoDEG * atan2(-pos1->rec.y, -pos1->rec.x);
  }
  bFwd = normRevAngle(bFwd);
  bRev = normRevAngle(bRev);

  double bestB = 0.0, bestR = 0.0, bestC = 0.0, bestErr = 1e30;
  int pick = -1;

  for (int i = 0; i < 4; i++) {
    const bool reversePlane = (i >= 2);
    const double k = ((i & 1) == 0) ? 1.0 : -1.0;
    const double rhoP  = reversePlane ? -rho : rho;
    const double delta = k * cAbs;
    const double b = reversePlane ? bRev : bFwd;

    if (b < minB - EPS || b > maxB + EPS) continue;

    double beta, err;
    ikBranch(rhoP, zv, delta, L1, L2, &beta, &err);
    double rDeg = RADtoDEG * (beta + delta);
    double cDeg = RADtoDEG * delta;

    if (!(rDeg >= minR - EPS && rDeg <= maxR + EPS)) continue;
    if (!(cDeg >= minC - EPS && cDeg <= maxC + EPS)) continue;
    if (!isFiniteNum(err)) continue;

    if (pick < 0 || err < bestErr) {
      pick = i; bestErr = err;
      bestB = b; bestR = rDeg; bestC = cDeg;
    }
  }

  if (pick < 0) {
    WEARM_LOG("[kin] reject: no planar branch fits the joint travel");
    return false;
  }

  if (!(bestErr <= 0.05)) {
    WEARM_LOG("[kin] reject: residual too large, no valid solution");
    return false;
  }

  double angle1 = bestB;
  double angle2 = bestR;
  double angle3 = bestC;

  if (angle2 > -ANGLE_EPS && angle2 < 0) angle2 = 0;
  if (angle3 > -ANGLE_EPS && angle3 < 0) angle3 = 0;

  const double LIM_EPS = 1e-9;
  const double a4 = pos1->ser.angle4;
  const double minF = 60.0, maxF = 150.0;
  const bool toolBad = (a4 < minF - LIM_EPS || a4 > maxF + LIM_EPS);

  if (toolBad && servoLimitMode == SERVO_LIMIT_REJECT) {
    WEARM_LOG("[servo] reject joint f out of tool range");
    return false;
  }

  pos1->ser.angle1 = angle1;
  pos1->ser.angle2 = angle2;
  pos1->ser.angle3 = angle3;

  bool limClamped = false;
  if (toolBad) {
    double v = a4;
    if (v < minF) v = minF;
    if (v > maxF) v = maxF;
    pos1->ser.angle4 = v;
    limClamped = true;
  }
  if (clamped != NULL) *clamped = limClamped;
  return true;
}

void posInit(void) {
  Pos.rec.x = POS_HOME.x;
  Pos.rec.y = POS_HOME.y;
  Pos.rec.z = POS_HOME.z;

  Pos.ser.angle4 = (60.0 + 150.0) * 0.5;

  if (!getAngle(&Pos)) {
    WEARM_LOG("[pos] ERROR: POS_HOME unreachable");
  }
#if WEARM_DEBUG_SERIAL
  {
    REC chk;
    if (recFromServo(&chk, &Pos.ser)) {
      Serial.print(F("[pos] home fk check: x="));
      Serial.print(chk.x);
      Serial.print(F(" y="));
      Serial.print(chk.y);
      Serial.print(F(" z="));
      Serial.print(chk.z);
      Serial.print(F("  (POS_HOME x="));
      Serial.print(POS_HOME.x);
      Serial.print(F(" y="));
      Serial.print(POS_HOME.y);
      Serial.print(F(" z="));
      Serial.print(POS_HOME.z);
      Serial.println(F(")"));
    } else {
      Serial.println(F("[pos] home fk check: recFromServo failed"));
    }
  }
#endif
}

bool posGetHomeAngles(SER *ser) {
  if (ser == NULL) return false;

  pos p;
  p.ser = *ser;
  p.rec.x = POS_HOME.x;
  p.rec.y = POS_HOME.y;
  p.rec.z = POS_HOME.z;
  if (!getAngle(&p)) return false;

  ser->angle1 = p.ser.angle1;
  ser->angle2 = p.ser.angle2;
  ser->angle3 = p.ser.angle3;
  return true;
}

void setSpeed(double stepSize, int stepDelayMs) {
  bool changed = false;
  if (stepSize > 0 && stepSize != speed.stepSize) {
    speed.stepSize = stepSize; changed = true;
  }
  if (stepDelayMs > 0 && stepDelayMs != speed.stepDelayMs) {
    speed.stepDelayMs = stepDelayMs; changed = true;
  }
  if (changed) speedLevel = -1;
}

int adjustSpeed(int level) {
  if (level < SPEED_SLOW || level > SPEED_FAST) return -1;
  setSpeed(0.5 * (1 << level), 80 >> level);
  speedLevel = level;
  return level;
}

int speedGetLevel(void) {
  return speedLevel;
}

const char * __attribute__((noinline)) speedLevelName(int level) {
  switch (level) {
    case SPEED_SLOW:   return "慢速";
    case SPEED_NORMAL: return "中速";
    case SPEED_FAST:   return "快速";
    default:           return "自定义";
  }
}

int speedStepDown(void) {
  int cur = speedLevel;
  if (cur < SPEED_SLOW || cur > SPEED_FAST) cur = SPEED_FAST;
  return adjustSpeed((cur + 1) % 3);
}

bool posSetAngle4(double angleDeg) {
  if (!isFiniteNum(angleDeg)) return false;

  double v = clampDouble(angleDeg, 60.0, 150.0);
  if (v == Pos.ser.angle4) return false;
  Pos.ser.angle4 = v;
  return true;
}

const char protoAxisChar[PROTO_AXIS_COUNT] = { 'x', 'y', 'z' };

const char protoAxisJoint[PROTO_AXIS_COUNT] = { 'b', 'r', 'c' };

int protoAxisIndexFromChar(int c)
{
  char lower_c = (char)c;
  if (c >= 'A' && c <= 'Z') {
    lower_c = (char)(c - 'A' + 'a');
  }

  for (int i = 0; i < PROTO_AXIS_COUNT; i++) {
    if (protoAxisChar[i] == lower_c) {
      return i;
    }
  }
  return -1;
}

bool protoAxisGetLimit(int axis, double *minAngle, double *maxAngle)
{
  if (axis < 0 || axis >= PROTO_AXIS_COUNT || minAngle == NULL || maxAngle == NULL) {
    return false;
  }

  *minAngle = 0.0;
  *maxAngle = 180.0;

  return true;
}

static const unsigned char DIR_CODE[7] PROGMEM = {
  0,
  (2 << 1) | 0,
  (2 << 1) | 1,
  (0 << 1) | 1,
  (0 << 1) | 0,
  (1 << 1) | 0,
  (1 << 1) | 1
};

static bool samePose(const SER *a, const SER *b) {
  const unsigned char *pa = (const unsigned char *)a;
  const unsigned char *pb = (const unsigned char *)b;
  for (unsigned char i = 0; i < 3 * sizeof(double); i++) {
    if (pa[i] != pb[i]) return false;
  }
  return true;
}

static void clampBCR(SER *s) {
  if (s->angle1 < 0.0)   s->angle1 = 0.0;
  if (s->angle1 > 180.0) s->angle1 = 180.0;
  if (s->angle2 < 0.0)   s->angle2 = 0.0;
  if (s->angle2 > 180.0) s->angle2 = 180.0;
  if (s->angle3 < 0.0)   s->angle3 = 0.0;
  if (s->angle3 > 180.0) s->angle3 = 180.0;
}

int moveJointStep(int dir, double stepSize) {
  if (stepSize <= 0) stepSize = speed.stepSize;

  if (dir <= 0 || dir > JOINT_R_BWD) {
    return MOVE_NONE;
  }
  SER next = Pos.ser;
  unsigned char code = pgm_read_byte(&DIR_CODE[dir]);
  double *ap = &next.angle1 + (code >> 1);
  double step = stepSize;
  if (code & 1) step = -step;
  *ap += step;

  clampBCR(&next);
  if (samePose(&next, &Pos.ser)) {
    return MOVE_AT_LIMIT;
  }

  REC nextRec;
  if (!recFromServo(&nextRec, &next)) {
    return MOVE_UNREACHABLE;
  }

  Pos.ser = next;
  Pos.rec = nextRec;
  return MOVE_OK;
}

static void stepFixed(int dir) {
  (void) moveJointStep(dir, 1.0);
}

void moveup(void)       { stepFixed(JOINT_C_UP); }
void movedown(void)     { stepFixed(JOINT_C_DOWN); }
void moveleft(void)     { stepFixed(JOINT_B_LEFT); }
void moveright(void)    { stepFixed(JOINT_B_RIGHT); }
void moveforward(void)  { stepFixed(JOINT_R_FWD); }
void movebackward(void) { stepFixed(JOINT_R_BWD); }

int moveToPoint(const double *goal, uint8_t seen, double maxDps, double dtSec, int mode) {
  if (goal == NULL) return MOVE_XYZ_REJECTED;

  pos target = Pos;
  if (seen & (uint8_t)(1u << 0)) target.rec.x = goal[0];
  if (seen & (uint8_t)(1u << 1)) target.rec.y = goal[1];
  if (seen & (uint8_t)(1u << 2)) target.rec.z = goal[2];

  bool clamped = false;
  if (!getAngleEx(&target, &clamped)) return MOVE_XYZ_REJECTED;

  if (mode == MOVE_XYZ_NOW) {
    Pos = target;
    (void) recFromServo(&Pos.rec, &Pos.ser);
    return MOVE_XYZ_OK;
  }

  if (clamped) return MOVE_XYZ_REJECTED;

  double cur[3];
  cur[0] = Pos.ser.angle1;
  cur[1] = Pos.ser.angle2;
  cur[2] = Pos.ser.angle3;
  double tgt[3];
  tgt[0] = target.ser.angle1;
  tgt[1] = target.ser.angle2;
  tgt[2] = target.ser.angle3;

  double maxStep = maxDps * dtSec;
  if (maxStep < 0.2) maxStep = 0.2;

  if (mode == MOVE_XYZ_TRACK) {
    for (unsigned char i = 0; i < 3; i++) {
      if (fabs(tgt[i] - cur[i]) > maxStep) return MOVE_XYZ_REJECTED;
    }
    pathCoreSetJoints(tgt[0], tgt[1], tgt[2]);
    return MOVE_XYZ_OK;
  }

  if (mode != MOVE_XYZ_JOG) return MOVE_XYZ_REJECTED;

  double d[3];
  for (unsigned char i = 0; i < 3; i++) {
    d[i] = tgt[i] - cur[i];
    if (d[i] > maxStep) d[i] = maxStep;
    else if (d[i] < -maxStep) d[i] = -maxStep;
  }
  pathCoreSetJoints(cur[0] + d[0], cur[1] + d[1], cur[2] + d[2]);
  return MOVE_XYZ_OK;
}

#define WEARM_JOY_DEBUG    0
#define WEARM_HAVE_BUTTONS 0

#if WEARM_DEBUG_SERIAL
  #define JLOG(msg)   Serial.println(F(msg))
#else
  #define JLOG(msg)   ((void)0)
#endif

#define JOY_LX_PIN     A0
#define JOY_LY_PIN     A1
#define JOY_RX_PIN     A2
#define JOY_RY_PIN     A3

#define PIN_LED_MODE   13

#define JOY_CENTER     512
#define JOY_DEADZONE   40
#define JOY_FULL_SCALE 500

#define JOY_CAL_SAMPLES  32
#define JOY_CAL_MAX_OFF 80

#define JOY_STEP_MIN_DEG 0.1

#define JOY_HYST 25
#define JOY_TRACK_MS 20

#define JOY_BTN_DEBOUNCE_MS 30
#define LED_FAST_MS    100

enum JointIdx { JIDX_BASE = 0, JIDX_SHOULDER, JIDX_ELBOW, JIDX_TOOL, JIDX_COUNT };

static const unsigned char JOY_DIR_NEG[JIDX_COUNT] PROGMEM = {
  (unsigned char)JOINT_B_LEFT,
  (unsigned char)JOINT_R_FWD,
  (unsigned char)JOINT_C_UP,
  0
};

#ifdef __AVR__
#define JOY_DIRNEG(i) ((int)pgm_read_byte(&JOY_DIR_NEG[(i)]))
#else
#define JOY_DIRNEG(i) ((int)JOY_DIR_NEG[(i)])
#endif

static const unsigned char JOY_RAW_SLOT[JIDX_COUNT] PROGMEM = { 0, 1, 3, 2 };

#ifdef __AVR__
#define JOY_RAWSLOT(i) ((int)pgm_read_byte(&JOY_RAW_SLOT[(i)]))
#else
#define JOY_RAWSLOT(i) ((int)JOY_RAW_SLOT[(i)])
#endif

static unsigned long lastStepTime[JIDX_COUNT] = { 0, 0, 0, 0 };

static int s_centerOff[4] = { 0, 0, 0, 0 };

static bool          s_axisHot[JIDX_COUNT] = { false, false, false, false };
static unsigned long s_trackMs[JIDX_COUNT] = { 0, 0, 0, 0 };

#if WEARM_DEBUG_SERIAL
static unsigned long lastBlockLogTime = 0;
#endif

#if WEARM_HAVE_BUTTONS
static bool sw1Prev = false;
static bool sw2Prev = false;
static bool sw2LongFired = false;
static unsigned long sw2DownTime = 0;
#endif

static void logBlocked(const __FlashStringHelper *msg) {
#if WEARM_DEBUG_SERIAL
  unsigned long now = millis();
  if (now - lastBlockLogTime < 500) return;
  lastBlockLogTime = now;
  Serial.println(msg);
#else
  (void) msg;
#endif
}

#if WEARM_HAVE_BUTTONS
static bool buttonDown(uint8_t pin) {
  static bool stable[20] = { false };
  static unsigned long changeAt[20] = { 0 };
  if (pin >= 20) return false;

  bool raw = (digitalRead(pin) == LOW);
  if (raw == stable[pin]) return stable[pin];

  unsigned long now = millis();
  if (changeAt[pin] == 0) {
    changeAt[pin] = now;
    return stable[pin];
  }
  if (now - changeAt[pin] >= JOY_BTN_DEBOUNCE_MS) {
    stable[pin] = raw;
    changeAt[pin] = 0;
  }
  return stable[pin];
}
#endif

static void joyCalibrateAxis(uint8_t pin) {
  long sum = 0;
  for (uint8_t i = 0; i < JOY_CAL_SAMPLES; i++) { sum += analogRead(pin); }
  int off = (int)(sum / (long)JOY_CAL_SAMPLES) - JOY_CENTER;
  if (off > JOY_CAL_MAX_OFF || off < -JOY_CAL_MAX_OFF) { off = 0; }
  s_centerOff[pin - A0] = off;
}

static int readAxisAmp(uint8_t pin, int *raw) {
  int idx = pin - A0;
  int v = analogRead(pin) - s_centerOff[idx];
  if (raw != NULL) *raw = v;
  int d = v - JOY_CENTER;
  int a = (d >= 0) ? d : -d;
  int gate = s_axisHot[idx] ? JOY_DEADZONE : (JOY_DEADZONE + JOY_HYST);
  if (a < gate) {
    unsigned long now = millis();
    if ((unsigned long)(now - s_trackMs[idx]) >= (unsigned long)JOY_TRACK_MS) {
      s_trackMs[idx] = now;
      int next = s_centerOff[idx] + ((d > 0) ? 1 : ((d < 0) ? -1 : 0));
      if (next >= -JOY_CAL_MAX_OFF && next <= JOY_CAL_MAX_OFF) { s_centerOff[idx] = next; }
    }
    s_axisHot[idx] = false;
    return 0;
  }
  s_axisHot[idx] = true;
  a -= JOY_DEADZONE;
  return (a > 0) ? a : 0;
}

void joystickReadState(struct joyState *st) {
  if (st == NULL) return;

  st->base     = readAxisAmp(JOY_LX_PIN, &st->sx);
  st->shoulder = readAxisAmp(JOY_LY_PIN, &st->sy);
  st->tool     = readAxisAmp(JOY_RX_PIN, &st->tx);
  st->elbow    = readAxisAmp(JOY_RY_PIN, &st->ty);

  int mask  = 0;
  int mag   = 0;
  int best  = JOY_DIR_NONE;

  if (st->base > 0) {
    mask |= JOY_ACT_BASE;
    if (st->base > mag) {
      mag = st->base;
      best = (st->sx > JOY_CENTER) ? JOY_DIR_RIGHT : JOY_DIR_LEFT;
    }
  }
  if (st->shoulder > 0) {
    mask |= JOY_ACT_SHOULDER;
    if (st->shoulder > mag) {
      mag = st->shoulder;
      best = (st->sy > JOY_CENTER) ? JOY_DIR_BWD : JOY_DIR_FWD;
    }
  }
  if (st->elbow > 0) {
    mask |= JOY_ACT_ELBOW;
    if (st->elbow > mag) {
      mag = st->elbow;
      best = (st->ty > JOY_CENTER) ? JOY_DIR_DOWN : JOY_DIR_UP;
    }
  }
  if (st->tool > 0) {
    mask |= JOY_ACT_TOOL;
    if (st->tool > mag) mag = st->tool;
  }

  st->mask = mask;
  st->dir  = best;
  st->mag  = mag;
}

int joystickRead(void) {
  struct joyState st;
  joystickReadState(&st);
  return st.dir;
}

static bool toolStep(int amp, int sign) {
  if (amp <= 0) return false;

  if (amp > JOY_FULL_SCALE) amp = JOY_FULL_SCALE;

  double step = speed.stepSize * ((double)amp / (double)JOY_FULL_SCALE);
  if (sign < 0) step = -step;

  return posSetAngle4(Pos.ser.angle4 + step);
}

static void updateLed(bool moving) {
  if (!moving) {
    PORTB &= (unsigned char)~_BV(PB5);
    return;
  }
  bool on = ((millis() / (unsigned long)LED_FAST_MS) % 2UL) == 0UL;
  if (on) PORTB |= (unsigned char)_BV(PB5);
  else    PORTB &= (unsigned char)~_BV(PB5);
}

void joystickSetup(void) {
  DDRC &= (unsigned char)~(_BV(PC0) | _BV(PC1) | _BV(PC2) | _BV(PC3));
  DDRB |= (unsigned char)_BV(PB5);
  PORTB &= (unsigned char)~_BV(PB5);

#if WEARM_DEBUG_SERIAL
  JLOG("[joy] MeArm dual-stick JOINT control ready (A0-A3)");
  JLOG("[joy] A0 -> b angle1 base   A1 -> r angle2 shoulder");
  JLOG("[joy] A3 -> c angle3 elbow  A2 -> f angle4 tool");
#endif

  joyCalibrateAxis(JOY_LX_PIN);
  joyCalibrateAxis(JOY_LY_PIN);
  joyCalibrateAxis(JOY_RX_PIN);
  joyCalibrateAxis(JOY_RY_PIN);

  for (int i = 0; i < JIDX_COUNT; i++) lastStepTime[i] = millis();
#if WEARM_DEBUG_SERIAL
  lastBlockLogTime = 0;
#endif
#if WEARM_HAVE_BUTTONS
  sw1Prev = false;
  sw2Prev = false;
  sw2LongFired = false;
#endif
}

void joystickLoop(void) {
  struct joyState st;
  joystickReadState(&st);

  bool locked = pickPlaceIsBusy() | buttonControlLocked() | drawControlLocked();
  bool moved = false;

  const int *amp  = &st.base;
  const int *rawp = &st.sx;

  if (!locked) {
    unsigned long now = millis();

    for (int i = 0; i < JIDX_COUNT; i++) {
      if (amp[i] <= 0) continue;

      int interval = speed.stepDelayMs;
      if (now - lastStepTime[i] < (unsigned long)interval) continue;

      int raw = rawp[JOY_RAWSLOT(i)];

      if (i == JIDX_TOOL) {
        int sign = (raw > JOY_CENTER) ? -1 : 1;
        if (toolStep(amp[i], sign)) {
          moved = true;
        } else {
          logBlocked(F("[joy] blocked: tool at servo limit"));
        }
      } else {
        int dirNeg = JOY_DIRNEG(i);
        int dir = (raw > JOY_CENTER) ? (dirNeg + 1) : dirNeg;
        int ampNow = amp[i];
        if (ampNow > JOY_FULL_SCALE) ampNow = JOY_FULL_SCALE;
        double step = speed.stepSize * ((double)ampNow / (double)JOY_FULL_SCALE);
        if (step < JOY_STEP_MIN_DEG) step = JOY_STEP_MIN_DEG;
        int res = moveJointStep(dir, step);
        if (res == MOVE_OK) {
          moved = true;
        } else if (res == MOVE_AT_LIMIT) {
          logBlocked(F("[joy] blocked: joint at travel limit"));
        } else if (res == MOVE_UNREACHABLE) {
          logBlocked(F("[joy] blocked: position out of workspace"));
        }
      }
      lastStepTime[i] = now;
    }
  }

#if WEARM_JOY_DEBUG
  static unsigned long lastJoyDbgMs = 0;
  unsigned long dbgNow = millis();
  if (moved || (unsigned long)(dbgNow - lastJoyDbgMs) >= 500UL) {
    lastJoyDbgMs = dbgNow;
    Serial.print(F("[joy] raw A0..A3="));
    Serial.print(st.sx); Serial.print(',');
    Serial.print(st.sy); Serial.print(',');
    Serial.print(st.tx); Serial.print(',');
    Serial.print(st.ty);
    Serial.print(F("  amp b/r/c/f="));
    Serial.print(st.base);     Serial.print('/');
    Serial.print(st.shoulder); Serial.print('/');
    Serial.print(st.elbow);    Serial.print('/');
    Serial.print(st.tool);
    Serial.print(F("  b=")); Serial.print(Pos.ser.angle1);
    Serial.print(F(" r="));  Serial.print(Pos.ser.angle2);
    Serial.print(F(" c="));  Serial.print(Pos.ser.angle3);
    Serial.print(F(" f="));  Serial.print(Pos.ser.angle4);
    Serial.print(F("  rec x=")); Serial.print(Pos.rec.x);
    Serial.print(F(" y="));      Serial.print(Pos.rec.y);
    Serial.print(F(" z="));      Serial.println(Pos.rec.z);
  }
#endif

  updateLed(moved || locked);
}

#if WEARM_ENABLE_PICK_PLACE

#define PICK_GRASP_Z 12.0

#define PICK_APPROACH_DZ 6.0

struct pickPoint {
  double x;
  double y;
  double z;
};

static const struct pickPoint PICK_SRC[PICK_OBJECT_COUNT] PROGMEM = {
  { 24.0,  12.0, PICK_GRASP_Z },
  { 24.0, -12.0, PICK_GRASP_Z },
  { 12.0,  20.0, PICK_GRASP_Z }
};

static const struct pickPoint PICK_DST[PICK_OBJECT_COUNT] PROGMEM = {
  { 16.0, -14.0, PICK_GRASP_Z },
  { 18.0,  16.0, PICK_GRASP_Z },
  { 28.0,  -6.0, PICK_GRASP_Z }
};

static const char PICK_LETTER[PICK_OBJECT_COUNT] = { 'A', 'B', 'C' };

#define PICK_RATE_SLOW_DPS   25.0
#define PICK_RATE_NORMAL_DPS 50.0
#define PICK_RATE_FAST_DPS   90.0

#define PICK_TOOL_RATE_DPS 60.0
#define PICK_DWELL_MS      400

#define PICK_MIN_SEG_MS 180
#define PICK_MAX_SEG_MS 4000

#define PICK_PATH_SAMPLE_STEP 0.5
#define PICK_PATH_SAMPLE_MAX  64
#define PICK_BRANCH_JUMP_DEG  25.0

#define PICK_START_TOL_DEG 10.0

#define PICK_TOOL_OPEN_ANGLE  150.0
#define PICK_TOOL_CLOSE_ANGLE 60.0

enum {
  PICK_ST_IDLE = 0,
  PICK_ST_TO_SRC_APPROACH,
  PICK_ST_DESCEND_SRC,
  PICK_ST_CLOSE_TOOL,
  PICK_ST_DWELL_CLOSE,
  PICK_ST_LIFT,
  PICK_ST_TRAVERSE,
  PICK_ST_DESCEND_DST,
  PICK_ST_OPEN_TOOL,
  PICK_ST_DWELL_OPEN,
  PICK_ST_RETREAT
};

static const char *const PICK_STAGE_NAME[] = {
  "idle", "to-src-approach", "descend-src", "close-tool", "dwell-close",
  "lift", "traverse", "descend-dst", "open-tool", "dwell-open",
  "retreat"
};

enum { PICK_KIND_MOVE = 0, PICK_KIND_TOOL, PICK_KIND_DWELL };

static signed char s_obj = -1;
static signed char s_stage = PICK_ST_IDLE;
static signed char s_kind = PICK_KIND_DWELL;
static unsigned long s_stageStartMs = 0;
static unsigned short s_stageMs = 0;

static double s_fromX = 0.0, s_fromY = 0.0, s_fromZ = 0.0;
static double s_toX = 0.0, s_toY = 0.0, s_toZ = 0.0;

#ifdef __AVR__
#define PICK_COORD(tab, field) ((double)pgm_read_float((const float *)&(tab)->field))
#else
#define PICK_COORD(tab, field) ((double)((tab)->field))
#endif

static void loadPickPoint(const struct pickPoint *tab, double *out) {
  out[0] = PICK_COORD(tab, x);
  out[1] = PICK_COORD(tab, y);
  out[2] = PICK_COORD(tab, z);
}

static double pickRateDps(void) {
  int level = speedGetLevel();
  if (level == SPEED_SLOW) return PICK_RATE_SLOW_DPS;
  if (level == SPEED_FAST) return PICK_RATE_FAST_DPS;
  return PICK_RATE_NORMAL_DPS;
}

static unsigned long __attribute__((noinline, noclone))
durationMs(double degrees, double rateDps) {
  double ms = 0.0;
  if (degrees > 0.0 && rateDps > 0.0) {
    ms = degrees / rateDps * 1000.0;
  }
  if (ms < (double)PICK_MIN_SEG_MS) ms = (double)PICK_MIN_SEG_MS;
  if (ms > (double)PICK_MAX_SEG_MS) ms = (double)PICK_MAX_SEG_MS;
  return (unsigned long)(ms + 0.5);
}

static void beginMove(int stage, const double *p, int rise) {
  s_stage = (signed char)stage;
  s_kind = PICK_KIND_MOVE;
  s_fromX = Pos.rec.x;
  s_fromY = Pos.rec.y;
  s_fromZ = Pos.rec.z;
  s_toX = p[0];
  s_toY = p[1];
  s_toZ = rise ? (p[2] + PICK_APPROACH_DZ) : p[2];
  s_stageStartMs = millis();

  double dMax = 0.0;
  double b = 0.0, r = 0.0, c = 0.0;
  if (pathCoreSolveJoint(s_toX, s_toY, s_toZ, &b, &r, &c)) {
    double d;
    d = fabs(b - Pos.ser.angle1); if (d > dMax) dMax = d;
    d = fabs(r - Pos.ser.angle2); if (d > dMax) dMax = d;
    d = fabs(c - Pos.ser.angle3); if (d > dMax) dMax = d;
  }
  s_stageMs = (unsigned short)durationMs(dMax, pickRateDps());
}

static void __attribute__((noinline, noclone))
beginTool(int stage, double targetAngle) {
  s_stage = (signed char)stage;
  s_kind = PICK_KIND_TOOL;
  s_fromX = Pos.ser.angle4;
  s_toX = targetAngle;
  s_stageStartMs = millis();
  s_stageMs = (unsigned short)durationMs(fabs(s_toX - s_fromX), PICK_TOOL_RATE_DPS);
}

static void beginDwell(int stage, unsigned long ms) {
  s_stage = (signed char)stage;
  s_kind = PICK_KIND_DWELL;
  s_stageStartMs = millis();
  s_stageMs = (unsigned short)ms;
}

static void finishSequence(void) {
#if WEARM_DEBUG_SERIAL
  Serial.print(F("[pick] "));
  Serial.print(PICK_LETTER[s_obj]);
  Serial.print(F(" done, retreat pos = ("));
  Serial.print(Pos.rec.x, 2);
  Serial.print(F(", "));
  Serial.print(Pos.rec.y, 2);
  Serial.print(F(", "));
  Serial.print(Pos.rec.z, 2);
  Serial.println(F(")"));
#endif
  s_obj = -1;
  s_stage = PICK_ST_IDLE;
  s_kind = PICK_KIND_DWELL;
  s_stageMs = 0;
  s_stageStartMs = millis();
}

#if WEARM_DEBUG_SERIAL
static void abortSequence(const __FlashStringHelper *why) {
  Serial.print(F("[pick] ERROR: "));
  Serial.print(why);
  Serial.println(F(", sequence aborted (arm holds position)"));
  s_obj = -1;
  s_stage = PICK_ST_IDLE;
  s_kind = PICK_KIND_DWELL;
  s_stageMs = 0;
  s_stageStartMs = millis();
}
#define PICK_ABORT(msg) abortSequence(F(msg))
#else
static void abortSequence(void) {
  s_obj = -1;
  s_stage = PICK_ST_IDLE;
  s_kind = PICK_KIND_DWELL;
  s_stageMs = 0;
  s_stageStartMs = millis();
}
#define PICK_ABORT(msg) abortSequence()
#endif

static void advanceStage(void) {
  double src[3], dst[3];
  loadPickPoint(&PICK_SRC[s_obj], src);
  loadPickPoint(&PICK_DST[s_obj], dst);

  switch (s_stage) {
    case PICK_ST_TO_SRC_APPROACH:
      beginMove(PICK_ST_DESCEND_SRC, src, 0);
      break;

    case PICK_ST_DESCEND_SRC:
      beginTool(PICK_ST_CLOSE_TOOL, PICK_TOOL_CLOSE_ANGLE);
      break;

    case PICK_ST_CLOSE_TOOL:
#if WEARM_DEBUG_SERIAL
      Serial.print(F("[pick] gripper closed at angle4 = "));
      Serial.println(Pos.ser.angle4);
#endif
      beginDwell(PICK_ST_DWELL_CLOSE, PICK_DWELL_MS);
      break;

    case PICK_ST_DWELL_CLOSE:
      beginMove(PICK_ST_LIFT, src, 1);
      break;

    case PICK_ST_LIFT:
      beginMove(PICK_ST_TRAVERSE, dst, 1);
      break;

    case PICK_ST_TRAVERSE:
      beginMove(PICK_ST_DESCEND_DST, dst, 0);
      break;

    case PICK_ST_DESCEND_DST:
      beginTool(PICK_ST_OPEN_TOOL, PICK_TOOL_OPEN_ANGLE);
      break;

    case PICK_ST_OPEN_TOOL:
#if WEARM_DEBUG_SERIAL
      Serial.print(F("[pick] gripper opened at angle4 = "));
      Serial.println(Pos.ser.angle4);
#endif
      beginDwell(PICK_ST_DWELL_OPEN, PICK_DWELL_MS);
      break;

    case PICK_ST_DWELL_OPEN:
      beginMove(PICK_ST_RETREAT, dst, 1);
      break;

    case PICK_ST_RETREAT:
      finishSequence();
      break;

    default:
      PICK_ABORT("unexpected stage");
      break;
  }
}

int pickPlaceStart(int object) {
  if (object < 0 || object >= PICK_OBJECT_COUNT) return -1;

  if (s_obj >= 0) {
#if WEARM_DEBUG_SERIAL
    Serial.print(F("[pick] busy: "));
    Serial.print(PICK_LETTER[s_obj]);
    Serial.println(F(" still running, command ignored"));
#endif
    return -2;
  }

  double srcP[3], dstP[3], srcRiseP[3], dstRiseP[3];
  loadPickPoint(&PICK_SRC[object], srcP);
  loadPickPoint(&PICK_DST[object], dstP);
  srcRiseP[0] = srcP[0]; srcRiseP[1] = srcP[1]; srcRiseP[2] = srcP[2] + PICK_APPROACH_DZ;
  dstRiseP[0] = dstP[0]; dstRiseP[1] = dstP[1]; dstRiseP[2] = dstP[2] + PICK_APPROACH_DZ;

  double b = 0.0, r = 0.0, c = 0.0;
  if (!pathCorePointOk(Pos.rec.x, Pos.rec.y, Pos.rec.z, &b, &r, &c)) return -3;
  if (fabs(b - Pos.ser.angle1) > PICK_START_TOL_DEG ||
      fabs(r - Pos.ser.angle2) > PICK_START_TOL_DEG ||
      fabs(c - Pos.ser.angle3) > PICK_START_TOL_DEG) {
#if WEARM_DEBUG_SERIAL
    Serial.println(F("[pick] rejected: current pose is not on the ik branch of its own"
                     " coordinates, run posInit()/回到初始位姿后再试"));
#endif
    return -3;
  }

  double curP[3];
  curP[0] = Pos.rec.x; curP[1] = Pos.rec.y; curP[2] = Pos.rec.z;
  if (!pathCoreSegmentOk(curP, srcRiseP, PICK_PATH_SAMPLE_STEP,
                         PICK_PATH_SAMPLE_MAX, PICK_BRANCH_JUMP_DEG) ||
      !pathCoreSegmentOk(srcRiseP, srcP, PICK_PATH_SAMPLE_STEP,
                         PICK_PATH_SAMPLE_MAX, PICK_BRANCH_JUMP_DEG) ||
      !pathCoreSegmentOk(srcRiseP, dstRiseP, PICK_PATH_SAMPLE_STEP,
                         PICK_PATH_SAMPLE_MAX, PICK_BRANCH_JUMP_DEG) ||
      !pathCoreSegmentOk(dstRiseP, dstP, PICK_PATH_SAMPLE_STEP,
                         PICK_PATH_SAMPLE_MAX, PICK_BRANCH_JUMP_DEG)) {
#if WEARM_DEBUG_SERIAL
    Serial.print(F("[pick] rejected: path check failed for "));
    Serial.println(PICK_LETTER[object]);
#endif
    return -3;
  }

  s_obj = (signed char)object;
#if WEARM_DEBUG_SERIAL
  Serial.print(F("[pick] start "));
  Serial.print(PICK_LETTER[object]);
  Serial.print(F(": src=("));
  Serial.print(srcP[0], 2);
  Serial.print(F(", "));
  Serial.print(srcP[1], 2);
  Serial.print(F(", "));
  Serial.print(srcP[2], 2);
  Serial.print(F(") dst=("));
  Serial.print(dstP[0], 2);
  Serial.print(F(", "));
  Serial.print(dstP[1], 2);
  Serial.print(F(", "));
  Serial.print(dstP[2], 2);
  Serial.print(F(") speed="));
  Serial.println(speedLevelName(speedGetLevel()));
#endif

  beginMove(PICK_ST_TO_SRC_APPROACH, srcP, 1);
  return 0;
}

void pickPlaceLoop(void) {
  if (s_obj < 0 || s_stage == PICK_ST_IDLE) return;

  unsigned long elapsed = millis() - s_stageStartMs;
  bool stageDone = (elapsed >= s_stageMs);
  double t = 1.0;
  if (!stageDone && s_stageMs > 0) {
    t = (double)elapsed / (double)s_stageMs;
  }

  if (s_kind == PICK_KIND_MOVE) {
    double x = s_fromX + (s_toX - s_fromX) * t;
    double y = s_fromY + (s_toY - s_fromY) * t;
    double z = s_fromZ + (s_toZ - s_fromZ) * t;
    double b = 0.0, r = 0.0, c = 0.0;
    if (!pathCoreSolveJoint(x, y, z, &b, &r, &c)) {
      PICK_ABORT("ik failed mid-path");
      return;
    }
    pathCoreSetJoints(b, r, c);
  } else if (s_kind == PICK_KIND_TOOL) {
    (void) posSetAngle4(s_fromX + (s_toX - s_fromX) * t);
  } else {
  }

  if (stageDone) advanceStage();
}

bool pickPlaceIsBusy(void) {
  return s_obj >= 0;
}

int pickPlaceCurrentObject(void) {
  return s_obj;
}

const char *pickPlaceStageName(void) {
  return PICK_STAGE_NAME[s_stage];
}

bool pickPlaceGetSource(int object, double *x, double *y, double *z) {
  if (object < 0 || object >= PICK_OBJECT_COUNT) return false;
  if (x) *x = PICK_COORD(&PICK_SRC[object], x);
  if (y) *y = PICK_COORD(&PICK_SRC[object], y);
  if (z) *z = PICK_COORD(&PICK_SRC[object], z);
  return true;
}

bool pickPlaceGetTarget(int object, double *x, double *y, double *z) {
  if (object < 0 || object >= PICK_OBJECT_COUNT) return false;
  if (x) *x = PICK_COORD(&PICK_DST[object], x);
  if (y) *y = PICK_COORD(&PICK_DST[object], y);
  if (z) *z = PICK_COORD(&PICK_DST[object], z);
  return true;
}

double pickPlaceApproachDz(void) {
  return PICK_APPROACH_DZ;
}
#endif

#define DRAW_DEBUG_SERIAL WEARM_DEBUG_SERIAL

#if WEARM_ENABLE_DRAW

#define DRAW_PEN_Z_DEFAULT    12.0
#define DRAW_CENTER_X_DEFAULT 20.0
#define DRAW_CENTER_Y_DEFAULT  0.0
#define DRAW_HALF_DEFAULT      6.0
#define DRAW_PEN_Z_MIN        -5.0
#define DRAW_PEN_Z_MAX        30.0
#define DRAW_HALF_MIN          2.0
#define DRAW_HALF_MAX         12.0
#define DRAW_CENTER_LIMIT     35.0

#define DRAW_LIFT_DZ           4.0

#define DRAW_V_MAX             3.0
#define DRAW_ACCEL             6.0
#define DRAW_MAX_DPS          70.0
#define DRAW_HOME_DPS         50.0
#define DRAW_JOG_MAX_DPS     200.0
#define DRAW_STEP_MAX          0.02

#define DRAW_TICK_MAX_MS      50UL
#define DRAW_TEACH_START_DELAY_MS 700UL
#define DRAW_HOME_TOL_DEG      0.4

#define DRAW_PATH_SAMPLE_STEP  0.25
#define DRAW_PATH_SAMPLE_MAX  96
#define DRAW_BRANCH_JUMP_DEG  25.0

#define DRAW_POINT_TOL         0.8
#define DRAW_JOG_SCALE         0.5
#define DRAW_JOG_CENTER      512
#define DRAW_JOG_STEP_MAX      0.25
#define DRAW_JOG_STEP_MIN      0.02
#define DRAW_JOG_TOOL_ENABLE   0
#define DRAW_JOG_INVERT_X      0
#define DRAW_JOG_INVERT_Y      0
#define DRAW_JOG_INVERT_Z      0

struct drawVertex {
  double u;
  double v;
};

static const struct drawVertex SHAPE_LINE[2] PROGMEM = {
  { -1.0,  0.0 }, {  1.0,  0.0 }
};
static const struct drawVertex SHAPE_N[4] PROGMEM = {
  { -1.0, -1.0 }, { -1.0,  1.0 }, {  1.0, -1.0 }, {  1.0,  1.0 }
};
static const struct drawVertex SHAPE_TRIANGLE[4] PROGMEM = {
  { -1.0, -1.0 }, {  1.0, -1.0 }, {  0.0,  1.0 }, { -1.0, -1.0 }
};
static const struct drawVertex SHAPE_Z[4] PROGMEM = {
  { -1.0,  1.0 }, {  1.0,  1.0 }, { -1.0, -1.0 }, {  1.0, -1.0 }
};
static const struct drawVertex SHAPE_V[3] PROGMEM = {
  { -1.0,  1.0 }, {  0.0, -1.0 }, {  1.0,  1.0 }
};

static const char *const DRAW_TASK_NAME[DRAW_TASK_COUNT] = {
  "直线", "字母N", "三角形", "字母Z", "字母V", "五点折线", "五点曲线"
};

static const char *const DRAW_TASK_TAG[DRAW_TASK_COUNT] = {
  "LINE", "N", "TRI", "Z", "V", "POLY", "CURVE"
};

static const char *const DRAW_PHASE_NAME[] = {
  "空闲", "回待机", "抬笔移动", "落笔", "绘制中", "抬笔", "示教中", "准备绘制", "结束回待机"
};

static int8_t s_task     = DRAW_TASK_LINE;
static int8_t s_phase    = DRAW_PHASE_IDLE;
static bool s_paused   = false;
static int  s_lastRes  = PROTO_RES_NONE;
static unsigned long s_lastMs = 0UL;
static double s_dtSec  = 0.0;
static unsigned long s_applyMs = 0UL;

static double s_penZ    = DRAW_PEN_Z_DEFAULT;
static double s_centerX = DRAW_CENTER_X_DEFAULT;
static double s_centerY = DRAW_CENTER_Y_DEFAULT;
static double s_half    = DRAW_HALF_DEFAULT;

static double s_pts[DRAW_TEACH_MAX_POINTS][3];
static int8_t s_ptCount  = 0;
static bool   s_curved   = false;
static bool   s_isTeach  = false;
static double s_totalLen = 0.0;
static double s_ptArc[DRAW_TEACH_MAX_POINTS];

static double s_done = 0.0;
static double s_v    = 0.0;
static int8_t s_span = 0;
static double s_u    = 0.0;

static double s_mFrom[3], s_mTo[3];
static double s_mLen = 0.0, s_mDone = 0.0, s_mV = 0.0;
static int8_t s_nextAfterMove = DRAW_PHASE_IDLE;

enum { AFTER_HOME_IDLE = 0, AFTER_HOME_TRAVEL, AFTER_HOME_TEACH };

static double s_homeTarget[3] = { 0.0, 0.0, 0.0 };
static int8_t s_afterHome = AFTER_HOME_IDLE;

#define DRAW_STALL_LIMIT 500
static int    s_stallCount = 0;

static unsigned long s_pathStartMs = 0UL;
static unsigned long s_lastRunMs   = 0UL;
static int8_t s_hitCount  = 0;
static int8_t s_hitTotal  = 0;
static uint8_t s_ptHit = 0;

static unsigned long s_teachWaitMs = 0UL;
static unsigned long s_jogLastMs[4] = { 0UL, 0UL, 0UL, 0UL };

static inline bool pointOk(double x, double y, double z,
                           double *b, double *r, double *c) {
  return pathCorePointOk(x, y, z, b, r, c);
}

static inline void setJoints(double b, double r, double c) {
  pathCoreSetJoints(b, r, c);
}

static double drawClampDouble(double v, double lo, double hi)
{
  if (v < lo) return lo;
  if (v > hi) return hi;
  return v;
}

static double dist3(const double *a, const double *b)
{
  double dx = a[0] - b[0];
  double dy = a[1] - b[1];
  double dz = a[2] - b[2];
  return sqrt(dx * dx + dy * dy + dz * dz);
}

static int shapeTable(int task, const struct drawVertex **tbl)
{
  switch (task) {
    case DRAW_TASK_LINE:     *tbl = SHAPE_LINE;     return 2;
    case DRAW_TASK_N:        *tbl = SHAPE_N;        return 4;
    case DRAW_TASK_TRIANGLE: *tbl = SHAPE_TRIANGLE; return 4;
    case DRAW_TASK_Z:        *tbl = SHAPE_Z;        return 4;
    case DRAW_TASK_V:        *tbl = SHAPE_V;        return 3;
    default:                 *tbl = NULL;           return 0;
  }
}

static void buildShapePath(int task)
{
  const struct drawVertex *tbl = NULL;
  int n = shapeTable(task, &tbl);
  if (n > DRAW_TEACH_MAX_POINTS) n = DRAW_TEACH_MAX_POINTS;

  s_ptCount = (int8_t)n;
  s_curved  = false;
  s_isTeach = false;
  for (int i = 0; i < n; i++) {
    s_pts[i][0] = s_centerX + pgm_read_float(&tbl[i].u) * s_half;
    s_pts[i][1] = s_centerY + pgm_read_float(&tbl[i].v) * s_half;
    s_pts[i][2] = s_penZ;
  }
}

static double knotDelta(int a, int b)
{
  double d = dist3(s_pts[a], s_pts[b]);
  if (d < 1e-6) return 0.001;
  return sqrt(d);
}

static void curveSpan(int span, double u, double *p, double *d)
{
  int n = s_ptCount;
  int i = span;
  double dt = knotDelta(i, i + 1);

  double t1[3], t2[3];
  if (i == 0) {
    for (int k = 0; k < 3; k++) t1[k] = (s_pts[1][k] - s_pts[0][k]) / dt * dt;
  } else {
    double sum = knotDelta(i - 1, i) + dt;
    for (int k = 0; k < 3; k++) t1[k] = (s_pts[i + 1][k] - s_pts[i - 1][k]) / sum * dt;
  }
  if (i + 1 == n - 1) {
    for (int k = 0; k < 3; k++) t2[k] = (s_pts[n - 1][k] - s_pts[n - 2][k]) / dt * dt;
  } else {
    double sum = dt + knotDelta(i + 1, i + 2);
    for (int k = 0; k < 3; k++) t2[k] = (s_pts[i + 2][k] - s_pts[i][k]) / sum * dt;
  }

  double u2 = u * u;
  double u3 = u2 * u;
  double h01 = -2.0 * u3 + 3.0 * u2;
  double h00 =  1.0 - h01;
  double h10 =         u3 - 2.0 * u2 + u;
  double h11 =         u3 -       u2;
  double g10 =  3.0 * u2 - 4.0 * u + 1.0;
  double g11 =  3.0 * u2 - 2.0 * u;
  double e0  =  6.0 * u2 - 6.0 * u;
  double e1  = -e0;

  for (int k = 0; k < 3; k++) {
    double a0 = s_pts[i][k];
    double a1 = s_pts[i + 1][k];
    p[k] = h00 * a0 + h10 * t1[k] + h01 * a1 + h11 * t2[k];
    d[k] = e0 * a0 + g10 * t1[k] + e1 * a1 + g11 * t2[k];
  }
}

static void curvePoint(int span, double u, double *p)
{
  double d[3];
  curveSpan(span, u, p, d);
}

static double curveSpeed(int span, double u)
{
  double p[3], d[3];
  curveSpan(span, u, p, d);
  return sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]);
}

static void curveMeasure(void)
{
  const int SAMPLE_PER_SPAN = 64;
  double len = 0.0;
  double prev[3];
  curvePoint(0, 0.0, prev);

  s_ptArc[0] = 0.0;
  for (int span = 0; span < s_ptCount - 1; span++) {
    for (int k = 1; k <= SAMPLE_PER_SPAN; k++) {
      double u = (double)k / (double)SAMPLE_PER_SPAN;
      double cur[3];
      curvePoint(span, u, cur);
      len += dist3(prev, cur);
      prev[0] = cur[0]; prev[1] = cur[1]; prev[2] = cur[2];
    }
    s_ptArc[span + 1] = len;
  }
  s_totalLen = len;
}

static void polyMeasure(void)
{
  double acc = 0.0;
  s_ptArc[0] = 0.0;
  for (int i = 0; i < s_ptCount - 1; i++) {
    acc += dist3(s_pts[i], s_pts[i + 1]);
    s_ptArc[i + 1] = acc;
  }
  s_totalLen = acc;
}

static void measurePath(void)
{
  if (s_curved) curveMeasure();
  else          polyMeasure();
}

static double liftZFor(const double *pt)
{
  double z = pt[2] + DRAW_LIFT_DZ;
  while (z > pt[2]) {
    if (pointOk(pt[0], pt[1], z, NULL, NULL, NULL)) return z;
    z -= 0.5;
  }
  return pt[2];
}

static bool validatePath(void)
{
  if (s_ptCount < 2) return false;

  SER home;
  home = Pos.ser;
  if (!posGetHomeAngles(&home)) return false;
  REC hrec;
  if (!recFromServo(&hrec, &home)) return false;

  double lz = liftZFor(s_pts[0]);
  double hp[3];
  hp[0] = hrec.x; hp[1] = hrec.y; hp[2] = hrec.z;
  double ap[3];
  ap[0] = s_pts[0][0]; ap[1] = s_pts[0][1]; ap[2] = lz;
  if (!pathCoreSegmentOk(hp, ap, DRAW_PATH_SAMPLE_STEP,
                         DRAW_PATH_SAMPLE_MAX, DRAW_BRANCH_JUMP_DEG)) return false;

  if (!pathCoreSegmentOk(ap, s_pts[0], DRAW_PATH_SAMPLE_STEP,
                         DRAW_PATH_SAMPLE_MAX, DRAW_BRANCH_JUMP_DEG)) {
    return false;
  }

  if (s_curved) {
    const int SAMPLE_PER_SPAN = 24;
    double prevB = 0.0, prevR = 0.0, prevC = 0.0;
    bool first = true;
    for (int span = 0; span < s_ptCount - 1; span++) {
      for (int k = 0; k <= SAMPLE_PER_SPAN; k++) {
        double u = (double)k / (double)SAMPLE_PER_SPAN;
        double p[3];
        curvePoint(span, u, p);
        double b = 0.0, r = 0.0, c = 0.0;
        if (!pointOk(p[0], p[1], p[2], &b, &r, &c)) return false;
        if (!first) {
          if (fabs(b - prevB) > DRAW_BRANCH_JUMP_DEG ||
              fabs(r - prevR) > DRAW_BRANCH_JUMP_DEG ||
              fabs(c - prevC) > DRAW_BRANCH_JUMP_DEG) {
            return false;
          }
        }
        prevB = b; prevR = r; prevC = c;
        first = false;
      }
    }
  } else {
    for (int i = 0; i < s_ptCount - 1; i++) {
      if (!pathCoreSegmentOk(s_pts[i], s_pts[i + 1], DRAW_PATH_SAMPLE_STEP,
                             DRAW_PATH_SAMPLE_MAX, DRAW_BRANCH_JUMP_DEG)) {
        return false;
      }
    }
  }

  const double *last = s_pts[s_ptCount - 1];
  double ez = liftZFor(last);
  double ep[3];
  ep[0] = last[0]; ep[1] = last[1]; ep[2] = ez;
  if (!pathCoreSegmentOk(last, ep, DRAW_PATH_SAMPLE_STEP,
                         DRAW_PATH_SAMPLE_MAX, DRAW_BRANCH_JUMP_DEG)) {
    return false;
  }
  return true;
}

static double applyDtSec(void)
{
  unsigned long now = millis();
  double dt = (double)(now - s_applyMs) / 1000.0;
  if (dt > 0.1) dt = 0.1;
  if (dt < 0.005) dt = 0.005;
  return dt;
}

static bool applyPointStep(double x, double y, double z, double maxDps, double dtSec, int mode)
{
  const double goal[3] = { x, y, z };
  if (moveToPoint(goal, 0x07u, maxDps, dtSec, mode) != MOVE_XYZ_OK) return false;
  s_applyMs = millis();
  return true;
}

static double speedLimit(double done, double total, double vCur, double dt)
{
  double remain = total - done;
  if (remain < 0.0) remain = 0.0;

  double vEnd = sqrt(2.0 * DRAW_ACCEL * remain);
  if (vEnd > DRAW_V_MAX) vEnd = DRAW_V_MAX;

  double vRamp = vCur + DRAW_ACCEL * dt;
  double v = (vRamp < vEnd) ? vRamp : vEnd;
  if (v < 0.0) v = 0.0;
  return v;
}

static bool stallGuard(double movedNow)
{
  if (movedNow > 1e-6) {
    s_stallCount = 0;
    return false;
  }
  s_stallCount++;
  if (s_stallCount > DRAW_STALL_LIMIT) {
#if DRAW_DEBUG_SERIAL
    Serial.println(F("[draw] 无法继续前进（关节速率或可达性受限），放弃本次绘图"));
#endif
    s_stallCount = 0;
    s_paused = false;
    s_phase  = DRAW_PHASE_IDLE;
    s_lastRes = PROTO_RES_DRAW_REJECTED;
    return true;
  }
  return false;
}

static void loadHomeTarget(void)
{
  SER ser = Pos.ser;
  if (!posGetHomeAngles(&ser)) ser = Pos.ser;
  s_homeTarget[0] = ser.angle1;
  s_homeTarget[1] = ser.angle2;
  s_homeTarget[2] = ser.angle3;
}

static void beginHome(int after, int phase)
{
  loadHomeTarget();
  s_afterHome  = (int8_t)after;
  s_stallCount = 0;
  s_applyMs    = millis();
  s_phase = (int8_t)phase;
}

static void beginMove(int next, double x, double y, double z)
{
  s_mFrom[0] = Pos.rec.x;
  s_mFrom[1] = Pos.rec.y;
  s_mFrom[2] = Pos.rec.z;
  s_mTo[0] = x;
  s_mTo[1] = y;
  s_mTo[2] = z;
  s_mLen  = dist3(s_mFrom, s_mTo);
  s_mDone = 0.0;
  s_mV    = 0.0;
  s_applyMs = millis();
  s_nextAfterMove = (int8_t)next;
}

static void beginSequence(void)
{
  s_paused  = false;
  s_done    = 0.0;
  s_v       = 0.0;
  s_span    = 0;
  s_u       = 0.0;
  s_hitCount = 0;
  s_hitTotal = s_isTeach ? s_ptCount : 0;
  s_ptHit = 0;

  beginHome(AFTER_HOME_TRAVEL, DRAW_PHASE_HOME);
}

static bool homeTick(void)
{
  double maxStep = DRAW_HOME_DPS * s_dtSec;
  if (maxStep < 0.2) maxStep = 0.2;

  double tgt[3], cur[3], d[3];
  tgt[0] = s_homeTarget[0]; tgt[1] = s_homeTarget[1]; tgt[2] = s_homeTarget[2];
  cur[0] = Pos.ser.angle1;  cur[1] = Pos.ser.angle2;  cur[2] = Pos.ser.angle3;

  bool atHome = true;
  for (int i = 0; i < 3; i++) {
    d[i] = tgt[i] - cur[i];
    if (fabs(d[i]) > DRAW_HOME_TOL_DEG) atHome = false;
  }

  if (atHome) {
    setJoints(tgt[0], tgt[1], tgt[2]);
    return true;
  }

  setJoints(cur[0] + drawClampDouble(d[0], -maxStep, maxStep),
            cur[1] + drawClampDouble(d[1], -maxStep, maxStep),
            cur[2] + drawClampDouble(d[2], -maxStep, maxStep));
  return false;
}

static bool moveTick(void)
{
  if (s_mLen < 1e-6) return true;

  double v = speedLimit(s_mDone, s_mLen, s_mV, s_dtSec);
  double step = v * s_dtSec;
  if (step > s_mLen - s_mDone) step = s_mLen - s_mDone;

  double t = (s_mDone + step) / s_mLen;
  double x = s_mFrom[0] + (s_mTo[0] - s_mFrom[0]) * t;
  double y = s_mFrom[1] + (s_mTo[1] - s_mFrom[1]) * t;
  double z = s_mFrom[2] + (s_mTo[2] - s_mFrom[2]) * t;

  if (!applyPointStep(x, y, z, DRAW_MAX_DPS, applyDtSec(), MOVE_XYZ_TRACK)) {
    return false;
  }

  s_mDone += step;
  s_mV = (s_dtSec > 1e-6) ? (step / s_dtSec) : 0.0;
  return (s_mDone >= s_mLen - 1e-6);
}

static void polyPointAt(double s, double *px, double *py, double *pz)
{
  if (s <= 0.0) {
    *px = s_pts[0][0]; *py = s_pts[0][1]; *pz = s_pts[0][2];
    return;
  }
  double acc = 0.0;
  for (int i = 0; i < s_ptCount - 1; i++) {
    bool last = (i == s_ptCount - 2);
    double seg = dist3(s_pts[i], s_pts[i + 1]);
    if (s <= acc + seg || last) {
      double t = (seg > 1e-9) ? (s - acc) / seg : 1.0;
      t = drawClampDouble(t, 0.0, 1.0);
      *px = s_pts[i][0] + (s_pts[i + 1][0] - s_pts[i][0]) * t;
      *py = s_pts[i][1] + (s_pts[i + 1][1] - s_pts[i][1]) * t;
      *pz = s_pts[i][2] + (s_pts[i + 1][2] - s_pts[i][2]) * t;
      return;
    }
    acc += seg;
  }
}

static bool pathAdvance(double step)
{
  if (step <= 0.0) return true;
  if (step > s_totalLen - s_done) step = s_totalLen - s_done;

  double tryStep = step;
  for (int attempt = 0; attempt < 4; attempt++) {
    double p[3] = { 0.0, 0.0, 0.0 };
    int    nspan = s_span;
    double nu    = s_u;

    if (s_curved) {
      double sp = curveSpeed(s_span, s_u);
      double du = (sp > 1e-6) ? (tryStep / sp) : 1.0;
      nu = s_u + du;
      while (nu >= 1.0 && nspan < s_ptCount - 2) { nu -= 1.0; nspan++; }
      if (nu > 1.0) nu = 1.0;
      curvePoint(nspan, nu, p);
    } else {
      polyPointAt(s_done + tryStep, &p[0], &p[1], &p[2]);
    }

    if (applyPointStep(p[0], p[1], p[2], DRAW_MAX_DPS, applyDtSec(), MOVE_XYZ_TRACK)) {
      s_done += tryStep;
      s_span  = (int8_t)nspan;
      s_u     = nu;
      s_v     = (s_dtSec > 1e-6) ? (tryStep / s_dtSec) : 0.0;
      return true;
    }
    tryStep *= 0.5;
  }
  return false;
}

static void pathTick(void)
{
  double remain = s_totalLen - s_done;
  double v = speedLimit(s_done, s_totalLen, s_v, s_dtSec);
  double step = v * s_dtSec;
  if (step > remain) step = remain;

  if (step > DRAW_STEP_MAX) step = DRAW_STEP_MAX;
  (void) pathAdvance(step);

  for (int i = 0; i < s_ptCount; i++) {
    uint8_t bit = (uint8_t)(1u << i);
    if (s_ptHit & bit) continue;
    if (s_done + 1e-6 < s_ptArc[i]) continue;
    double dx = Pos.rec.x - s_pts[i][0];
    double dy = Pos.rec.y - s_pts[i][1];
    double dz = Pos.rec.z - s_pts[i][2];
    if (sqrt(dx * dx + dy * dy + dz * dz) <= DRAW_POINT_TOL) {
      s_ptHit |= bit;
      s_hitCount++;
    }
  }
}

static void beginLift(double z)
{
  beginMove(DRAW_PHASE_LIFT, Pos.rec.x, Pos.rec.y, z);
}

static void beginLiftToReturn(void)
{
  double lz = Pos.rec.z + DRAW_LIFT_DZ;
  if (!pointOk(Pos.rec.x, Pos.rec.y, lz, NULL, NULL, NULL)) lz = Pos.rec.z;
  beginLift(lz);
  s_nextAfterMove = DRAW_PHASE_RETURN;
  s_phase = DRAW_PHASE_LIFT;
}

static void teachJogTick(void)
{
  struct joyState st;
  joystickReadState(&st);

  unsigned long now = millis();
  const int amp[4]   = { st.base, st.shoulder, st.elbow, st.tool };
  const int raw[4]   = { st.sx,   st.sy,        st.ty,      st.tx };

  for (int i = 0; i < 4; i++) {
    if (amp[i] <= 0) continue;
#if !DRAW_JOG_TOOL_ENABLE
    if (i == 3) continue;
#endif
    int interval = speed.stepDelayMs;
    if (now - s_jogLastMs[i] < (unsigned long)interval) continue;
    s_jogLastMs[i] = now;

    int sign = (raw[i] > DRAW_JOG_CENTER) ? 1 : -1;

    if (i == 3) {
      double deg = speed.stepSize * DRAW_JOG_SCALE *
                   ((double)amp[i] / (double)DRAW_JOG_CENTER);
      if (deg < 0.05) deg = 0.05;
      (void) posSetAngle4(Pos.ser.angle4 - (double)sign * deg);
      continue;
    }

    double step = DRAW_JOG_STEP_MAX * ((double)amp[i] / (double)DRAW_JOG_CENTER);
    if (step < DRAW_JOG_STEP_MIN) step = DRAW_JOG_STEP_MIN;

    double nx = Pos.rec.x;
    double ny = Pos.rec.y;
    double nz = Pos.rec.z;
    if (i == 0) {
      int dir = DRAW_JOG_INVERT_X ? -sign : sign;
      nx += (double)dir * step;
    } else if (i == 1) {
      int dir = DRAW_JOG_INVERT_Y ? -sign : sign;
      ny += (double)dir * step;
    } else {
      int dir = DRAW_JOG_INVERT_Z ? sign : -sign;
      nz += (double)dir * step;
    }

    if (!applyPointStep(nx, ny, nz, DRAW_JOG_MAX_DPS, (double)interval / 1000.0, MOVE_XYZ_JOG)) {
#if DRAW_DEBUG_SERIAL
      Serial.println(F("[draw] 点动被挡：该方向不可达或超出工作空间"));
#endif
    }
  }
}

static int teachRecord(void)
{
  if (s_ptCount >= DRAW_TEACH_MAX_POINTS) return PROTO_RES_BUSY;

  s_pts[s_ptCount][0] = Pos.rec.x;
  s_pts[s_ptCount][1] = Pos.rec.y;
  s_pts[s_ptCount][2] = Pos.rec.z;
  s_ptCount++;

#if DRAW_DEBUG_SERIAL
  Serial.print(F("[draw] 记录示教点 "));
  Serial.print((int)s_ptCount);
  Serial.print(F("/"));
  Serial.print(DRAW_TEACH_MAX_POINTS);
  Serial.print(F("  x="));
  Serial.print(s_pts[s_ptCount - 1][0], 2);
  Serial.print(F(" y="));
  Serial.print(s_pts[s_ptCount - 1][1], 2);
  Serial.print(F(" z="));
  Serial.println(s_pts[s_ptCount - 1][2], 2);
#endif

  if (s_ptCount >= DRAW_TEACH_MAX_POINTS) {
    s_teachWaitMs = millis();
    s_phase = DRAW_PHASE_TEACH_WAIT;
  }
  return PROTO_RES_DRAW_TEACH_POINT;
}

static int teachFinish(void)
{
  if (s_ptCount < 2) return PROTO_RES_DRAW_REJECTED;

  s_curved = (s_task == DRAW_TASK_CURVE);
  measurePath();
  if (!validatePath()) {
#if DRAW_DEBUG_SERIAL
    Serial.println(F("[draw] 轨迹校验失败，拒绝开始绘制"));
#endif
    return PROTO_RES_DRAW_REJECTED;
  }
  beginSequence();
  return PROTO_RES_DRAW_STARTED;
}

void drawSetup(void)
{
  s_task   = DRAW_TASK_LINE;
  s_phase  = DRAW_PHASE_IDLE;
  s_paused = false;
  s_lastMs = millis();
  s_applyMs = s_lastMs;
  s_lastRes = PROTO_RES_NONE;
  s_ptCount = 0;
  s_curved  = false;
  s_isTeach = false;

#if DRAW_DEBUG_SERIAL
  Serial.println(F("[draw] 绘图模块就绪（铅笔固定方案）："));
  Serial.print(F("[draw]   当前任务 "));
  Serial.print(DRAW_TASK_NAME[s_task]);
  Serial.print(F("，纸面 z="));
  Serial.print(s_penZ, 2);
  Serial.print(F("，中心 ("));
  Serial.print(s_centerX, 2);
  Serial.print(F(","));
  Serial.print(s_centerY, 2);
  Serial.print(F(")，半宽 "));
  Serial.println(s_half, 2);
  Serial.println(F("[draw]   按键: 示教中 1=记录 2=撤销 3=取消 4=开始；绘制中 1=暂停 2=继续 3=取消"));
  Serial.println(F("[draw]   串口: F 换任务  D 开始  G 记录  E 撤销  Q 暂停  U 继续  W 取消"));
  Serial.println(F("[draw]   标定: p<纸面高>  n<半宽>  o<中心x>,<中心y>"));
#endif
}

int drawSelectTask(int task)
{
  if (task < 0 || task >= DRAW_TASK_COUNT) return -1;
  if (s_phase != DRAW_PHASE_IDLE) return -1;
  s_task = (int8_t)task;
  return s_task;
}

int drawTaskCycle(void)
{
  if (s_phase != DRAW_PHASE_IDLE) return -1;
  s_task = (int8_t)((s_task + 1) % DRAW_TASK_COUNT);
  return s_task;
}

int drawGetTask(void) { return s_task; }

const char *drawTaskName(int task)
{
  if (task < 0 || task >= DRAW_TASK_COUNT) return "未知";
  return DRAW_TASK_NAME[task];
}

const char *drawTaskTag(int task)
{
  if (task < 0 || task >= DRAW_TASK_COUNT) return "?";
  return DRAW_TASK_TAG[task];
}

int drawStartTask(void)
{
  s_lastRes = PROTO_RES_BUSY;

  if (s_phase != DRAW_PHASE_IDLE) {
#if DRAW_DEBUG_SERIAL
    Serial.println(F("[draw] 忙：先取消当前绘图任务再开始新的"));
#endif
    return PROTO_RES_BUSY;
  }
  if (pickPlaceIsBusy() || buttonControlBusy()) {
#if DRAW_DEBUG_SERIAL
    Serial.println(F("[draw] 忙：取放序列或按键录制/播放/回中正在进行"));
#endif
    return PROTO_RES_BUSY;
  }

  s_paused  = false;
  s_isTeach = (s_task == DRAW_TASK_POLYLINE || s_task == DRAW_TASK_CURVE);

  if (s_isTeach) {
    s_ptCount = 0;
    s_curved  = (s_task == DRAW_TASK_CURVE);
    beginHome(AFTER_HOME_TEACH, DRAW_PHASE_HOME);
#if DRAW_DEBUG_SERIAL
    Serial.print(F("[draw] 进入示教（"));
    Serial.print(DRAW_TASK_NAME[s_task]);
    Serial.print(F("），用摇杆把笔尖移到目标点，按键1 记录，共 "));
    Serial.print(DRAW_TEACH_MAX_POINTS);
    Serial.println(F(" 个点"));
#endif
    s_lastRes = PROTO_RES_DRAW_STARTED;
    return PROTO_RES_DRAW_STARTED;
  }

  buildShapePath(s_task);
  measurePath();
  if (!validatePath()) {
#if DRAW_DEBUG_SERIAL
    Serial.println(F("[draw] 轨迹校验失败，拒绝开始绘制"));
#endif
    s_lastRes = PROTO_RES_DRAW_REJECTED;
    return PROTO_RES_DRAW_REJECTED;
  }
  beginSequence();
#if DRAW_DEBUG_SERIAL
  Serial.print(F("[draw] 开始绘制 "));
  Serial.print(DRAW_TASK_NAME[s_task]);
  Serial.print(F("：总弧长 "));
  Serial.print(s_totalLen, 2);
  Serial.println(F(" 单位"));
#endif
  s_lastRes = PROTO_RES_DRAW_STARTED;
  return PROTO_RES_DRAW_STARTED;
}

int drawTeachRecord(void)
{
  if (s_phase != DRAW_PHASE_TEACH) {
    s_lastRes = PROTO_RES_BUSY;
    return PROTO_RES_BUSY;
  }
  s_lastRes = teachRecord();
  return s_lastRes;
}

int drawTeachUndo(void)
{
  if (s_phase != DRAW_PHASE_TEACH || s_ptCount <= 0) {
    s_lastRes = PROTO_RES_DRAW_REJECTED;
    return PROTO_RES_DRAW_REJECTED;
  }
  s_ptCount--;
#if DRAW_DEBUG_SERIAL
  Serial.print(F("[draw] 撤销一个示教点，剩 "));
  Serial.println((int)s_ptCount);
#endif
  s_lastRes = PROTO_RES_DRAW_TEACH_UNDO;
  return PROTO_RES_DRAW_TEACH_UNDO;
}

int drawTeachFinish(void)
{
  if (s_phase != DRAW_PHASE_TEACH && s_phase != DRAW_PHASE_TEACH_WAIT) {
    s_lastRes = PROTO_RES_BUSY;
    return PROTO_RES_BUSY;
  }
  s_lastRes = teachFinish();
  return s_lastRes;
}

int drawTeachCount(void) { return s_ptCount; }

int drawPause(void)
{
  if (s_phase == DRAW_PHASE_IDLE || s_phase == DRAW_PHASE_TEACH ||
      s_phase == DRAW_PHASE_TEACH_WAIT) {
    s_lastRes = PROTO_RES_BUSY;
    return PROTO_RES_BUSY;
  }
  s_paused = true;
#if DRAW_DEBUG_SERIAL
  Serial.println(F("[draw] 已暂停（按键2 继续，按键3 取消）"));
#endif
  s_lastRes = PROTO_RES_DRAW_PAUSED;
  return PROTO_RES_DRAW_PAUSED;
}

int drawResume(void)
{
  if (!s_paused) {
    s_lastRes = PROTO_RES_BUSY;
    return PROTO_RES_BUSY;
  }
  s_paused = false;
  s_v      = 0.0;
  s_mV     = 0.0;
#if DRAW_DEBUG_SERIAL
  Serial.println(F("[draw] 继续绘制"));
#endif
  s_lastRes = PROTO_RES_DRAW_RESUMED;
  return PROTO_RES_DRAW_RESUMED;
}

int drawCancel(void)
{
  if (s_phase == DRAW_PHASE_IDLE) {
    s_lastRes = PROTO_RES_BUSY;
    return PROTO_RES_BUSY;
  }
  s_paused = false;

  if (s_phase == DRAW_PHASE_TEACH || s_phase == DRAW_PHASE_TEACH_WAIT) {
    s_ptCount = 0;
    beginHome(AFTER_HOME_IDLE, DRAW_PHASE_HOME);
  } else {
    beginLiftToReturn();
  }
#if DRAW_DEBUG_SERIAL
  Serial.println(F("[draw] 已取消：抬笔后回待机"));
#endif
  s_lastRes = PROTO_RES_DRAW_CANCELED;
  return PROTO_RES_DRAW_CANCELED;
}

bool drawSetPaperZ(double z)
{
  if (z != z) return false;
  if (z < DRAW_PEN_Z_MIN || z > DRAW_PEN_Z_MAX) return false;
  s_penZ = z;
  return true;
}
double drawGetPaperZ(void) { return s_penZ; }

bool drawSetHalfSize(double half)
{
  if (half != half) return false;
  if (half < DRAW_HALF_MIN || half > DRAW_HALF_MAX) return false;
  s_half = half;
  return true;
}
double drawGetHalfSize(void) { return s_half; }

bool drawSetCenter(double x, double y)
{
  if (x != x || y != y) return false;
  if (fabs(x) > DRAW_CENTER_LIMIT || fabs(y) > DRAW_CENTER_LIMIT) return false;
  s_centerX = x;
  s_centerY = y;
  return true;
}
double drawGetCenterX(void) { return s_centerX; }
double drawGetCenterY(void) { return s_centerY; }

int drawHandleButton(int key)
{
  switch (key) {
    case DRAW_KEY_1:
      if (s_phase == DRAW_PHASE_TEACH)  return drawTeachRecord();
      if (s_phase == DRAW_PHASE_TEACH_WAIT) return PROTO_RES_BUSY;
      return drawPause();
    case DRAW_KEY_2:
      if (s_phase == DRAW_PHASE_TEACH)  return drawTeachUndo();
      if (s_phase == DRAW_PHASE_TEACH_WAIT) return PROTO_RES_BUSY;
      return drawResume();
    case DRAW_KEY_3:
      return drawCancel();
    case DRAW_KEY_4:
      if (s_phase == DRAW_PHASE_TEACH || s_phase == DRAW_PHASE_TEACH_WAIT) {
        return drawTeachFinish();
      }
#if DRAW_DEBUG_SERIAL
      Serial.println(F("[draw] 绘制中按键4 无动作（按键1 暂停 / 2 继续 / 3 取消）"));
#endif
      return PROTO_RES_BUSY;
    default:
      return PROTO_RES_UNKNOWN;
  }
}

bool drawAcceptButton(int key)
{
  (void) key;
  return (s_phase != DRAW_PHASE_IDLE);
}

bool drawIsCommandChar(char c)
{
  return (c == 'F' || c == 'D' || c == 'G' || c == 'E' ||
          c == 'Q' || c == 'U' || c == 'W' ||
          c == 'p' || c == 'n' || c == 'o');
}

int drawHandleCommand(char c)
{
  switch (c) {
    case 'F': {
      int t = drawTaskCycle();
      if (t < 0) {
        s_lastRes = PROTO_RES_BUSY;
        return PROTO_RES_BUSY;
      }
#if DRAW_DEBUG_SERIAL
      Serial.print(F("[draw] 当前任务 -> "));
      Serial.println(DRAW_TASK_NAME[t]);
#endif
      s_lastRes = PROTO_RES_DRAW_TASK_SELECTED;
      return PROTO_RES_DRAW_TASK_SELECTED;
    }
    case 'D':
      return drawStartTask();
    case 'G':
      return drawTeachRecord();
    case 'E':
      return drawTeachUndo();
    case 'Q':
      return drawPause();
    case 'U':
      return drawResume();
    case 'W':
      return drawCancel();
    default:
      return PROTO_RES_UNKNOWN;
  }
}

bool drawControlBusy(void)  { return (s_phase != DRAW_PHASE_IDLE); }
bool drawControlLocked(void) { return (s_phase != DRAW_PHASE_IDLE); }
int  drawGetPhase(void)     { return s_phase; }
bool drawIsPaused(void)     { return s_paused; }

const char *drawPhaseName(void)
{
  if (s_phase < 0 || s_phase > DRAW_PHASE_RETURN) return "未知";
  return DRAW_PHASE_NAME[s_phase];
}

const char *drawStateName(void)
{
  if (s_phase == DRAW_PHASE_IDLE) return "空闲";
  if (s_phase == DRAW_PHASE_TEACH) return "示教中";
  if (s_phase == DRAW_PHASE_TEACH_WAIT) return "准备绘制";
  if (s_paused) return "已暂停";
  return DRAW_PHASE_NAME[s_phase];
}

unsigned long drawLastRunMs(void) { return s_lastRunMs; }
int drawLastPointsHit(void)   { return s_hitCount; }
int drawLastPointsTotal(void) { return s_hitTotal; }
int drawLastResult(void)      { return s_lastRes; }

void drawLoop(void)
{
  unsigned long now = millis();
  unsigned long dtMs = now - s_lastMs;
  if (dtMs == 0UL) return;
  s_lastMs = now;
  if (dtMs > DRAW_TICK_MAX_MS) dtMs = DRAW_TICK_MAX_MS;
  s_dtSec = (double)dtMs / 1000.0;

  if (s_phase == DRAW_PHASE_IDLE) return;

  if (s_phase == DRAW_PHASE_TEACH) {
    teachJogTick();
    return;
  }

  if (s_phase == DRAW_PHASE_TEACH_WAIT) {
    if (now - s_teachWaitMs >= DRAW_TEACH_START_DELAY_MS) {
      s_lastRes = teachFinish();
      if (s_lastRes != PROTO_RES_DRAW_STARTED) {
        s_phase = DRAW_PHASE_IDLE;
      }
    }
    return;
  }

  if (s_paused) return;

  switch (s_phase) {
    case DRAW_PHASE_HOME: {
      if (homeTick()) {
        if (s_afterHome == AFTER_HOME_TEACH) {
          s_phase = DRAW_PHASE_TEACH;
        } else if (s_afterHome == AFTER_HOME_IDLE) {
          s_phase = DRAW_PHASE_IDLE;
        } else {
          double lz = liftZFor(s_pts[0]);
          beginMove(DRAW_PHASE_PLUNGE, s_pts[0][0], s_pts[0][1], lz);
          s_phase = DRAW_PHASE_TRAVEL;
        }
      }
      break;
    }

    case DRAW_PHASE_TRAVEL:
    case DRAW_PHASE_PLUNGE:
    case DRAW_PHASE_LIFT: {
      double px = Pos.rec.x, py = Pos.rec.y, pz = Pos.rec.z;
      bool arrived = moveTick();
      double moved = fabs(Pos.rec.x - px) + fabs(Pos.rec.y - py) + fabs(Pos.rec.z - pz);
      if (!arrived) {
        (void) stallGuard(moved);
        break;
      }
      if (s_phase == DRAW_PHASE_TRAVEL) {
        beginMove(DRAW_PHASE_PATH, s_pts[0][0], s_pts[0][1], s_pts[0][2]);
        s_phase = DRAW_PHASE_PLUNGE;
      } else if (s_phase == DRAW_PHASE_PLUNGE) {
        s_done = 0.0;
        s_v    = 0.0;
        s_span = 0;
        s_u    = 0.0;
        s_stallCount = 0;
        s_pathStartMs = millis();
        s_phase = DRAW_PHASE_PATH;
      } else {
        if (s_nextAfterMove == DRAW_PHASE_RETURN) {
          beginHome(AFTER_HOME_IDLE, DRAW_PHASE_RETURN);
        } else {
          s_phase = s_nextAfterMove;
        }
      }
      break;
    }

    case DRAW_PHASE_PATH: {
      double doneBefore = s_done;
      pathTick();
      if (stallGuard(s_done - doneBefore)) break;
      if (s_done >= s_totalLen - 1e-6) {
        s_lastRunMs = millis() - s_pathStartMs;
#if DRAW_DEBUG_SERIAL
        Serial.print(F("[draw] 绘制完成：用时 "));
        Serial.print(s_lastRunMs);
        Serial.print(F(" ms，笔尖停在 x="));
        Serial.print(Pos.rec.x, 2);
        Serial.print(F(" y="));
        Serial.print(Pos.rec.y, 2);
        Serial.print(F(" z="));
        Serial.println(Pos.rec.z, 2);
        if (s_isTeach) {
          Serial.print(F("[draw] 过点 "));
          Serial.print((int)s_hitCount);
          Serial.print(F("/"));
          Serial.println((int)s_hitTotal);
        }
#endif
        beginLiftToReturn();
      }
      break;
    }

    case DRAW_PHASE_RETURN: {
      if (homeTick()) {
#if DRAW_DEBUG_SERIAL
        Serial.println(F("[draw] 已回到待机位，绘图任务结束"));
#endif
        s_phase = DRAW_PHASE_IDLE;
      }
      break;
    }

    default:
      s_phase = DRAW_PHASE_IDLE;
      break;
  }
}

#endif

#if WEARM_ENABLE_BUTTONS

#if WEARM_BUTTON_PINS
#define BTN_PIN_CYCLE   2
#define BTN_PIN_RECORD  3
#define BTN_PIN_PLAY    4
#define BTN_PIN_HOME    5
#endif

#define BTN_DEBOUNCE_MS     25UL
#define BTN_TICK_MS         ((unsigned long) WEARM_REC_TICK_MS)
#define BTN_RAMP_MS         1500UL
#define BTN_REC_MIN_TRAVEL  10.0
#define BTN_REC_ENTRIES     WEARM_REC_ENTRIES
#define BTN_REC_BYTES       4
#define BTN_REC_LIMIT       128
#define BTN_ANGLE_UNIT      2.0
#define BTN_PLAY_SUBSTEPS   4

#if WEARM_BUTTON_PINS
static const uint8_t BTN_PIN[BTN_COUNT] = {
  BTN_PIN_CYCLE, BTN_PIN_RECORD, BTN_PIN_PLAY, BTN_PIN_HOME
};
#endif

static uint8_t s_buf[BTN_REC_ENTRIES * BTN_REC_BYTES];

enum { BS_IDLE = 0, BS_RAMP, BS_PLAY };

static uint8_t s_state       = BS_IDLE;
static uint8_t s_cycleIdx    = 0;
static bool    s_recording   = false;
static bool    s_rampThenPlay = false;

static uint16_t      s_recCount     = 0;
static uint16_t      s_recLen       = 0;
static bool          s_hasRec       = false;
static bool          s_recOverflow  = false;
static unsigned long s_recStartMs    = 0;
static unsigned long s_recDurationMs = 0;
static unsigned long s_tickNow       = 0;
static double        s_snap[4]      = {0.0, 0.0, 0.0, 0.0};
static double        s_recStart[4]  = {0.0, 0.0, 0.0, 0.0};
static double        s_recTravel    = 0.0;
static double        s_bbMin[3]     = {0.0, 0.0, 0.0};
static double        s_bbMax[3]     = {0.0, 0.0, 0.0};

static double        s_rampFrom[4] = {0.0, 0.0, 0.0, 0.0};
static double        s_rampTo[4]   = {0.0, 0.0, 0.0, 0.0};
static unsigned long s_rampStartMs = 0;

static uint16_t      s_playIdx   = 0;
static unsigned long s_playDueMs = 0;
static uint8_t       s_subIdx    = 0;
static double        s_subDelta[4]   = {0.0, 0.0, 0.0, 0.0};
static double        s_subApplied[4] = {0.0, 0.0, 0.0, 0.0};

#if WEARM_BUTTON_PINS
static bool          s_btnStable[BTN_COUNT] = {false, false, false, false};
static bool          s_btnArmed[BTN_COUNT]  = {false, false, false, false};
static unsigned long s_btnChangeAt[BTN_COUNT] = {0UL, 0UL, 0UL, 0UL};
#endif

static double *btnAngle(int joint) {
  return &Pos.ser.angle1 + joint;
}

static void btnCommitAngles(void) {
  SER tmp = Pos.ser;
  if (tmp.angle1 < 0.0)   tmp.angle1 = 0.0;
  if (tmp.angle1 > 180.0) tmp.angle1 = 180.0;
  if (tmp.angle2 < 0.0)   tmp.angle2 = 0.0;
  if (tmp.angle2 > 180.0) tmp.angle2 = 180.0;
  if (tmp.angle3 < 0.0)   tmp.angle3 = 0.0;
  if (tmp.angle3 > 180.0) tmp.angle3 = 180.0;
  if (tmp.angle4 < 60.0)  tmp.angle4 = 60.0;
  if (tmp.angle4 > 150.0) tmp.angle4 = 150.0;
  Pos.ser = tmp;
  (void) recFromServo(&Pos.rec, &Pos.ser);
}

static int btnToUnits(double deltaDeg) {
  double u = deltaDeg * BTN_ANGLE_UNIT;
  return (int) ((u >= 0.0) ? (u + 0.5) : (u - 0.5));
}

static double btnFromUnits(int units) {
  return (double) units / BTN_ANGLE_UNIT;
}

static void btnUpdateTravel(const REC *rec) {
  const double *v = &rec->x;
  for (int a = 0; a < 3; a++) {
    double x = v[a];
    if (x < s_bbMin[a]) s_bbMin[a] = x;
    if (x > s_bbMax[a]) s_bbMax[a] = x;
  }
}

static const char *btnObjectName(int object) {
  static const char *const name[PICK_OBJECT_COUNT] = { "A", "B", "C" };
  if (object < 0 || object >= PICK_OBJECT_COUNT) return "?";
  return name[object];
}

static double btnTravelSpan(void) {
  double t = s_bbMax[0] - s_bbMin[0];
  for (int a = 1; a < 3; a++) {
    double d = s_bbMax[a] - s_bbMin[a];
    if (d > t) t = d;
  }
  return t;
}

static void btnRecPut(const int *u) {
  if (s_recCount >= BTN_REC_ENTRIES) {
    s_recOverflow = true;
    return;
  }
  uint8_t *p = &s_buf[s_recCount * BTN_REC_BYTES];
  uint32_t v = 0;
  for (int j = 0; j < 4; j++) {
    v |= ((uint32_t) (u[j] & 0xFF)) << (8 * j);
  }
  p[0] = (uint8_t) v;
  p[1] = (uint8_t) (v >> 8);
  p[2] = (uint8_t) (v >> 16);
  p[3] = (uint8_t) (v >> 24);
  s_recCount++;
}

static bool btnRecCollect(int *u) {
  bool moved = false;
  for (int j = 0; j < 4; j++) {
    int d = btnToUnits(*btnAngle(j) - s_snap[j]);
    if (d >  BTN_REC_LIMIT - 1) d =  BTN_REC_LIMIT - 1;
    if (d < -BTN_REC_LIMIT)     d = -BTN_REC_LIMIT;
    u[j] = d;
    if (d != 0) {
      moved = true;
      s_snap[j] += btnFromUnits(d);
    }
  }
  return moved;
}

static int  btnStopRecording(void);

static void btnStartRecording(void) __attribute__((noinline));

static void btnStartRecording(void) {
  s_recCount      = 0;
  s_recOverflow   = false;
  s_recording     = true;
  s_recStartMs    = millis();
  s_tickNow       = 0;
  s_recDurationMs = 0;
  s_recTravel     = 0.0;
  for (int j = 0; j < 4; j++) {
    s_snap[j]     = *btnAngle(j);
    s_recStart[j] = s_snap[j];
  }
  s_bbMin[0] = s_bbMax[0] = Pos.rec.x;
  s_bbMin[1] = s_bbMax[1] = Pos.rec.y;
  s_bbMin[2] = s_bbMax[2] = Pos.rec.z;

#if WEARM_DEBUG_SERIAL
  Serial.print(F("[btn] 开始录制：请用摇杆操控机械臂（要有明显位移，最长 "));
  Serial.print((unsigned long) BTN_REC_ENTRIES * BTN_TICK_MS / 1000UL);
  Serial.println(F(" 秒）"));
  Serial.println(F("[btn] 提示：本次录制会覆盖上一次的录制数据"));
#endif
}

static void btnRecTick(unsigned long now) {
  unsigned long tick = (now - s_recStartMs) / BTN_TICK_MS;

  while (s_tickNow < tick && !s_recOverflow) {
    int u[4];
    s_tickNow++;
    (void) btnRecCollect(u);
    btnUpdateTravel(&Pos.rec);
    btnRecPut(u);
  }

  if (s_recOverflow) {
#if WEARM_DEBUG_SERIAL
    Serial.print(F("[btn] 录制缓冲已满（"));
    Serial.print((unsigned int) BTN_REC_ENTRIES);
    Serial.println(F(" 条），自动结束录制"));
#endif
    (void) btnStopRecording();
  }
}

static int btnStopRecording(void) {
  unsigned long now = millis();

  if (!s_recOverflow) {
    int u[4];
    for (int i = 0; i < 8 && !s_recOverflow; i++) {
      if (!btnRecCollect(u)) break;
      btnUpdateTravel(&Pos.rec);
      btnRecPut(u);
    }
  }

  s_recording     = false;
  s_recDurationMs = now - s_recStartMs;

  s_recTravel = btnTravelSpan();

#if WEARM_DEBUG_SERIAL
  Serial.print(F("[btn] 结束录制：时长 "));
  Serial.print(s_recDurationMs);
  Serial.print(F(" ms，条目 "));
  Serial.print(s_recCount);
  Serial.print(F(" 条，末端位移 "));
  Serial.print(s_recTravel, 2);
  Serial.println(F("（坐标单位）"));
#endif

  bool ok = true;
  if (s_recOverflow) {
    ok = false;
#if WEARM_DEBUG_SERIAL
    Serial.print(F("[btn] 不合格：动作太长把 "));
    Serial.print((unsigned int) BTN_REC_ENTRIES);
    Serial.println(F(" 条缓冲写满了，尾部动作丢失"));
#endif
  } else if (s_recCount <= 0) {
    ok = false;
#if WEARM_DEBUG_SERIAL
    Serial.println(F("[btn] 不合格：缓冲里没有任何动作"));
#endif
  } else if (s_recTravel < BTN_REC_MIN_TRAVEL) {
    ok = false;
#if WEARM_DEBUG_SERIAL
    Serial.println(F("[btn] 不合格：位移太小，看不出明显移动"));
#endif
  }

  if (!ok) {
    s_recLen = 0;
    s_recCount = 0;
    s_hasRec = false;
#if WEARM_DEBUG_SERIAL
    Serial.println(F("[btn] 本次录制已丢弃，上一次的录制数据也已被覆盖，请重录"));
#endif
    return PROTO_RES_REC_REJECTED;
  }

  s_recLen = s_recCount;
  s_hasRec = true;
#if WEARM_DEBUG_SERIAL
  Serial.print(F("[btn] 录制已保存："));
  Serial.print(s_recLen);
  Serial.println(F(" 条，按按键3 可播放"));
#endif
  return PROTO_RES_REC_SAVED;
}

static void btnStartRamp(const double *target, bool thenPlay) {
  for (int j = 0; j < 4; j++) {
    s_rampFrom[j] = *btnAngle(j);
    s_rampTo[j]   = target[j];
  }
  s_rampStartMs  = millis();
  s_rampThenPlay = thenPlay;
  s_state        = BS_RAMP;
}

static void btnRampTick(unsigned long now) {
  double t = (double) (now - s_rampStartMs) / (double) BTN_RAMP_MS;
  if (t > 1.0) t = 1.0;

  for (int j = 0; j < 4; j++) {
    *btnAngle(j) = s_rampFrom[j] + (s_rampTo[j] - s_rampFrom[j]) * t;
  }
  btnCommitAngles();

  if (t < 1.0) return;

  for (int j = 0; j < 4; j++) {
    *btnAngle(j) = s_rampTo[j];
  }
  btnCommitAngles();

  if (s_rampThenPlay) {
    s_rampThenPlay = false;
    s_state        = BS_PLAY;
    s_playIdx      = 0;
    s_playDueMs    = millis();
    s_subIdx       = 0;
#if WEARM_DEBUG_SERIAL
    Serial.println(F("[btn] 已摆到录制起点，开始播放"));
#endif
  } else {
    s_state = BS_IDLE;
#if WEARM_DEBUG_SERIAL
    Serial.println(F("[btn] 已回到初始位置"));
#endif
  }
}

static void btnPlayLoad(void) {
  const uint8_t *p = &s_buf[s_playIdx * BTN_REC_BYTES];
  uint32_t v = (uint32_t) p[0] | ((uint32_t) p[1] << 8) |
               ((uint32_t) p[2] << 16) | ((uint32_t) p[3] << 24);
  for (int j = 0; j < 4; j++) {
    int u = (int) ((v >> (8 * j)) & 0xFF);
    u = (u ^ BTN_REC_LIMIT) - BTN_REC_LIMIT;
    s_subDelta[j]   = btnFromUnits(u);
    s_subApplied[j] = 0.0;
  }
  s_subIdx = 0;
}

static void btnPlaySub(void) {
  s_subIdx++;
  for (int j = 0; j < 4; j++) {
    double target = s_subDelta[j] * (double) s_subIdx / (double) BTN_PLAY_SUBSTEPS;
    *btnAngle(j) += target - s_subApplied[j];
    s_subApplied[j] = target;
  }
  btnCommitAngles();
}

static void btnPlayTick(unsigned long now) {
  const unsigned long subMs = BTN_TICK_MS / (unsigned long) BTN_PLAY_SUBSTEPS;

  while (s_playIdx < s_recLen) {
    if (s_subIdx == 0) btnPlayLoad();

    unsigned long due = s_playDueMs + subMs;
    if ((long) (now - due) < 0L) break;
    s_playDueMs = due;
    btnPlaySub();
    if (s_subIdx >= BTN_PLAY_SUBSTEPS) {
      s_subIdx = 0;
      s_playIdx++;
    }
  }

  if (s_playIdx >= s_recLen) {
    s_state = BS_IDLE;
#if WEARM_DEBUG_SERIAL
    Serial.println(F("[btn] 播放结束"));
#endif
  }
}

static int btnActionCycle(void) {
  if (s_recording) {
#if WEARM_DEBUG_SERIAL
    Serial.println(F("[btn] 正在录制，按键1 忽略（先按按键2 结束录制）"));
#endif
    return PROTO_RES_BUSY;
  }
  if (s_state != BS_IDLE) {
#if WEARM_DEBUG_SERIAL
    Serial.println(F("[btn] 正在播放/回中，按键1 忽略"));
#endif
    return PROTO_RES_BUSY;
  }

  int object = s_cycleIdx;
  int rc = pickPlaceStart(object);
  if (rc != 0) {
#if WEARM_DEBUG_SERIAL
    Serial.print(F("[btn] 取放启动失败 rc="));
    Serial.println(rc);
#endif
    return PROTO_RES_BUSY;
  }

#if WEARM_DEBUG_SERIAL
  Serial.print(F("[btn] 按键1 循环执行：夹取物体 "));
  Serial.print(btnObjectName(object));
  Serial.print(F("，下一次是 "));
  Serial.println(btnObjectName((object + 1) % PICK_OBJECT_COUNT));
#endif
  s_cycleIdx = (uint8_t)((object + 1) % PICK_OBJECT_COUNT);
  return PROTO_RES_PICK_STARTED;
}

static int btnActionRecord(void) {
  if (!s_recording) {
    if (pickPlaceIsBusy() || s_state != BS_IDLE) {
#if WEARM_DEBUG_SERIAL
      Serial.println(F("[btn] 机械臂正忙，现在不能开始录制"));
#endif
      return PROTO_RES_BUSY;
    }
    btnStartRecording();
    return PROTO_RES_REC_STARTED;
  }
  return btnStopRecording();
}

static int btnActionPlay(void) {
  if (s_recording) {
    int stopped = btnStopRecording();
    if (stopped != PROTO_RES_REC_SAVED) {
      return stopped;
    }
  }
  if (pickPlaceIsBusy() || s_state != BS_IDLE) {
#if WEARM_DEBUG_SERIAL
    Serial.println(F("[btn] 机械臂正忙，按键3 忽略"));
#endif
    return PROTO_RES_BUSY;
  }
  if (!s_hasRec) {
#if WEARM_DEBUG_SERIAL
    Serial.println(F("[btn] 还没有录制数据，先按按键2 录一段"));
#endif
    return PROTO_RES_PLAY_NO_RECORD;
  }

  btnStartRamp(s_recStart, true);
#if WEARM_DEBUG_SERIAL
  Serial.print(F("[btn] 按键3 播放：先平滑摆到录制起点，再复现 "));
  Serial.print(s_recLen);
  Serial.println(F(" 条动作"));
#endif
  return PROTO_RES_PLAY_STARTED;
}

static int btnActionHome(void) {
  if (s_recording) {
#if WEARM_DEBUG_SERIAL
    Serial.println(F("[btn] 正在录制，按键4 忽略（先按按键2 结束录制）"));
#endif
    return PROTO_RES_BUSY;
  }
  if (pickPlaceIsBusy() || s_state != BS_IDLE) {
#if WEARM_DEBUG_SERIAL
    Serial.println(F("[btn] 正在播放/回中或取放中，按键4 忽略"));
#endif
    return PROTO_RES_BUSY;
  }

  SER home;
  home.angle4 = Pos.ser.angle4;
  if (!posGetHomeAngles(&home)) {
#if WEARM_DEBUG_SERIAL
    Serial.println(F("[btn] 回中失败：初始位姿反解不成功"));
#endif
    return PROTO_RES_BUSY;
  }

  btnStartRamp(&home.angle1, false);

#if WEARM_DEBUG_SERIAL
  Serial.println(F("[btn] 按键4 回中：平滑回到开机初始位姿"));
#endif
  return PROTO_RES_HOME_STARTED;
}

static int btnAction(int key) {
  if (drawAcceptButton(key)) {
    return drawHandleButton(key);
  }

  switch (key) {
    case BTN_KEY_CYCLE:  return btnActionCycle();
    case BTN_KEY_RECORD: return btnActionRecord();
    case BTN_KEY_PLAY:   return btnActionPlay();
    case BTN_KEY_HOME:   return btnActionHome();
    default:             return PROTO_RES_UNKNOWN;
  }
}

#if WEARM_BUTTON_PINS
static bool btnEdge(int key) {
  bool raw = (digitalRead(BTN_PIN[key]) == LOW);
  unsigned long now = millis();

  if (raw == s_btnStable[key]) {
    s_btnArmed[key] = false;
    return false;
  }
  if (!s_btnArmed[key]) {
    s_btnArmed[key]    = true;
    s_btnChangeAt[key] = now;
    return false;
  }
  if ((now - s_btnChangeAt[key]) < BTN_DEBOUNCE_MS) return false;

  s_btnStable[key] = raw;
  s_btnArmed[key]  = false;
  return raw;
}
#endif

void buttonSetup(void) {
#if WEARM_BUTTON_PINS
  for (int k = 0; k < BTN_COUNT; k++) {
    pinMode(BTN_PIN[k], INPUT_PULLUP);
    s_btnStable[k]   = (digitalRead(BTN_PIN[k]) == LOW);
    s_btnArmed[k]    = false;
    s_btnChangeAt[k] = 0UL;
  }
#endif

  s_state        = BS_IDLE;
  s_recording    = false;
  s_hasRec       = false;
  s_recLen       = 0;
  s_recCount     = 0;
  s_recOverflow  = false;
  s_cycleIdx     = 0;
  s_rampThenPlay = false;

#if WEARM_DEBUG_SERIAL
  Serial.println(F("[btn] 按键初始化："));
#if WEARM_BUTTON_PINS
  Serial.println(F("[btn]   按键1 D2  循环执行（每次按顺序夹 A -> B -> C，串口 N）"));
  Serial.println(F("[btn]   按键2 D3  录制 开/关（有明显位移即可，串口 R）"));
  Serial.println(F("[btn]   按键3 D4  播放上一次录制的内容（串口 P）"));
  Serial.println(F("[btn]   按键4 D5  回中：回到开机初始位姿（串口 M 或 0）"));
#else
  Serial.println(F("[btn]   不读 D2~D5 物理按键（WEARM_BUTTON_PINS=0）："));
  Serial.println(F("[btn]     N 循环执行（夹 A -> B -> C）  R 录制开/关"));
  Serial.println(F("[btn]     P 播放上一次录制            M 或 0 回中"));
#endif
#endif
}

void buttonLoop(void) {
  unsigned long now = millis();

  if (s_recording)            btnRecTick(now);
  if (s_state == BS_RAMP)     btnRampTick(now);
  else if (s_state == BS_PLAY) btnPlayTick(now);

#if WEARM_BUTTON_PINS
  for (int k = 0; k < BTN_COUNT; k++) {
    if (!btnEdge(k)) continue;
    (void) btnAction(k);
  }
#endif
}

int buttonHandleCommand(char c) {
  switch (c) {
    case PROTO_CMD_BTN_CYCLE:    return btnAction(BTN_KEY_CYCLE);
    case PROTO_CMD_BTN_RECORD:   return btnAction(BTN_KEY_RECORD);
    case PROTO_CMD_BTN_PLAY:     return btnAction(BTN_KEY_PLAY);
    case PROTO_CMD_BTN_HOME:
    case PROTO_CMD_BTN_HOME_ALT: return btnAction(BTN_KEY_HOME);
    default:                     return PROTO_RES_UNKNOWN;
  }
}

bool buttonIsCommandChar(char c) {
  return (c == PROTO_CMD_BTN_CYCLE)
      || (c == PROTO_CMD_BTN_RECORD)
      || (c == PROTO_CMD_BTN_PLAY)
      || (c == PROTO_CMD_BTN_HOME)
      || (c == PROTO_CMD_BTN_HOME_ALT);
}

int buttonPickNext(void) {
  return s_cycleIdx;
}

bool buttonIsRecording(void) {
  return s_recording;
}

bool buttonPlaybackActive(void) {
  return (s_state == BS_PLAY) || (s_state == BS_RAMP && s_rampThenPlay);
}

int buttonRecordingEntries(void) {
  return s_recording ? s_recCount : s_recLen;
}

unsigned long buttonRecordingMs(void) {
  if (s_recording) return millis() - s_recStartMs;
  return s_recDurationMs;
}

double buttonRecordingTravel(void) {
  return s_recTravel;
}

bool buttonHasRecording(void) {
  return s_hasRec;
}

bool buttonControlBusy(void) {
  return s_recording || (s_state != BS_IDLE);
}

bool buttonControlLocked(void) {
  return (s_state != BS_IDLE);
}

const char *buttonName(int key) {
  switch (key) {
    case BTN_KEY_CYCLE:  return "按键1 循环执行";
    case BTN_KEY_RECORD: return "按键2 录制";
    case BTN_KEY_PLAY:   return "按键3 播放";
    case BTN_KEY_HOME:   return "按键4 回中";
    default:             return "未知按键";
  }
}

const char *buttonStateName(void) {
  if (s_recording)          return "录制中";
  if (s_state == BS_PLAY)   return "播放中";
  if (s_state == BS_RAMP)   return s_rampThenPlay ? "预摆中" : "回中中";
  return "空闲";
}

#endif

static char s_line[PROTO_LINE_BUF_SIZE];
static int  s_len = 0;
static bool s_pending = false;
static bool s_dropUntilEol = false;
static unsigned long s_lastCharMs = 0;

static void protoFlushLine(void);
static bool protoParseAxisLine(const char *s, double angles[3], uint8_t *seen);
static bool protoParseNumber(const char **pp, double *out);
static void protoApplyAngles(const double angles[3], uint8_t seen);
static int protoSpeedStep(int delta);
static int protoHandleDrawCalib(const char *line, char cmd);
#define PROTO_FEATURE_PICK   0x01u
#define PROTO_FEATURE_BUTTON 0x02u
#define PROTO_FEATURE_DRAW   0x04u

static bool protoRuntimeEnabled(uint8_t feature);
static uint8_t protoCompiledFeatures(void);
static uint8_t s_runtimeFeatures =
    (WEARM_ENABLE_PICK_PLACE ? PROTO_FEATURE_PICK : 0u) |
    (WEARM_ENABLE_BUTTONS ? PROTO_FEATURE_BUTTON : 0u) |
    (WEARM_ENABLE_DRAW ? PROTO_FEATURE_DRAW : 0u);

static const char *protoSkipBlanks(const char *p)
{
  while (*p == ' ' || *p == '\t') {
    p++;
  }
  return p;
}

#define PROTO_SKIP_BLANKS(p) do { (p) = protoSkipBlanks(p); } while (0)

#ifndef PSTR
#define PSTR(s) (s)
#endif
#ifndef pgm_read_byte
#define pgm_read_byte(addr) (*(const unsigned char *)(addr))
#endif
#ifndef PROGMEM
#define PROGMEM
#endif

#ifndef WEARM_SERIAL_ARDUINO
#define WEARM_SERIAL_ARDUINO 0
#endif

#if defined(__AVR__) && !WEARM_SERIAL_ARDUINO
#define WEARM_UART_RAW 1
#else
#define WEARM_UART_RAW 0
#endif

#if WEARM_UART_RAW
#include <avr/interrupt.h>

#define PROTO_RX_BUF_MASK 63u
static volatile uint8_t s_rxBuf[PROTO_RX_BUF_MASK + 1u];
static volatile uint8_t s_rxHead = 0;
static volatile uint8_t s_rxTail = 0;

static void protoRxStore(uint8_t b)
{
  uint8_t next = (uint8_t)((s_rxHead + 1u) & PROTO_RX_BUF_MASK);

  if (next != s_rxTail) {
    s_rxBuf[s_rxHead] = b;
    s_rxHead = next;
  }
}

ISR(USART_RX_vect)
{
  protoRxStore(UDR0);
}

static void protoPut(char c)
{
  while ((UCSR0A & (1u << UDRE0)) == 0u) {
  }
  UDR0 = (uint8_t)c;
}

static int protoRxTake(void)
{
  uint8_t b;

  if (s_rxHead == s_rxTail) {
    return -1;
  }
  b = s_rxBuf[s_rxTail];
  s_rxTail = (uint8_t)((s_rxTail + 1u) & PROTO_RX_BUF_MASK);
  return (int)b;
}

static void protoSerialBegin(void)
{
  uint16_t ubrr = (uint16_t)((F_CPU / 4UL / (unsigned long)PROTO_BAUD - 1UL) / 2UL);

  UCSR0A = (uint8_t)(1u << U2X0);
  UBRR0H = (uint8_t)(ubrr >> 8);
  UBRR0L = (uint8_t)ubrr;
  UCSR0C = (uint8_t)((1u << UCSZ01) | (1u << UCSZ00));
  UCSR0B = (uint8_t)((1u << RXEN0) | (1u << TXEN0) | (1u << RXCIE0));
}
#else
static void protoPut(char c)
{
  Serial.print(c);
}

static int protoRxTake(void)
{
  if (Serial.available() <= 0) {
    return -1;
  }
  return Serial.read();
}

static void protoSerialBegin(void)
{
  Serial.begin(PROTO_BAUD);
}
#endif

#if WEARM_SERIAL_RESPONSES

static void protoWriteInt(int v)
{
  if (v >= 100) {
    protoPut((char)('0' + v / 100));
  }
  if (v >= 10) {
    protoPut((char)('0' + (v / 10) % 10));
  }
  protoPut((char)('0' + v % 10));
}

__attribute__((noinline, noclone))
static void protoReply(const char *text)
{
  char c;

  while ((c = (char)pgm_read_byte(text++)) != '\0') {
    if (c == '#') {
      protoWriteInt((int)Pos.ser.angle4);
    } else {
      protoPut(c);
    }
  }
  protoPut('\n');
}

static const char s_rOk[] PROGMEM = "OK";
static const char s_rErr[] PROGMEM = "ERR";
static const char s_rRej[] PROGMEM = "REJECTED";
static const char s_rOkN[] PROGMEM = "OK #";
static const char s_rBusy[] PROGMEM = "BUSY";
static const char s_rDiscard[] PROGMEM = "DISCARD";
static const char s_rEmpty[] PROGMEM = "EMPTY";
static const char s_rOff[] PROGMEM = "OFF";
static const char s_rBoot[] PROGMEM = "CMD OSHL 123 kK ABC NRPM0 FDGEQUW pno ANG x,y,z ! !P !B !D";

__attribute__((noinline))
static void protoReplyTaskTag(const char *tag)
{
  protoPut('O');
  protoPut('K');
  protoPut(' ');
  protoPut('F');
  protoPut('=');
  while (*tag != '\0') {
    protoPut(*tag++);
  }
  protoPut('\n');
}

#define R_OK()   protoReply(s_rOk)
#define R_ERR()  protoReply(s_rErr)
#define R_REJ()  protoReply(s_rRej)
#define R_OKN()  protoReply(s_rOkN)
#define R_BUSY() protoReply(s_rBusy)
#define R_DISCARD() protoReply(s_rDiscard)
#define R_EMPTY() protoReply(s_rEmpty)
#define R_OFF()  protoReply(s_rOff)
#define R_BOOT() protoReply(s_rBoot)
#define R_FEATURE() do { protoPut('P'); protoPut('='); protoPut((s_runtimeFeatures & PROTO_FEATURE_PICK) ? '1' : '0'); protoPut(' '); protoPut('B'); protoPut('='); protoPut((s_runtimeFeatures & PROTO_FEATURE_BUTTON) ? '1' : '0'); protoPut(' '); protoPut('D'); protoPut('='); protoPut((s_runtimeFeatures & PROTO_FEATURE_DRAW) ? '1' : '0'); protoPut(10); } while (0)
#else
#define R_OK()   do { } while (0)
#define R_ERR()  do { } while (0)
#define R_REJ()  do { } while (0)
#define R_OKN()  do { } while (0)
#define R_BUSY() do { } while (0)
#define R_DISCARD() do { } while (0)
#define R_EMPTY() do { } while (0)
#define R_OFF()  do { } while (0)
#define R_BOOT() do { } while (0)
#define R_FEATURE() do { } while (0)
#define protoReplyTaskTag(tag) do { (void)(tag); } while (0)
#endif

static const uint8_t s_liveBits[9] PROGMEM = { 0x0F, 0x00, 0xF0, 0x71, 0xA7, 0x00, 0x00, 0xC0, 0x01 };
static const uint8_t s_fastBits[9] PROGMEM = { 0x0E, 0x00, 0x0E, 0x99, 0x08, 0x00, 0x00, 0x08, 0x00 };

__attribute__((noinline)) static bool protoCmdBit(const uint8_t *bits, char cmd)
{
  uint8_t i = (uint8_t)cmd - (uint8_t)'0';

  if (i > 64u) {
    return false;
  }
  return (pgm_read_byte(bits + (i >> 3)) & (uint8_t)(1u << (i & 7u))) != 0;
}

static const uint8_t s_featureBits[17] PROGMEM = {
  0x02,
  0x00, 0x00, 0x00,
  0x54,
  0xFF,
  0x00,
  0x28,
  0x2E,
  0xCC,
  0x00, 0x00, 0x00, 0x00, 0x00,
  0xF0,
  0x03
};

__attribute__((noinline)) static uint8_t protoCmdFeature(char cmd)
{
  uint8_t i = (uint8_t)cmd - (uint8_t)'0';

  if (i > 64u) {
    return 0u;
  }
  return (uint8_t)((pgm_read_byte(s_featureBits + (i >> 2)) >> (uint8_t)((i & 3u) * 2u)) & 0x03u);
}

void serialProtocolLoop(void)
{
  int c;

  while ((c = protoRxTake()) >= 0) {
    s_lastCharMs = millis();

    if (c == '\n' || c == '\r') {
      if (s_dropUntilEol) {
        s_dropUntilEol = false;
        s_len = 0;
        s_pending = false;
      } else {
        protoFlushLine();
      }
      continue;
    }
    if (s_dropUntilEol) {
      continue;
    }

    if (s_len >= PROTO_LINE_BUF_SIZE - 1) {
      s_dropUntilEol = true;
      s_len = 0;
      s_pending = false;
      continue;
    }

    s_line[s_len++] = (char)c;
    s_pending = true;

    if (s_len == 1 && protoCmdBit(s_fastBits, s_line[0])) {
      protoFlushLine();
    }
  }

  if (s_pending && (millis() - s_lastCharMs) >= PROTO_LINE_TIMEOUT_MS) {
    protoFlushLine();
  }

  if (s_dropUntilEol && (millis() - s_lastCharMs) >= PROTO_LINE_TIMEOUT_MS) {
    s_dropUntilEol = false;
    s_line[0] = '\0';
    s_len = 0;
    s_pending = false;
  }
}

static bool protoRuntimeEnabled(uint8_t feature)
{
  return (s_runtimeFeatures & feature) != 0;
}

static uint8_t protoCompiledFeatures(void)
{
  return (WEARM_ENABLE_PICK_PLACE ? PROTO_FEATURE_PICK : 0u) |
         (WEARM_ENABLE_BUTTONS ? PROTO_FEATURE_BUTTON : 0u) |
         (WEARM_ENABLE_DRAW ? PROTO_FEATURE_DRAW : 0u);
}

static void protoReplyButtonResult(int result)
{
  (void)result;
  if (result == PROTO_RES_BUSY) {
    R_BUSY();
  } else if (result == PROTO_RES_REC_REJECTED) {
    R_DISCARD();
  } else if (result == PROTO_RES_PLAY_NO_RECORD) {
    R_EMPTY();
  } else if (result < 0) {
    R_ERR();
  } else {
    R_OK();
  }
}

static void protoRefuseModule(uint8_t feature)
{
  if ((protoCompiledFeatures() & feature) != 0u) {
    R_OFF();
  } else {
    R_REJ();
  }
}

static void protoFlushLine(void)
{
  s_line[s_len] = '\0';
  if (s_len > 0) {
    protoHandleLine(s_line);
  }
  s_len = 0;
  s_pending = false;
}

int protoHandleLine(const char *line)
{
  if (line == NULL) {
    return PROTO_RES_NONE;
  }

  const char *p = line;
  PROTO_SKIP_BLANKS(p);

  const char cmd = *p;
  if (cmd == '\0') {
    return PROTO_RES_NONE;
  }

  const char *tail = p + 1;
  PROTO_SKIP_BLANKS(tail);
  const bool single = (*tail == '\0');

  if (cmd == '!' && !single) {
    const char *q = tail;
    uint8_t feature;
    if (q[1] != '\0' || (q[0] != 'P' && q[0] != 'B' && q[0] != 'D')) {
      R_REJ();
      return PROTO_RES_UNKNOWN;
    }
    feature = q[0] == 'P' ? PROTO_FEATURE_PICK :
              q[0] == 'B' ? PROTO_FEATURE_BUTTON : PROTO_FEATURE_DRAW;
    if (!(protoCompiledFeatures() & feature)) {
      R_REJ();
      return PROTO_RES_UNKNOWN;
    }
    if (!protoRuntimeEnabled(feature)) s_runtimeFeatures |= feature;
    else s_runtimeFeatures &= (uint8_t)~feature;
    R_FEATURE();
    return PROTO_RES_FEATURE;
  }
  if (cmd == '!' && single) {
    R_FEATURE();
    return PROTO_RES_NONE;
  }

  if (!single && (cmd == PROTO_CMD_BTN_CYCLE || cmd == PROTO_CMD_BTN_RECORD ||
      cmd == PROTO_CMD_BTN_PLAY || cmd == PROTO_CMD_BTN_HOME ||
      cmd == PROTO_CMD_BTN_HOME_ALT)) {
    R_ERR();
    return PROTO_RES_BAD_SYNTAX;
  }
  if (single) {
    uint8_t module = protoCmdFeature(cmd);

    if (module != 0u) {
      uint8_t feature = (module == 1u) ? PROTO_FEATURE_PICK :
                        (module == 2u) ? PROTO_FEATURE_BUTTON : PROTO_FEATURE_DRAW;

      if (!protoRuntimeEnabled(feature)) {
        protoRefuseModule(feature);
        return PROTO_RES_UNKNOWN;
      }
    }
  }

  if (drawControlBusy() || buttonControlBusy() || pickPlaceIsBusy()) {
    if (!protoCmdBit(s_liveBits, cmd)) {
      R_BUSY();
      return PROTO_RES_BUSY;
    }
  }

  if (single) {
    if (cmd == PROTO_CMD_BTN_HOME_ALT) {
      int result = buttonHandleCommand(cmd);
      protoReplyButtonResult(result);
      return result < 0 ? PROTO_RES_UNKNOWN : result;
    }

    if (cmd == PROTO_CMD_GRIPPER_OPEN) {
      posSetAngle4(150.0);
      R_OKN();
      return PROTO_RES_GRIPPER_OPEN;

    } else if (cmd == PROTO_CMD_GRIPPER_CLOSE) {
      posSetAngle4(60.0);
      R_OKN();
      return PROTO_RES_GRIPPER_CLOSE;

    } else if (cmd == PROTO_CMD_SPEED_UP || cmd == PROTO_CMD_SPEED_DOWN) {
        protoSpeedStep((cmd == PROTO_CMD_SPEED_UP) ? +1 : -1);
        R_OK();
        return (cmd == PROTO_CMD_SPEED_UP) ? PROTO_RES_SPEED_UP : PROTO_RES_SPEED_DOWN;

    } else if (cmd == PROTO_CMD_PICK_A || cmd == PROTO_CMD_PICK_B ||
               cmd == PROTO_CMD_PICK_C) {
        int object = PICK_OBJECT_A + (cmd - PROTO_CMD_PICK_A);
        int rc = pickPlaceStart(object);
        if (rc == 0) {
          R_OK();
          return PROTO_RES_PICK_STARTED;
        }
        R_BUSY();
        return PROTO_RES_BUSY;

    } else if (cmd == PROTO_CMD_BTN_CYCLE || cmd == PROTO_CMD_BTN_RECORD ||
               cmd == PROTO_CMD_BTN_PLAY || cmd == PROTO_CMD_BTN_HOME) {
      int result = buttonHandleCommand(cmd);
      protoReplyButtonResult(result);
      return result < 0 ? PROTO_RES_UNKNOWN : result;

    } else if (cmd == PROTO_CMD_DRAW_TASK || cmd == PROTO_CMD_DRAW_START ||
               cmd == PROTO_CMD_DRAW_RECORD || cmd == PROTO_CMD_DRAW_UNDO ||
               cmd == PROTO_CMD_DRAW_PAUSE || cmd == PROTO_CMD_DRAW_RESUME ||
               cmd == PROTO_CMD_DRAW_CANCEL) {
      int result = drawHandleCommand(cmd);
      if (result == PROTO_RES_DRAW_TASK_SELECTED) {
        protoReplyTaskTag(drawTaskTag(drawGetTask()));
      } else if (result == PROTO_RES_BUSY) R_BUSY();
      else if (result == PROTO_RES_DRAW_REJECTED) R_REJ();
      else if (result < 0) R_ERR();
      else R_OK();
      return result;
    }
  }

  if ((cmd == PROTO_CMD_DRAW_PAPER_Z ||
       cmd == PROTO_CMD_DRAW_HALF ||
       cmd == PROTO_CMD_DRAW_CENTER) && !single) {
    if (!protoRuntimeEnabled(PROTO_FEATURE_DRAW)) {
      protoRefuseModule(PROTO_FEATURE_DRAW);
      return PROTO_RES_UNKNOWN;
    }
    int result = protoHandleDrawCalib(p, cmd);
    if (result == PROTO_RES_DRAW_REJECTED) R_REJ();
    return result;
  }

  if (protoAxisIndexFromChar(cmd) >= 0) {
    double angles[3];
    uint8_t seen = 0;

    if (!protoParseAxisLine(p, angles, &seen)) {
      R_ERR();
      return PROTO_RES_BAD_SYNTAX;
    }

    protoApplyAngles(angles, seen);

    R_OK();
    return PROTO_RES_ANGLES_SET;
  }

  {
    const char *scan = p;
    while (*scan != '\0' && *scan != ',') {
      scan++;
    }
    if (*scan != ',' && cmd != '=') {
      R_ERR();
      return PROTO_RES_UNKNOWN;
    }
  }

  R_ERR();
  return PROTO_RES_BAD_SYNTAX;
}

static bool protoParseAxisLine(const char *s, double angles[3], uint8_t *seen)
{
  const char *p = s;
  int groups = 0;

  for (;;) {
    PROTO_SKIP_BLANKS(p);

    int axis = protoAxisIndexFromChar(*p);
    if (axis < 0) return false;
    p++;

    PROTO_SKIP_BLANKS(p);

    if (*p == '=') {
      p++;
      PROTO_SKIP_BLANKS(p);
    }

    if (!protoParseNumber(&p, &angles[axis])) return false;

    *seen |= (uint8_t)(1u << axis);
    groups++;

    PROTO_SKIP_BLANKS(p);
    if (*p == '\0') break;
    if (*p != ',') return false;
    p++;
  }

  return (groups > 0);
}

static bool protoParseNumber(const char **pp, double *out)
{
  const char *p = *pp;
  bool neg = false;
  unsigned int ip = 0;
  double value;

  if (*p == '+') {
    p++;
  } else if (*p == '-') {
    neg = true;
    p++;
  }

  if (*p < '0' || *p > '9') {
    return false;
  }
  do {
    if (ip < 9999u) {
      ip = ip * 10u + (unsigned int)(*p - '0');
    }
    p++;
  } while (*p >= '0' && *p <= '9');

  value = (double)ip;

  if (*p == '.') {
    double decimal_place = 0.1;
    p++;
    if (*p < '0' || *p > '9') {
      return false;
    }
    do {
      value += (*p - '0') * decimal_place;
      decimal_place *= 0.1;
      p++;
    } while (*p >= '0' && *p <= '9');
  }

  *out = neg ? -value : value;
  *pp = p;
  return true;
}

static void protoApplyAngles(const double angles[3], uint8_t seen)
{
  for (int a = 0; a < PROTO_AXIS_COUNT; a++) {
    if ((seen & (uint8_t)(1u << a)) == 0u) continue;
    double v = angles[a];
    if (v < 0.0)   v = 0.0;
    if (v > 180.0) v = 180.0;
    (&Pos.ser.angle1)[a] = v;
  }

  (void) recFromServo(&Pos.rec, &Pos.ser);
}

static int protoHandleDrawCalib(const char *line, char cmd)
{
  const char *p = line + 1;
  double v1;
  double v2;

  PROTO_SKIP_BLANKS(p);
  if (!protoParseNumber(&p, &v1)) {
    R_ERR();
    return PROTO_RES_DRAW_REJECTED;
  }
  PROTO_SKIP_BLANKS(p);

  bool ok = false;
  if (cmd == PROTO_CMD_DRAW_PAPER_Z) {
    if (*p == '\0') ok = drawSetPaperZ(v1);
  } else if (cmd == PROTO_CMD_DRAW_HALF) {
    if (*p == '\0') ok = drawSetHalfSize(v1);
  } else if (*p == ',') {
    p++;
    PROTO_SKIP_BLANKS(p);
    if (protoParseNumber(&p, &v2) && *p == '\0') {
      ok = drawSetCenter(v1, v2);
    }
  }

  if (ok) {
    R_OK();
    return PROTO_RES_DRAW_CALIBRATED;
  }

  R_ERR();
  return PROTO_RES_DRAW_REJECTED;
}

static int protoSpeedStep(int delta)
{
  int current_level = speedGetLevel();

  if (current_level < PROTO_SPEED_LEVEL_MIN || current_level > PROTO_SPEED_LEVEL_MAX) {
    current_level = PROTO_SPEED_LEVEL_DEF;
  }

  int want_level = current_level + delta;

  if (want_level < PROTO_SPEED_LEVEL_MIN) {
    want_level = PROTO_SPEED_LEVEL_MIN;
  } else if (want_level > PROTO_SPEED_LEVEL_MAX) {
    want_level = PROTO_SPEED_LEVEL_MAX;
  }

  if (want_level == current_level) {
    return current_level;
  }

  want_level = adjustSpeed(want_level);
  return want_level;
}

void serialProtocolBegin(void)
{
  protoSerialBegin();
  s_runtimeFeatures = protoCompiledFeatures();

  R_BOOT();
}

void writeServo(void){
#if WEARM_MIRROR_BASE
    servoDriveWrite(0, 180.0 - Pos.ser.angle1);
#else
    servoDriveWrite(0, Pos.ser.angle1);
#endif

    servoDriveWrite(1, Pos.ser.angle2);
    servoDriveWrite(2, Pos.ser.angle3);

#if WEARM_MIRROR_TOOL
    servoDriveWrite(3, (60.0 + 150.0) - Pos.ser.angle4);
#else
    servoDriveWrite(3, Pos.ser.angle4);
#endif
}

void setup() {
  posInit();

  serialProtocolBegin();

  joystickSetup();

  buttonSetup();

  drawSetup();

  servoDriveBegin();
  servoDriveAttach(0, 9);
  servoDriveAttach(1, 7);
  servoDriveAttach(2, 8);
  servoDriveAttach(3, 6);

  writeServo();

}

void loop() {
  serialProtocolLoop();

  pickPlaceLoop();

  buttonLoop();

  drawLoop();

  joystickLoop();

  writeServo();
}
